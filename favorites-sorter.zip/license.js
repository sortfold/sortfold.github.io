// Licence Pro (Lemon Squeezy) et quota gratuit. Chargé par background.js (importScripts) : les appels réseau se font ici,
// pas dans les pages TikTok. Dépend de PRO_CONFIG (config.js).
//
// Limite honnête : l'extension est du code ouvert côté navigateur, donc ce contrôle décourage l'usage gratuit du mode Pro
// mais ne peut pas l'empêcher pour quelqu'un de déterminé. C'est normal pour un outil à 5 € ; le but est la simplicité.

const LS_API = 'https://api.lemonsqueezy.com/v1/licenses';
const DAY_MS = 24 * 60 * 60 * 1000;

const licenseConfigured = () => !!(PRO_CONFIG.storeId && PRO_CONFIG.productId);

async function lsCall(path, params) {
  const res = await fetch(`${LS_API}/${path}`, {
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params),
  });
  return res.json();
}

// La clé doit appartenir à TA boutique et à TON produit (sinon une clé achetée ailleurs débloquerait l'extension).
const sameProduct = (meta) => String(meta?.store_id) === String(PRO_CONFIG.storeId) && String(meta?.product_id) === String(PRO_CONFIG.productId);

const getLicense = async () => (await chrome.storage.local.get('license')).license || null;
const putLicense = (l) => chrome.storage.local.set({ license: l });

// Revérifie la licence auprès du service. Sans connexion, on garde la licence valable pendant `offlineGraceDays`.
async function revalidateLicense(l) {
  try {
    const r = await lsCall('validate', { license_key: l.key, instance_id: l.instanceId });
    const ok = r.valid === true && sameProduct(r.meta) && ['active', 'inactive'].includes(r.license_key?.status);
    await putLicense({ ...l, valid: ok, checkedAt: Date.now(), error: ok ? '' : r.error || 'Licence désactivée ou expirée.' });
  } catch {
    if (Date.now() - (l.checkedAt || 0) > PRO_CONFIG.offlineGraceDays * DAY_MS) {
      await putLicense({ ...l, valid: false, error: 'Vérification impossible depuis trop longtemps : reconnecte-toi à Internet.' });
    }
  }
}

// ── code personnel : comparaison d'empreintes, le code n'apparaît nulle part dans l'extension
const hexToBytes = (h) => new Uint8Array(h.match(/../g).map((b) => parseInt(b, 16)));
const bytesToHex = (b) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
async function codeHash(code) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(code), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: hexToBytes(PRO_CONFIG.masterSalt), iterations: 200000 }, key, 256);
  return bytesToHex(bits);
}
const masterOk = async (code) => !!PRO_CONFIG.masterHash && (await codeHash(String(code).trim().toLowerCase())) === PRO_CONFIG.masterHash;

async function isPro() {
  let l = await getLicense();
  if (l?.master) return l.proof === PRO_CONFIG.masterHash; // la preuve est l'empreinte : un simple drapeau écrit à la main ne suffit pas
  if (!licenseConfigured()) return true; // mode développement : tout est débloqué
  if (!l?.valid) return false;
  if (Date.now() - (l.checkedAt || 0) > PRO_CONFIG.revalidateDays * DAY_MS) {
    await revalidateLicense(l);
    l = await getLicense();
  }
  return l?.valid === true;
}

async function activateLicense(rawKey) {
  const key = String(rawKey || '').trim();
  if (!key) return { ok: false, error: 'Saisis ta clé de licence.' };
  if (await masterOk(key)) {
    await putLicense({ master: true, proof: PRO_CONFIG.masterHash, valid: true, checkedAt: Date.now(), email: '', error: '' });
    return { ok: true, note: 'Mode illimité activé.' };
  }
  if (!licenseConfigured()) return { ok: true, note: 'Mode développement : tout est déjà débloqué.' };
  try {
    const r = await lsCall('activate', { license_key: key, instance_name: `Chrome ${navigator.userAgent.match(/Chrome\/([\d.]+)/)?.[1] || ''}`.trim() });
    if (!r.activated) return { ok: false, error: r.error || 'Clé refusée.' };
    if (!sameProduct(r.meta)) {
      await lsCall('deactivate', { license_key: key, instance_id: r.instance?.id }).catch(() => {});
      return { ok: false, error: 'Cette clé ne correspond pas à ce produit.' };
    }
    await putLicense({ key, instanceId: r.instance?.id, valid: true, checkedAt: Date.now(), email: r.meta?.customer_email || '', error: '' });
    return { ok: true };
  } catch {
    return { ok: false, error: 'Impossible de joindre le service de licences. Vérifie ta connexion.' };
  }
}

async function deactivateLicense() {
  const l = await getLicense();
  if (l?.key && l.instanceId) await lsCall('deactivate', { license_key: l.key, instance_id: l.instanceId }).catch(() => {});
  await chrome.storage.local.remove('license'); // libère l'activation : la clé peut servir sur un autre ordinateur
  return { ok: true };
}

// ── quota gratuit : retraits par jour (jour local)
const todayKey = () => new Date().toLocaleDateString('sv-SE');
async function usageToday() {
  const { usage } = await chrome.storage.local.get('usage');
  return usage && usage.date === todayKey() ? usage : { date: todayKey(), removals: 0 };
}
const bumpUsage = async (n) => {
  const u = await usageToday();
  u.removals = Math.max(0, u.removals + n);
  await chrome.storage.local.set({ usage: u });
  return u;
};

// Ce que l'interface affiche : plan, quota, achat.
async function planStatus() {
  const pro = await isPro();
  const l = await getLicense();
  const u = await usageToday();
  return {
    configured: licenseConfigured(),
    pro,
    used: u.removals,
    limit: PRO_CONFIG.freeDailyRemovals,
    buyUrl: PRO_CONFIG.buyUrl,
    price: PRO_CONFIG.price,
    donateUrl: PRO_CONFIG.donateUrl,
    email: l?.email || '',
    keyTail: l?.master ? 'code perso' : l?.key ? `…${l.key.slice(-4)}` : '',
    error: l && !l.valid ? l.error || '' : '',
  };
}
