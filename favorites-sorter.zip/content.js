(() => {
  if (window.top !== window) return;
  const _tr = (s) => (typeof TTS_I18N !== 'undefined' ? TTS_I18N.tr(s) : s);
  const confirm = (m) => window.confirm(_tr(m));
  const alert = (m) => window.alert(_tr(m));
  const prompt = (m, d) => window.prompt(_tr(m), d);

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const send = (msg) => chrome.runtime.sendMessage(msg);

  // ───────────────────────── Mode « job » : retirer un favori ─────────────────────────
  // Vérifié sur tiktok.com (FR) : le bouton est un <div role="button" data-e2e="favorite-icon">.
  // Son aria-label ne change JAMAIS (« Ajouter aux Favoris… » même si déjà favori) :
  // l'état se lit sur la couleur de l'icône (jaune #FACE15 = favori, blanc = non favori).
  // La page contient plusieurs vidéos (flux) : on prend le bouton visible dans la fenêtre.
  function findFavButton() {
    const all = [...document.querySelectorAll('[data-e2e="favorite-icon"]')];
    return (
      all.find((el) => {
        const r = el.getBoundingClientRect();
        return r.height > 0 && r.top >= -10 && r.bottom <= innerHeight + 10;
      }) ||
      all[0] ||
      null
    );
  }

  // true = actuellement en favori, false = pas en favori, null = indéterminé
  function favState(btn) {
    const svg = btn?.querySelector('svg');
    if (!svg) return null;
    const m = getComputedStyle(svg).color.match(/\d+(\.\d+)?/g);
    if (!m) return null;
    const [r, g, b] = m.map(Number);
    return r > 200 && g > 170 && b < 90;
  }

  async function runJob(id, account) {
    const report = (status, note = '') => send({ type: 'job-result', id, status, note });
    // garde-fou : le retrait ne doit s'exécuter que sous le compte qui l'a demandé
    const handle = await waitFor(() => currentHandle(), 15000, 150);
    if (account && handle !== account) return report('error', `Ce retrait appartient à ${account} (connecté : ${handle || 'personne'})`);
    // Attentes actives (on agit dès que la page est prête) plutôt que des pauses fixes : c'est ce qui coûtait ~4 s par vidéo.
    // Le flux peut enchaîner sur une autre vidéo : on ne clique que sur le bouton de la bonne.
    const btn = await waitFor(() => location.href.includes(id) && findFavButton(), 25000, 150);
    if (!btn) return report('error', location.href.includes(id) ? 'Bouton favori introuvable (connexion ? captcha ?)' : 'La page affiche une autre vidéo');
    // L'icône est d'abord blanche le temps que TikTok charge l'état : on attend de la voir jaune (favori).
    let st = null;
    for (const end = Date.now() + 6000; Date.now() < end; ) {
      st = favState(findFavButton() || btn);
      if (st === true) break;
      await sleep(150);
    }
    if (st !== true) {
      // toujours pas jaune : deux lectures espacées avant de conclure « déjà retiré »
      await sleep(1200);
      st = favState(findFavButton() || btn);
      if (st === false) return report('done', 'Déjà retiré');
      if (st !== true) return report('error', 'État du favori illisible');
    }
    (findFavButton() || btn).click();
    // vérification : dès que l'icône n'est plus jaune (pas d'attente fixe)
    let after = true;
    for (const end = Date.now() + 5000; Date.now() < end; ) {
      await sleep(150);
      after = favState(findFavButton() || btn);
      if (after === false) break;
    }
    if (after === false) return report('done');
    if (after === true) return report('error', 'Le clic n’a pas retiré le favori');
    return report('unverified', 'Clic effectué, état non vérifiable');
  }
  // ───────────────────────── Mode « interface » ─────────────────────────
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, Segoe UI, sans-serif; }
    button { cursor: pointer; font: inherit; color: inherit; }
    .fab { position: fixed; right: 20px; bottom: 20px; z-index: 2147483646; background: #fe2c55; color: #fff; border: 0;
      border-radius: 999px; padding: 12px 18px; font-weight: 700; box-shadow: 0 6px 20px #0006; }
    .ov { position: fixed; inset: 0; z-index: 2147483647; background: #0b0b10; color: #f4f4f6; display: flex; flex-direction: column; }
    .ov[hidden] { display: none; }
    header { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-bottom: 1px solid #ffffff18; }
    .acct { color: #8a8a96; font-size: 12px; }
    header .tabs { display: flex; gap: 6px; flex: 1; flex-wrap: wrap; }
    .tab { background: transparent; border: 1px solid #ffffff25; border-radius: 999px; padding: 6px 14px; }
    .tab.on { background: #fff; color: #000; border-color: #fff; }
    .x { background: transparent; border: 0; font-size: 22px; }
    main { flex: 1; overflow: auto; display: flex; flex-direction: column; align-items: center; padding: 16px; }
    .stage { position: relative; width: min(360px, 90vw); height: min(640px, calc(100vh - 210px)); margin-top: 4px; }
    .card { position: absolute; inset: 0; border-radius: 18px; overflow: hidden; background: #000; box-shadow: 0 10px 40px #000a;
      touch-action: none; will-change: transform; }
    .card iframe { width: 100%; height: 100%; border: 0; background: #111; }
    .drag { position: absolute; left: 0; right: 0; cursor: grab; }
    /* La couche de glissement couvre toute la carte (on glisse de n'importe où) sauf : un trou autour du ▶ central,
       pour lancer/mettre en pause la vidéo, et les 44 px du bas où se trouvent les commandes du lecteur. */
    .drag.top, .drag.bot { display: none; }
    .drag.mid { top: 0; bottom: 44px; clip-path: polygon(evenodd, 0 0, 100% 0, 100% 100%, 0 100%, 0 0,
      calc(50% - 44px) calc(50% - 22px), calc(50% + 44px) calc(50% - 22px), calc(50% + 44px) calc(50% + 66px),
      calc(50% - 44px) calc(50% + 66px), calc(50% - 44px) calc(50% - 22px)); }
    .tag { position: absolute; top: 60px; padding: 6px 14px; border: 4px solid; border-radius: 12px; font-weight: 800; font-size: 32px;
      opacity: 0; pointer-events: none; letter-spacing: 1px; background: #0009; }
    .tag.keep { right: 16px; color: #3ddc84; transform: rotate(12deg); }
    .tag.del { left: 16px; color: #ff4d5e; transform: rotate(-12deg); }
    .undobar { position: fixed; left: 50%; bottom: 22px; translate: -50% 0; background: #1a1a22; border: 1px solid #ffffff25; border-radius: 12px; padding: 8px 10px 8px 14px; z-index: 6; box-shadow: 0 8px 30px #000a; display: flex; gap: 10px; align-items: center; font-size: 13px; }
    .undobar button { background: #fe2c55; border: 0; border-radius: 8px; padding: 6px 10px; color: #fff; font-weight: 700; }
    .tag.col { left: 50%; top: auto; bottom: 90px; color: #4db8ff; translate: -50% 0; }
    .btns { display: flex; gap: 14px; margin-top: 16px; align-items: center; }
    .rb { width: 58px; height: 58px; border-radius: 50%; border: 2px solid; background: #15151c; font-size: 24px; }
    .rb.del { color: #ff4d5e; } .rb.keep { color: #3ddc84; } .rb.col { color: #4db8ff; }
    .rb.undo { width: 44px; height: 44px; font-size: 18px; color: #ccc; border-color: #ffffff30; }
    .hint { color: #8a8a96; font-size: 12px; margin-top: 10px; text-align: center; max-width: 420px; }
    .count { color: #8a8a96; font-size: 13px; margin-bottom: 8px; }
    .empty { text-align: center; max-width: 460px; margin: auto; line-height: 1.5; }
    .empty h2 { margin: 0 0 8px; }
    .pri { background: #fe2c55; border: 0; border-radius: 10px; padding: 12px 18px; font-weight: 700; color: #fff; margin: 6px; }
    .sec { background: #ffffff14; border: 1px solid #ffffff25; border-radius: 10px; padding: 10px 16px; margin: 6px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 10px; width: 100%; max-width: 1000px; }
    .item { position: relative; aspect-ratio: 9/14; background: #1b1b24 center/cover; border-radius: 10px; overflow: hidden; }
    .item a { position: absolute; inset: 0; }
    .item .lbl { position: absolute; left: 0; right: 0; bottom: 0; padding: 6px; font-size: 11px; background: #000b; display: flex; gap: 6px; align-items: center; justify-content: space-between; }
    .item .lbl button { background: #ffffff22; border: 0; border-radius: 6px; padding: 2px 6px; font-size: 11px; }
    .item .lbl .acts { display: flex; gap: 3px; }
    .syncbtn { background: #fe2c55; border: 0; border-radius: 10px; padding: 10px 12px; font-weight: 700; font-size: 13px; color: #fff; text-align: left; }
    .syncbtn:disabled { background: #3a3a46; color: #8a8a96; cursor: default; }
    .sec.small { padding: 5px 12px; font-size: 12px; margin: 0 0 6px; }
    .err { color: #ff4d5e; font-size: 13px; max-width: 1000px; width: 100%; margin: 0 0 8px; }
    .ren { background: none; border: 0; color: #8a8a96; font-size: 14px; }
    h3 { align-self: flex-start; max-width: 1000px; width: 100%; margin: 18px auto 10px; }
    .modal { position: fixed; inset: 0; background: #000a; display: grid; place-items: center; z-index: 2147483647; }
    .box { background: #1a1a22; border-radius: 16px; padding: 18px; width: min(360px, 92vw); max-height: 80vh; overflow: auto; }
    .box button.opt { display: block; width: 100%; text-align: left; background: #ffffff10; border: 0; border-radius: 10px; padding: 12px; margin-bottom: 8px; }
    .box input { width: 100%; padding: 10px; border-radius: 10px; border: 1px solid #ffffff30; background: #0b0b10; color: #fff; margin: 6px 0; }
    /* couleurs explicites : sans elles, le texte de la fenêtre suit la couleur de la page TikTok */
    .modal { color: #f4f4f6; font-size: 14px; }
    .box { color: #f4f4f6; border: 1px solid #ffffff18; box-shadow: 0 10px 40px #000a; }
    .box b { font-size: 15px; }
    .box .hint { color: #8a8a96; }
    .box button.opt { color: #f4f4f6; font-size: 14px; line-height: 1.35; }
    .box button.opt:hover:not(:disabled) { background: #ffffff1c; }
    .box button.opt.danger { color: #ff6b7a; background: #ff4d5e18; }
    .box button.opt.danger:hover:not(:disabled) { background: #ff4d5e2e; }
    .box button:disabled { opacity: .4; cursor: default; }
    .box .sec { color: #f4f4f6; }
    .box label.opt { box-sizing: border-box; width: 100%; text-align: left; background: #ffffff10; border-radius: 10px; padding: 12px; margin-bottom: 8px; font-size: 14px; line-height: 1.35; color: #f4f4f6; }
    .box label.opt:hover { background: #ffffff1c; }
    .box hr { border: 0; border-top: 1px solid #ffffff18; margin: 10px 0; }
    .qchip { position: fixed; right: 16px; bottom: 16px; z-index: 6; max-width: 330px; background: #1a1a22; border: 1px solid #ffffff25; border-radius: 12px; padding: 10px 14px; font-size: 13px; line-height: 1.45; box-shadow: 0 8px 30px #000a; } .qchip > div + div { margin-top: 6px; } .qchip .bad { color: #ff8a97; } .qchip button { background: #ffffff18; border: 1px solid #ffffff30; border-radius: 8px; padding: 3px 9px; margin-left: 2px; font-size: 12px; color: #f4f4f6; }
    .adv { margin: 10px 0 4px; border-top: 1px solid #ffffff18; padding-top: 8px; } .adv summary { cursor: pointer; color: #4db8ff; margin-bottom: 6px; } .box select { width: 100%; padding: 9px; border-radius: 10px; border: 1px solid #ffffff30; background: #0b0b10; color: #fff; margin-top: 4px; }
    .toast { position: fixed; bottom: 24px; left: 50%; translate: -50% 0; background: #fff; color: #000; padding: 10px 16px; border-radius: 10px; z-index: 2147483647; }
    .deckwrap { display: flex; gap: 56px; justify-content: center; align-items: flex-start; width: 100%; }
    .deckmain { display: flex; flex-direction: column; align-items: center; }
    .cols { width: 200px; max-height: calc(100vh - 130px); overflow: auto; display: flex; flex-direction: column; gap: 6px; padding-right: 4px; }
    .cols h4 { margin: 0 0 4px; font-size: 12px; color: #8a8a96; text-transform: uppercase; letter-spacing: .5px; }
    .chip { display: flex; justify-content: space-between; align-items: center; gap: 8px; text-align: left; background: #1a1a22;
      border: 1px solid #ffffff20; border-radius: 10px; padding: 9px 12px; font-size: 13px; }
    .chip span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .chip small { color: #8a8a96; }
    .chip.new { border-style: dashed; color: #4db8ff; }
    .chip:hover { background: #23232e; }
    .chip.hot { background: #1e3a5f; border-color: #4db8ff; transform: scale(1.04); }
    .chip.ready { box-shadow: 0 0 0 2px #4db8ff; }
    .badge { display: inline-block; min-width: 16px; padding: 0 5px; margin-left: 4px; border-radius: 9px; background: #fe2c55; color: #fff; font-size: 11px; font-weight: 700; text-align: center; }
    .selbar { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin: 0 0 10px; }
    .selbar b { margin-right: 6px; }
    .item.picked { outline: 3px solid #4db8ff; }
    .item .chk { position: absolute; top: 6px; left: 6px; font-size: 20px; background: #000a; border-radius: 6px; padding: 0 4px; }
    .item[data-sel] { cursor: pointer; }
    .sec.danger { color: #ff6b7a; border-color: #ff4d5e55; }
    .state { width: 100%; max-width: 760px; }
    .state section { background: #15151c; border: 1px solid #ffffff14; border-radius: 12px; padding: 14px 16px; margin-bottom: 12px; }
    .state h3 { margin: 0 0 8px; width: auto; max-width: none; }
    .state p { margin: 0 0 8px; }
    .state .bad { color: #ff6b7a; }
    .state .sec { margin: 4px 6px 4px 0; }
    .state .err { max-width: none; margin: 0 0 8px; }
    .log { list-style: none; padding: 0; margin: 0; max-height: 320px; overflow: auto; font-size: 13px; line-height: 1.7; }
    .log .t { color: #8a8a96; margin-right: 6px; font-variant-numeric: tabular-nums; }
    .log a { color: #4db8ff; }
    .fld { display: block; margin: 10px 0; font-size: 13px; color: #c8c8d2; }
    .fld input[type="number"] { display: block; width: 100%; margin-top: 4px; }
    .fld.chk { display: flex; gap: 8px; align-items: center; }
    .fld.chk input { width: auto; margin: 0; }
    .warn { font-size: 13px; line-height: 1.5; color: #e6c6c9; margin: 8px 0; }
    .colsearch { width: 100%; padding: 8px 10px; border-radius: 10px; border: 1px solid #ffffff25; background: #0b0b10; color: #f4f4f6; font-size: 13px; }
    .chips { display: flex; flex-direction: column; gap: 6px; }
    .chip kbd { display: inline-block; min-width: 18px; margin-right: 6px; padding: 0 4px; border-radius: 5px; background: #ffffff18; color: #b5b5c0; font: 11px system-ui; text-align: center; }
    .chip .pin { font-style: normal; color: #6a6a78; opacity: 0; margin-left: 4px; }
    .chip:hover .pin, .chip .pin.on { opacity: 1; }
    .chip .pin.on { color: #ffcf4d; }
    .nextcard { position: absolute; inset: 0; border-radius: 18px; background: #15151c center/cover; transform: scale(.94) translateY(16px); opacity: .5; filter: blur(1px); }
    iframe.pre { position: absolute; width: 1px; height: 1px; opacity: 0; pointer-events: none; border: 0; }
    .swap .tag.keep { right: auto; left: 16px; transform: rotate(-12deg); }
    .swap .tag.del { left: auto; right: 16px; transform: rotate(12deg); }
    @media (max-width: 860px) { .cols { display: none; } }
    .bar { width: 100%; max-width: 420px; height: 6px; background: #ffffff20; border-radius: 3px; overflow: hidden; margin: 10px auto; }
    .bar i { display: block; height: 100%; background: #fe2c55; }
  `;

  const EMPTY_STATE = { videos: {}, order: [], collections: [], confirmed: false };
  let S = EMPTY_STATE;
  let J = {};
  let QS = {}; // état de la file de retraits (durée moyenne par vidéo, pause de sécurité) écrit par background.js
  let tab = 'deck';
  let hist = [];
  let host, root, ov;
  let scanning = false;
  let ready = Promise.resolve();
  let syncing = false;
  let cancelOp = false; // « ✕ Stop » : les boucles longues (import, synchro) s'arrêtent à la prochaine étape
  const checkCancel = () => {
    if (cancelOp) throw new Error('Arrêté par toi.');
  };
  // Bouton « Synchroniser les collections » de l'écran de tri : libellé et état à jour sans redessiner la carte.
  const updateSyncBtn = () => {
    const b = ov?.querySelector('#deck-sync');
    if (!b) return;
    const n = pendingSync();
    b.textContent = syncing ? '⏳ Synchronisation…' : `⇄ Synchroniser les collections (${n})`;
    b.disabled = syncing || scanning || !n;
  };
  // L'import s'est-il arrêté avant la fin (page fermée en cours de route) ? Le total vient de « Publications N ».
  const importIncomplete = () => !!S.importTotal && Object.keys(S.videos).length < S.importTotal * 0.98;
  const busyChanged = () => {
    const b = ov?.querySelector('#stop');
    if (b) b.hidden = !(scanning || syncing);
    updateSyncBtn();
  };
  const busyGuard = () => {
    if (!(scanning || syncing)) return false;
    toast('Une opération est déjà en cours (import ou synchronisation). Clique sur ✕ Stop pour l’arrêter.');
    return true;
  };

  // Les données sont séparées par compte TikTok (clé « state:@pseudo »), sinon un changement de compte
  // afficherait les favoris de l'autre.
  let ACCOUNT = '';
  let legacyState = null; // données d'avant la séparation par compte (clé « state »)
  const stateKey = () => `state:${ACCOUNT}`;
  // Écritures regroupées : plusieurs sauvegardes rapprochées n'en font qu'une (l'état complet pèse plusieurs Mo).
  let saving = null;
  let dirty = false;
  const save = () => {
    dirty = true;
    saving ||= (async () => {
      try {
        while (dirty) {
          dirty = false;
          await chrome.storage.local.set({ [stateKey()]: S });
        }
      } finally {
        saving = null;
      }
    })();
    return saving;
  };

  // Réglages (globaux, pas par compte)
  const DEFAULT_SET = { grace: 15, pauseMin: 2, pauseMax: 5, workers: 3, syncDelay: 20, blockMedia: true, swap: false, riskAccepted: false, lang: 'auto', safetyPause: 20 };
  let SET = { ...DEFAULT_SET };
  const saveSettings = () => chrome.storage.local.set({ settings: SET });
  const keepSign = () => (SET.swap ? 1 : -1); // sens du glissement « garder » : -1 = vers la gauche

  // Journal des actions (les 300 dernières) : un retrait est irréversible, on garde de quoi retrouver la vidéo.
  const logAct = (a, id, name) => {
    S.log ||= [];
    S.log.unshift({ t: Date.now(), a, id, name });
    if (S.log.length > 300) S.log.length = 300;
  };

  // Collections dans l'ordre du panneau : épinglées, puis utilisées récemment, puis les autres.
  const orderedCollections = () => {
    const pin = (S.pinned || []).filter((c) => S.collections.includes(c));
    const rec = (S.recent || []).filter((c) => S.collections.includes(c) && !pin.includes(c));
    const rest = S.collections.filter((c) => !pin.includes(c) && !rec.includes(c));
    return [...pin, ...rec, ...rest];
  };
  const touchRecent = (name) => {
    S.recent = [name, ...(S.recent || []).filter((c) => c !== name)].slice(0, 30);
  };
  const profilePath = () => (document.querySelector('[data-e2e="nav-profile"]')?.getAttribute('href') || '').split(/[?#]/)[0]; // sans « ?lang=en » ni ancre
  const currentHandle = () => profilePath().replace(/^\//, '');
  const pile = () => S.order.filter((id) => S.videos[id].status === 'new');
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  function toast(text) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = text;
    root.append(t);
    setTimeout(() => t.remove(), 2800);
  }

  function addVideos(list) {
    let added = 0;
    const newer = []; // favoris plus récents que tout ce qu'on connaissait (ré-import)
    for (const v of list) {
      const known = S.videos[v.id];
      if (known) {
        // les vidéos importées avant l'ajout de la clé de vignette la récupèrent (nécessaire au rangement TikTok)
        if (!known.key && v.key) Object.assign(known, { key: v.key, thumb: known.thumb || v.thumb || '' });
        continue;
      }
      S.videos[v.id] = { id: v.id, url: v.url, thumb: v.thumb || '', key: v.key || null, status: 'new', collection: null, synced: false };
      if (v.newer) newer.push(v.id);
      else S.order.push(v.id);
      added++;
    }
    if (newer.length) {
      // Les plus récents passent juste APRÈS la carte affichée : jamais avant, car les boutons agissent sur la
      // première vidéo de la pile, qui doit rester celle qu'on a sous les yeux.
      const shownId = pile()[0];
      const at = shownId ? S.order.indexOf(shownId) + 1 : 0;
      S.order.splice(at, 0, ...newer);
    }
    return added;
  }

  // ── Utilitaires TikTok (comportements vérifiés sur le site) ──
  // Les vignettes de la liste des favoris et celles de la fenêtre « Sélectionner des vidéos » partagent la même clé
  // (nom de fichier sans signature) ; c'est le seul lien entre une case à cocher et une vidéo. Les images pas encore
  // chargées sont des data: URL, d'où le null.
  const keyOf = (src) => {
    if (!src || src.startsWith('data:')) return null;
    try {
      return new URL(src).pathname.split('~')[0].split('.')[0].split('/').pop() || null;
    } catch {
      return null;
    }
  };

  async function waitFor(fn, ms = 4000, every = 250) {
    for (const end = Date.now() + ms; Date.now() < end; ) {
      const r = fn();
      if (r) return r;
      await sleep(every);
    }
    return null;
  }

  // Certains boutons de TikTok (sous-onglets) ignorent un simple .click() : on rejoue la séquence complète.
  function realClick(el) {
    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    }
  }

  // Appelle une fonction de bridge.js (contexte de la page) et attend sa réponse.
  function bridge(fn, args = {}, timeout = 2500) {
    return new Promise((resolve) => {
      const reqId = Math.random().toString(36).slice(2);
      const done = (res) => {
        window.removeEventListener('message', onMsg);
        clearTimeout(timer);
        resolve(res);
      };
      const onMsg = (e) => {
        if (e.source === window && e.data?.tts === 'result' && e.data.reqId === reqId) done(e.data);
      };
      const timer = setTimeout(() => done({ ok: false }), timeout);
      window.addEventListener('message', onMsg);
      window.postMessage({ tts: 'call', fn, args, reqId }, '*');
    });
  }

  // Change de sous-onglet du profil : « posts » | « collections ».
  const setSubTab = async (id) => !!(await bridge('subtab', { id })).ok;

  // libellés de TikTok selon la langue du site (sous-onglets du profil)
  const SUB_RE = { Publications: '(Publications|Videos|Vidéos|Posts)', Collections: 'Collections' };
  const buttonByText =(re, root = document) => [...root.querySelectorAll('button, [role="button"]')].find((b) => re.test(b.textContent.trim()));

  // TikTok limite parfois l'accès à la liste (réponses vides) : la page affiche alors « Une erreur est survenue ». Mieux vaut
  // s'arrêter et le dire que d'insister, ce qui prolongerait la limitation.
  const tiktokError = () => /Une erreur est survenue|Something went wrong|Nous sommes désolés/.test(document.body.innerText);
  const RATE_MSG = 'TikTok limite l’accès à tes favoris en ce moment (« Une erreur est survenue »). Attends 10 à 30 minutes, recharge tiktok.com, puis relance.';
  function limited() {
    S.limitedAt = Date.now();
    save();
    return new Error(RATE_MSG);
  }

  // Ouvre Profil → Favoris → sous-onglet `sub` (« Publications » = les favoris, « Collections »).
  // Navigation interne à la page (sans rechargement), donc l'extension reste active.
  async function openMyFavorites(sub, resume) {
    const nav = document.querySelector('[data-e2e="nav-profile"]');
    const href = profilePath();
    if (!href || !href.includes('@')) throw new Error('Connecte-toi à TikTok.');
    const norm = (p) => {
      try {
        return decodeURIComponent(p).toLowerCase().replace(/\/$/, '');
      } catch {
        return p.toLowerCase();
      }
    };
    const onProfile = () => norm(location.pathname) === norm(href);
    if (!onProfile()) {
      nav.click();
      if (!(await waitFor(onProfile, 6000))) {
        // le clic interne n'a pas abouti : on recharge sur le profil, puis l'action reprend toute seule.
        // Au plus 2 rechargements d'affilée : sans ce plafond, une page qui ne s'ouvre pas relancerait l'import en boucle.
        const reloads = Number(sessionStorage.getItem('tts-reloads') || 0);
        if (reloads >= 2) throw new Error('Impossible d’ouvrir ton profil (plusieurs rechargements sans succès).');
        sessionStorage.setItem('tts-reloads', String(reloads + 1));
        sessionStorage.setItem('tts-resume', resume || '');
        location.href = href;
        await sleep(20000);
        throw new Error('Impossible d’ouvrir ton profil.');
      }
    }
    const favTab = await waitFor(() => [...document.querySelectorAll('[role="tab"]')].find((t) => /^(Favoris|Favorites|Favourites)$/.test(t.textContent.trim())), 15000);
    if (!favTab) throw new Error('Onglet « Favoris » introuvable sur ton profil.');
    favTab.click();
    // Le sous-onglet se réinitialise parfois pendant le chargement de la liste : on clique puis on vérifie
    // que le bon contenu s'affiche, sinon on recommence.
    const shown =
      sub === 'Collections'
        ? () => document.querySelector('a[href*="/collection/"]') || /Tes collections|Your collections/.test(document.body.innerText)
        : () => document.querySelector('[data-e2e="favorites-item-list"] a[href*="/video/"]');
    for (let attempt = 0; attempt < 4; attempt++) {
      const subBtn = await waitFor(() => buttonByText(new RegExp('^' + (SUB_RE[sub] || sub))), 10000);
      if (!subBtn) throw new Error(`Sous-onglet « ${sub} » introuvable.`);
      // pont vers la page (bridge.js) ; à défaut, un clic simulé (qui n'aboutit pas toujours)
      if (!(await setSubTab(sub === 'Collections' ? 'collections' : 'posts'))) realClick(subBtn);
      if (await waitFor(() => shown() || tiktokError(), 6000)) {
        if (tiktokError() && !shown()) throw limited();
        return;
      }
    }
    throw new Error(`Le sous-onglet « ${sub} » ne s’est pas ouvert.`);
  }

  // ── Import ──
  async function scanFavorites(opts = {}) {
    const full = opts.full === true; // « Tout relire » : ne pas s'arrêter aux vidéos déjà connues
    if (accountChanged() || busyGuard()) return;
    if (!(await riskGate())) return;
    cancelOp = false;
    scanning = true;
    busyChanged();
    try {
      await openMyFavorites('Publications', 'scan');
      await waitFor(() => document.querySelector('[data-e2e="favorites-item-list"] a[href*="/video/"]'), 10000);
      const SEL = '[data-e2e="favorites-item-list"] a[href*="/video/"]';
      const found = new Map();
      const status = (t) => {
        const s = ov.querySelector('#scan-status');
        if (s) s.textContent = t;
      };
      // Les vidéos sont ajoutées par paquets pendant le défilement : on peut commencer à trier tout de suite.
      let flushed = 0;
      const flush = async () => {
        const wasEmpty = !pile().length;
        addVideos([...found.values()].slice(flushed));
        flushed = found.size;
        await save();
        if (tab !== 'deck') return;
        if (wasEmpty && pile().length) return renderBody();
        const c = ov.querySelector('.count');
        const bar = ov.querySelector('.bar i');
        const n = pile().length;
        if (c) c.textContent = `${n} à trier`;
        if (bar) bar.style.width = `${((S.order.length - n) / S.order.length) * 100}%`;
      };

      // Le total annoncé par TikTok (« Publications 5000 ») sert de but et de barre de progression.
      const parseCount = (t) => {
        const m = String(t || '').match(/([\d.,]+)\s*([KkMm])?/);
        if (!m) return 0;
        const n = parseFloat(m[1].replace(',', '.'));
        return Math.round(n * ({ k: 1e3, m: 1e6 }[(m[2] || '').toLowerCase()] || 1));
      };
      const readTotal = () => parseCount(buttonByText(/^(Publications|Videos|Vidéos|Posts)/)?.textContent.replace(/^(Publications|Videos|Vidéos|Posts)/, ''));
      let total = readTotal();

      let domCount = 0;
      let stalls = 0;
      // Le total annoncé n'est qu'un repère : des favoris ont pu être ajoutés entre-temps. Une fois atteint, on ne
      // s'arrête qu'après 2 passages sans nouveauté (« settled »), et non dès qu'on l'atteint.
      let settled = 0;
      const hadBefore = S.order.length > 0; // ré-import : les favoris plus récents que tout ce qu'on connaît sont « newer »
      let sawKnown = false;
      // Ré-import court : les nouveaux favoris sont tout en haut ; dès qu'on croise 40 vidéos déjà connues d'affilée, on s'arrête.
      const short = hadBefore && !full && !importIncomplete();
      let knownRun = 0;
      // Moins d'une page de vidéos : la liste est entière, inutile d'attendre longtemps la suite (le total annoncé par TikTok
      // compte parfois des vidéos supprimées ou privées qu'on ne verra jamais).
      while (stalls < (found.size < 25 ? 2 : 6) && settled < 2) {
        checkCancel();
        total = Math.max(total, readTotal()); // le compteur de TikTok se met à jour après le chargement
        if (total) S.importTotal = total; // mémorisé : permet de proposer « Reprendre l’import » si la page est fermée
        const anchors = document.querySelectorAll(SEL);
        for (let i = domCount; i < anchors.length; i++) {
          const a = anchors[i];
          const m = a.href.match(/\/video\/(\d{8,})/);
          const img = a.querySelector('img')?.src || '';
          if (m) {
            if (S.videos[m[1]]) {
              sawKnown = true;
              knownRun++;
            } else knownRun = 0;
          }
          if (m && !found.has(m[1])) {
            found.set(m[1], { id: m[1], url: a.href.split('?')[0], thumb: img, key: keyOf(img), newer: hadBefore && !sawKnown });
          }
        }
        domCount = anchors.length;
        if (short && knownRun >= 40) break; // on a rejoint ce qu'on connaît déjà : la suite est identique
        status(`Import : ${found.size}${total ? ` / ${total}` : ''}…`);
        if (found.size - flushed >= 150) await flush();
        // on défile, puis on repart dès que de nouvelles vidéos apparaissent (au lieu d'une pause fixe)
        if (tiktokError()) {
          await flush(); // on garde ce qui a déjà été lu
          throw limited();
        }
        // rythme humain : une pause aléatoire entre deux pages (un défilement instantané en continu peut déclencher la limitation)
        await sleep(350 + Math.random() * 450);
        anchors[anchors.length - 1]?.scrollIntoView({ block: 'end' });
        window.scrollTo(0, document.documentElement.scrollHeight);
        const atTotal = total && found.size >= total;
        let grew = await waitFor(() => document.querySelectorAll(SEL).length > domCount, atTotal ? 2500 : 5000, 100);
        if (!grew) {
          // TikTok charge parfois la suite seulement après un mouvement : on remonte un peu puis on redescend
          window.scrollBy(0, -600);
          await sleep(400);
          window.scrollTo(0, document.documentElement.scrollHeight);
          grew = await waitFor(() => document.querySelectorAll(SEL).length > domCount, atTotal ? 2500 : 5000, 100);
        }
        stalls = grew ? 0 : stalls + 1;
        settled = atTotal && !grew ? settled + 1 : 0;
      }
      await flush();
      status('');
      S.lastImport = Date.now();
      delete S.limitedAt; // la lecture est allée au bout : TikTok ne limite plus
      await save();
      // Le total annoncé par TikTok compte parfois des vidéos supprimées ou privées : si l'écart est petit et que la liste
      // ne grandit plus, l'import est terminé (sinon « Reprendre l'import (3 / 5) » resterait affiché pour toujours).
      const gap = total - Object.keys(S.videos).length;
      const missing = total && gap > 0;
      if (missing && gap <= 10) {
        S.importTotal = Object.keys(S.videos).length;
        await save();
      }
      try {
        const r = await importCollections();
        toast(`${found.size} favoris lus, ${r.names} collections (${r.placed} vidéos déjà rangées)`);
      } catch (e) {
        toast('Collections non lues : ' + e.message);
      }
      if (missing && gap > 10) toast(`${found.size} favoris lus sur ${total} : relance l’import pour continuer`);
      else if (missing) toast(`${Object.keys(S.videos).length} favoris lus (TikTok en annonce ${total} : certaines vidéos ne sont plus disponibles)`);
    } catch (e) {
      toast(e.message);
    } finally {
      scanning = false;
      sessionStorage.removeItem('tts-reloads'); // l'opération est allée au bout : on remet le plafond de rechargements à zéro
      busyChanged();
      render();
    }
  }

  // ── Collections déjà présentes sur TikTok ──
  // Leurs noms alimentent le choix de collection, et les vidéos qu'elles contiennent (reconnues par la clé de
  // vignette) sortent de la pile à trier : elles sont déjà rangées.
  const scanStatus = (t) => {
    const s = ov.querySelector('#scan-status');
    if (s) s.textContent = t;
  };

  // Identifiants des vidéos d'une collection, lus dans les données de la page (bridge.js). Les vidéos s'affichent par
  // pages : on défile jusqu'au nombre annoncé, ou jusqu'à ce que la liste ne grandisse plus.
  async function readCollectionIds(collectionId, expected) {
    let ids = [];
    let lastGrowth = Date.now();
    const start = Date.now();
    while (Date.now() - start < 40000) {
      checkCancel();
      const res = await bridge('ids', { collectionId });
      const now = (res.data || []).filter(Boolean);
      if (now.length > ids.length) lastGrowth = Date.now();
      ids = now;
      if (expected && ids.length >= expected && Date.now() - lastGrowth > 1500) break; // attendre une fournée de plus : des vidéos ont pu être ajoutées
      // la page met plusieurs secondes à afficher la 1re fournée ; ensuite, 2 s sans nouveauté = c'est fini
      if (ids.length ? Date.now() - lastGrowth > 2000 : Date.now() - start > 20000) break;
      document.querySelector('[data-e2e="collection-item-list"] [data-e2e="collection-item"]:last-child')?.scrollIntoView({ block: 'end' });
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(400);
    }
    return ids;
  }

  async function importCollections(opts = {}) {
    const full = !!opts.full; // relecture complète : ignore le « nombre de vidéos inchangé »
    const listReady = () => document.querySelector('a[href*="/collection/"]') || /Tes collections|Your collections/.test(document.body.innerText);
    const firstLine = (a) => a.innerText.trim().split('\n')[0].trim();
    const linkEls = () => [...document.querySelectorAll('a[href*="/collection/"]')];
    // On défile la liste jusqu'à ce qu'elle ne grandisse plus : le total annoncé (« Collections 26 ») n'est qu'un repère,
    // des collections ont pu être ajoutées entre-temps. TikTok n'en affiche qu'une partie à la fois (19 sur 26 par ex.).
    const loadList = async () => {
      await waitFor(listReady, 8000);
      for (let stalls = 0; stalls < 3; ) {
        checkCancel();
        const n = linkEls().length;
        const total = Number((buttonByText(/^Collections/)?.textContent.match(/\d+/) || [])[0]) || 0;
        if (total && n >= total && stalls >= 1) break; // total atteint, confirmé par un passage sans nouveauté
        linkEls().at(-1)?.scrollIntoView({ block: 'end' });
        window.scrollTo(0, document.documentElement.scrollHeight);
        await sleep(800);
        stalls = linkEls().length > n ? 0 : stalls + 1;
      }
      return [...new Map(linkEls().map((a) => [a.getAttribute('href'), a])).values()]
        .map((a) => ({
          name: firstLine(a),
          href: a.getAttribute('href'),
          id: (a.getAttribute('href').match(/(\d+)\/?$/) || [])[1],
          expected: Number((a.innerText.match(/(\d+)\s+(?:vidéo|video)/) || [])[1]) || 0,
        }))
        .filter((c) => c.name && c.id);
    };

    await openMyFavorites('Collections', 'collections');
    let cols = await loadList();
    const seen = new Set();
    let placed = 0;
    let skipped = 0;
    // Plusieurs passages : après avoir lu les collections connues, on relit la liste pour visiter celles apparues entre-temps.
    for (let pass = 0; pass < 3; pass++) {
      const todo = cols.filter((c) => !seen.has(c.href));
      if (!todo.length) break;
      for (const c of todo) {
        if (!S.collections.includes(c.name)) S.collections.push(c.name);
        S.colInfo[c.name] = { href: c.href, id: c.id }; // mémorisé : permet de rouvrir la collection directement, sans repasser par Profil → Favoris → Collections
      }
      await save();
      if (tab === 'deck') renderBody(); // les noms sont déjà utilisables dans le panneau

      for (const c of todo) {
        checkCancel();
        seen.add(c.href);
        // Une collection dont le nombre de vidéos n'a pas changé depuis la dernière lecture n'est pas rouverte (gros gain de temps).
        if (!full && S.colCounts[c.name] === c.expected) {
          skipped++;
          continue;
        }
        // Collection vide côté TikTok : rien à lire (et inutile d'attendre) ; ce qu'on croyait y avoir rangé n'y est pas.
        if (c.expected === 0) {
          for (const v of Object.values(S.videos)) if (v.collection === c.name && v.status === 'kept' && v.synced) v.synced = false;
          S.colCounts[c.name] = 0;
          await save();
          continue;
        }
        scanStatus(`Collection ${seen.size}/${cols.length} : « ${c.name} »`);
        history.pushState({}, '', c.href);
        window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
        const ids = await readCollectionIds(c.id, c.expected);
        const shown = pile()[0]; // la carte affichée en ce moment n'est jamais déplacée sous les doigts
        for (const id of ids) {
          const v = S.videos[id];
          // on ne touche ni aux vidéos déjà retirées ni à celles que tu as déjà rangées ailleurs
          if (v && id !== shown && (v.status === 'new' || (v.status === 'kept' && !v.collection))) {
            Object.assign(v, { status: 'kept', collection: c.name, synced: true });
            placed++;
          }
        }
        // rapprochement avec TikTok : ce qui s'y trouve est « synchronisé » ; ce qui était marqué synchronisé mais n'y est
        // pas (lecture complète seulement) sera renvoyé à la prochaine synchronisation.
        const inCol = new Set(ids);
        const complete = ids.length >= Math.max(1, Math.floor(c.expected * 0.9));
        for (const v of Object.values(S.videos)) {
          if (v.collection !== c.name || v.status !== 'kept') continue;
          if (inCol.has(v.id)) v.synced = true;
          else if (complete && v.synced && v.id !== shown) v.synced = false;
        }
        if (complete) S.colCounts[c.name] = c.expected; // lue en entier : la prochaine fois, on peut l'ignorer si rien n'a changé
        await save();
      }
      scanStatus('Recherche de nouvelles collections…');
      await openMyFavorites('Collections', 'collections');
      cols = await loadList();
    }
    scanStatus('');
    return { names: seen.size, placed, skipped };
  }

  async function refreshCollections(opts = {}) {
    if (accountChanged() || busyGuard()) return;
    if (!(await riskGate())) return;
    cancelOp = false;
    scanning = true;
    busyChanged();
    try {
      const r = await importCollections({ full: !!opts.full });
      toast(`${r.names} collections vues (${r.skipped} inchangée(s) ignorée(s)), ${r.placed} vidéos déjà rangées`);
    } catch (e) {
      toast(e.message);
    } finally {
      scanning = false;
      sessionStorage.removeItem('tts-reloads'); // l'opération est allée au bout : on remet le plafond de rechargements à zéro
      busyChanged();
      render();
    }
  }

  // ── Rangement dans les collections TikTok (ajouts et retraits) ──
  // Flux vérifié sur le site :
  //  - ajout : « Créer une nouvelle collection » (nom → Suivant) ou, pour une collection existante, sa page →
  //    « Ajouter des vidéos » ; une fenêtre liste alors les favoris avec une case chacun (jusqu'à ~15 s à s'ouvrir
  //    avec des milliers de favoris) ;
  //  - retrait : page de la collection → « Gérer les vidéos » → cases → « Supprimer (N) » → confirmation
  //    (« Tes vidéos seront toujours enregistrées dans les Favoris »).
  // La fenêtre s'affiche tout de suite avec son titre ; les vidéos n'arrivent que quelques secondes plus tard.
  const findSelectDialog = () =>
    [...document.querySelectorAll('[role="dialog"]')].find((d) => /Sélectionner des vidéos|Select videos/i.test(d.innerText) || d.querySelector('[data-e2e="collection-item"]'));
  const dialogsInfo = () =>
    [...document.querySelectorAll('[role="dialog"]')]
      .filter((d) => d.getAttribute('aria-label') !== 'Notifications')
      .map((d) => d.innerText.split('\n')[0].slice(0, 40))
      .join(' | ') || 'aucune fenêtre';
  const LIST_ITEM = '[data-e2e="collection-item-list"] [data-e2e="collection-item"]';

  // Charge toutes les cartes de la liste des collections (TikTok n'en affiche qu'une partie à la fois).
  async function loadAllCollectionLinks() {
    const linkEls = () => [...document.querySelectorAll('a[href*="/collection/"]')];
    await waitFor(() => linkEls().length || /Tes collections|Your collections/.test(document.body.innerText), 10000);
    const total = Number((buttonByText(/^Collections/)?.textContent.match(/\d+/) || [])[0]) || 0;
    for (let stalls = 0; stalls < 3 && linkEls().length < total; ) {
      const n = linkEls().length;
      linkEls().at(-1)?.scrollIntoView({ block: 'end' });
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(800);
      stalls = linkEls().length > n ? 0 : stalls + 1;
    }
    return linkEls();
  }

  // Ouvre la page d'une collection existante ; null si elle n'existe pas.
  async function openCollection(name) {
    // Voie rapide : navigation interne de la page vers l'adresse mémorisée de la collection. On évite ainsi de repasser
    // par Profil → Favoris → Collections → (défilement de la liste) pour chaque collection, soit 10 à 15 s économisées.
    const info = S.colInfo?.[name];
    if (info) {
      history.pushState({}, '', info.href);
      window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
      // Juste après la navigation, le contenu de l'ANCIENNE page (et son bouton « Ajouter ») reste affiché un instant : on
      // n'agit que quand toutes les vidéos affichées appartiennent bien à la collection visée (vérifié sur le vrai site).
      const t0 = Date.now();
      let ready = false;
      while (Date.now() - t0 < 12000) {
        const add = document.querySelector('[data-e2e="collection-action-add"]');
        const data = (await bridge('ids', { collectionId: info.id })).data || [];
        const mine = data.filter(Boolean).length;
        if (add && data.length > 0 && mine === data.length) ready = true; // les vidéos affichées sont celles de la bonne collection
        else if (add && data.length === 0 && Date.now() - t0 > 1500) ready = true; // collection vide (rien à comparer) : on laisse la page se poser
        if (ready) break;
        await sleep(150);
      }
      if (ready) return { colId: info.id };
      delete S.colInfo[name]; // adresse périmée (collection renommée ou supprimée) : on la retrouvera par la liste
    }
    await openMyFavorites('Collections', 'sync');
    const link = (await loadAllCollectionLinks()).find((a) => a.innerText.trim().split('\n')[0].trim().toLowerCase() === name.toLowerCase());
    if (!link) return null;
    link.click();
    if (!(await waitFor(() => document.querySelector('[data-e2e="collection-action-add"]'), 25000))) {
      throw new Error(`Page de la collection « ${name} » introuvable.`);
    }
    const href = link.getAttribute('href');
    const colId = (href.match(/(\d+)\/?$/) || [])[1];
    S.colInfo[name] = { href, id: colId };
    return { colId };
  }

  // La croix est le DERNIER bouton sans texte de la fenêtre (le premier est la flèche « retour » à l'étape 2).
  const closeDialog = (dlg) => [...dlg.querySelectorAll('button')].filter((b) => !b.textContent.trim()).at(-1)?.click();

  // Message de refus affiché par TikTok sous le champ du nom (ex. « Ce nom est inapproprié. Réessaie. »).
  const nameError = () => {
    const d = [...document.querySelectorAll('[role="dialog"]')].find((x) => /Nouvelle collection|New collection/i.test(x.innerText));
    return d?.innerText.split('\n').find((l) => /inappropri|invalid|already|exist|try again|invalide|déjà|existe|réessaie/i.test(l)) || '';
  };

  // Coche dans la fenêtre « Sélectionner des vidéos » les vidéos voulues (reconnues par leur identifiant, lu par
  // bridge.js). La liste ne charge la suite que si on fait défiler SON conteneur interne (vérifié : scrollIntoView
  // ne suffit pas, elle restait bloquée à 28 vidéos ; scrollTop = scrollHeight en charge ~20 par seconde).
  async function fillModal(wanted) {
    const ITEM = '[role="dialog"] [data-e2e="collection-item"]';
    // les vidéos apparaissent plusieurs secondes après la fenêtre (jusqu'à ~40 s avec une page chargée)
    await waitFor(() => document.querySelector(ITEM), 40000);
    const scroller = () => {
      for (let el = document.querySelector(ITEM)?.parentElement; el && el !== document.body; el = el.parentElement) {
        if (el.scrollHeight > el.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(el).overflowY)) return el;
      }
      return null;
    };
    const picked = new Set();
    let scanned = 0;
    let stalls = 0;
    while (picked.size < wanted.size && stalls < 6 && scanned < 2500) { // au-delà, la recherche prendrait trop de temps
      checkCancel();
      const items = [...document.querySelectorAll(ITEM)];
      const ids = (await bridge('modalIds')).data || [];
      for (let i = scanned; i < items.length; i++) {
        const id = ids[i];
        if (id && wanted.has(id) && !picked.has(id)) {
          items[i].querySelector('input[type="checkbox"]')?.click();
          picked.add(id);
        }
      }
      scanned = items.length;
      if (picked.size >= wanted.size) break;
      const box = scroller();
      if (box) {
        box.scrollTop = box.scrollHeight;
        // l'événement « scroll » naturel n'arrive pas si la page ne s'affiche pas (onglet en arrière-plan) : on l'émet
        box.dispatchEvent(new Event('scroll', { bubbles: true }));
      } else items.at(-1)?.scrollIntoView({ block: 'end' });
      const grew = await waitFor(() => document.querySelectorAll(ITEM).length > scanned, 6000);
      stalls = grew ? 0 : stalls + 1;
    }
    return picked;
  }

  // Attend que TOUTES les vidéos `wanted` soient dans la collection (ou, avec gone:true, qu'aucune n'y soit plus). On sort
  // dès que c'est vrai (souvent en 1 s), au lieu d'attendre que la liste « se stabilise » ; on défile un peu à chaque tour
  // car une collection de plus de 50 vidéos n'affiche que la première page.
  async function waitForIds(collectionId, wanted, { gone = false, timeout = 15000 } = {}) {
    const start = Date.now();
    let seen = new Set();
    while (Date.now() - start < timeout) {
      const data = (await bridge('ids', { collectionId })).data || [];
      seen = new Set(data.filter(Boolean));
      const ok = gone ? [...wanted].every((id) => !seen.has(id)) : [...wanted].every((id) => seen.has(id));
      if (ok) break;
      document.querySelector(`${LIST_ITEM}:last-child`)?.scrollIntoView({ block: 'end' });
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(250);
    }
    return seen;
  }

  async function addToCollection(name, vids) {
    const wanted = new Map(vids.map((v) => [v.id, v]));
    const col = await openCollection(name);
    let dlg;
    if (col) {
      // le clic ne prend pas toujours si la page n'est pas encore prête : on réessaie
      for (const wait of [40000, 20000, 20000]) {
        document.querySelector('[data-e2e="collection-action-add"]')?.click();
        dlg = await waitFor(findSelectDialog, wait);
        if (dlg) break;
      }
    } else {
      const create = document.querySelector('[data-e2e="collection-action-create"]');
      if (!create) throw new Error('Bouton « Créer une nouvelle collection » introuvable.');
      create.click();
      const input = await waitFor(() => document.querySelector('input.TUXTextInputCore-input'), 8000);
      if (!input) throw new Error('Champ du nom de collection introuvable.');
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, name);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(700);
      const refused = () => {
        const msg = nameError();
        if (!msg) return null;
        [...document.querySelectorAll('[role="dialog"]')].filter((x) => /Nouvelle collection|New collection/i.test(x.innerText)).forEach(closeDialog);
        return new Error(`TikTok refuse le nom « ${name} » : ${msg.trim()} Renomme la collection (✎).`);
      };
      const early = refused();
      if (early) throw early;
      const next = buttonByText(/^(Suivant|Next)$/);
      if (!next) throw new Error('Bouton « Suivant » introuvable.');
      next.click();
      // soit la fenêtre de sélection arrive, soit TikTok affiche un refus sous le champ du nom
      dlg = await waitFor(() => findSelectDialog() || nameError(), 60000);
      if (typeof dlg === 'string') throw refused() || new Error(`TikTok refuse le nom « ${name} » : ${dlg.trim()}`);
    }
    if (!dlg) {
      throw new Error(`Fenêtre de sélection introuvable pour « ${name} » (${col ? 'collection existante' : 'nouvelle collection'} ; à l'écran : ${dialogsInfo()}).`);
    }

    const picked = await fillModal(wanted);
    const confirmBtn = buttonByText(/^(Ajouter des vidéos|Terminé|Add videos|Done)/, dlg);
    if (!picked.size || !confirmBtn || confirmBtn.disabled) {
      closeDialog(dlg);
      return { done: [], missed: vids.length };
    }
    // garde-fou : le compteur du bouton doit refléter ce qu'on a coché
    const count = Number((confirmBtn.textContent.match(/\((\d+)\)/) || [])[1]);
    if (count !== picked.size) {
      closeDialog(dlg);
      throw new Error(`Sélection incohérente pour « ${name} » (${count} ≠ ${picked.size}).`);
    }
    confirmBtn.click();
    // TikTok referme la fenêtre puis affiche la collection : on vérifie que les vidéos y sont VRAIMENT avant de les
    // marquer « synchronisées » (un clic qui ne prend pas ne doit pas passer pour un succès).
    await waitFor(() => !findSelectDialog(), 15000);
    const colId = col?.colId || (await waitFor(() => (location.pathname.match(/\/collection\/.*?(\d+)\/?$/) || [])[1], 20000));
    let confirmed = [...picked];
    if (colId) {
      const inCol = await waitForIds(colId, new Set(picked));
      confirmed = confirmed.filter((id) => inCol.has(id));
    }
    return { done: confirmed.map((id) => wanted.get(id)), missed: vids.length - confirmed.length };
  }

  async function removeFromCollection(name, vids) {
    const wanted = new Map(vids.map((v) => [v.id, v]));
    const col = await openCollection(name);
    if (!col) return { done: vids, missed: 0 }; // la collection n'existe plus : rien à retirer
    // attendre que la 1re fournée de vidéos soit affichée
    const loaded = await (async () => {
      for (const end = Date.now() + 25000; Date.now() < end; ) {
        if (((await bridge('ids', { collectionId: col.colId })).data || []).some(Boolean)) return true;
        await sleep(400);
      }
      return false;
    })();
    if (!loaded) return { done: [], missed: vids.length };

    document.querySelector('[data-e2e="collection-action-manage"]')?.click();
    if (!(await waitFor(() => document.querySelector('[data-e2e="collection-manage-header"]'), 8000))) {
      throw new Error(`Mode « Gérer les vidéos » introuvable pour « ${name} ».`);
    }
    const picked = new Set();
    let stalls = 0;
    let lastCount = 0;
    while (picked.size < wanted.size && stalls < 4) {
      checkCancel();
      const items = [...document.querySelectorAll(LIST_ITEM)];
      const ids = (await bridge('ids', { collectionId: col.colId })).data || [];
      let progress = items.length > lastCount;
      lastCount = items.length;
      items.forEach((it, i) => {
        const id = ids[i];
        const box = it.querySelector('input[type="checkbox"]');
        if (id && box && wanted.has(id) && !picked.has(id)) {
          box.click();
          picked.add(id);
          progress = true;
        }
      });
      items.at(-1)?.scrollIntoView({ block: 'end' });
      await sleep(900);
      stalls = progress ? 0 : stalls + 1;
    }
    const cancel = () => buttonByText(/^(Annuler|Cancel)$/)?.click();
    if (!picked.size) {
      cancel();
      return { done: [], missed: vids.length };
    }
    const del = await waitFor(() => buttonByText(/^(Supprimer|Delete|Remove) \(\d+\)/), 5000);
    if (!del) {
      cancel();
      throw new Error('Bouton « Supprimer » introuvable dans « Gérer les vidéos ».');
    }
    del.click();
    // la confirmation doit parler de VIDÉOS d'une collection (et non de la suppression de la collection entière)
    const dlg = await waitFor(
      () => [...document.querySelectorAll('[role="dialog"]')].find((d) => /vidéo|video/i.test(d.innerText) && /collection|Favoris|Favorites/i.test(d.innerText) && buttonByText(/^(Supprimer|Delete|Remove)$/, d)),
      8000,
    );
    if (!dlg) {
      cancel();
      throw new Error('Confirmation de retrait introuvable.');
    }
    buttonByText(/^(Supprimer|Delete|Remove)$/, dlg).click();
    const remaining = await waitForIds(col.colId, new Set(picked), { gone: true, timeout: 12000 });
    for (const id of [...picked]) if (remaining.has(id)) picked.delete(id); // pas retirée : on ne la déclare pas retirée
    return { done: [...picked].map((id) => wanted.get(id)), missed: vids.length - picked.size };
  }

  // Synchronisation automatique : quelques secondes après le dernier rangement, on l'envoie à TikTok.
  let syncTimer = null;
  const pendingSync = () =>
    Object.values(S.videos).filter((v) => v.removeFrom || (v.status === 'kept' && v.collection && !v.synced)).length;
  // Les rangements sont envoyés en un seul lot après un moment d'inactivité (réglage), ou tout de suite dès 10 en attente :
  // chaque ouverture de la fenêtre de sélection de TikTok coûte 10 à 15 s, autant la partager entre plusieurs vidéos.
  function scheduleSync(ms) {
    if (ms === undefined) ms = pendingSync() >= 10 ? 2000 : SET.syncDelay * 1000;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      if (scanning || syncing) return scheduleSync(5000);
      if (workLeft()) syncCollections({ auto: true });
    }, ms);
  }

  // Ferme d'éventuelles fenêtres restées ouvertes après une erreur (hors notifications).
  const closeStrayDialogs = () =>
    [...document.querySelectorAll('[role="dialog"]')].filter((d) => d.getAttribute('aria-label') !== 'Notifications').forEach(closeDialog);

  const workLeft = () =>
    Object.values(S.videos).filter(
      (v) => (v.removeFrom && !S.errors?.[v.removeFrom]) || (v.status === 'kept' && v.collection && !v.synced && !S.errors?.[v.collection]),
    ).length;

  async function syncCollections({ auto = false } = {}) {
    if (accountChanged()) return;
    if (syncing || scanning) {
      if (!auto) busyGuard();
      return;
    }
    // pas de synchronisation automatique tant que l'avertissement n'a pas été accepté ; en manuel, on le présente
    if (auto ? !SET.riskAccepted : !(await riskGate())) return;
    cancelOp = false;
    if (!auto) S.errors = {}; // « Synchroniser maintenant » retente aussi les collections en erreur
    S.errors ||= {};
    const adds = {};
    const removals = {};
    for (const id of S.order) {
      const v = S.videos[id];
      if (v.removeFrom && !S.errors[v.removeFrom]) (removals[v.removeFrom] ||= []).push(v);
      if (v.status === 'kept' && v.collection && !v.synced && !S.errors[v.collection]) (adds[v.collection] ||= []).push(v);
    }
    if (!Object.keys(adds).length && !Object.keys(removals).length) {
      if (auto) return;
      // rien en attente d'après l'extension : on vérifie auprès de TikTok (une vidéo marquée rangée peut ne pas l'être)
      toast('Rien en attente. Vérification auprès de TikTok…');
      await refreshCollections();
      if (workLeft()) syncCollections();
      return;
    }
    // Une page TikTok chargée de milliers de favoris (après l'import) devient très lente : la fenêtre de sélection
    // met alors une éternité à s'ouvrir. On repart d'une page neuve, puis la synchronisation reprend toute seule.
    const profileHref = profilePath();
    if (profileHref && document.getElementsByTagName('*').length > 12000 && !sessionStorage.getItem('tts-fresh')) {
      sessionStorage.setItem('tts-fresh', '1');
      sessionStorage.setItem('tts-resume', auto ? 'sync-auto' : 'sync');
      location.href = profileHref;
      return;
    }
    syncing = true;
    busyChanged();
    if (tab === 'cols') renderBody();
    let progress = 0;
    let missed = 0;
    let failed = 0;
    // une erreur sur une collection est mémorisée (et affichée dans l'onglet Collections) sans bloquer les autres
    const run = async (name, work, apply) => {
      try {
        closeStrayDialogs();
        const r = await work();
        for (const v of r.done) apply(S.videos[v.id]);
        progress += r.done.length;
        missed += r.missed;
        delete S.errors[name];
        delete S.colCounts[name]; // la collection a changé côté TikTok : à relire la prochaine fois
      } catch (e) {
        closeStrayDialogs();
        if (!cancelOp) {
          failed++;
          S.errors[name] = e.message;
        }
      }
      await save();
      if (tab === 'cols') renderBody();
    };
    try {
      for (const [name, vids] of Object.entries(removals)) {
        if (cancelOp) break;
        scanStatus(`Retrait de « ${name} »…`);
        await run(name, () => removeFromCollection(name, vids), (v) => delete v.removeFrom);
      }
      for (const [name, vids] of Object.entries(adds)) {
        if (cancelOp) break;
        scanStatus(`Rangement dans « ${name} »…`);
        await run(name, () => addToCollection(name, vids), (v) => (v.synced = true));
      }
      if (cancelOp) toast("Synchronisation arrêtée.");
      else if (!auto || missed || failed) {
        toast(
          failed
            ? `${progress} synchronisées, ${failed} collection(s) en erreur (voir l’onglet Collections)`
            : missed
              ? `${progress} synchronisées, ${missed} introuvables dans la liste TikTok`
              : `${progress} vidéos synchronisées avec TikTok`,
        );
      }
    } finally {
      syncing = false;
      sessionStorage.removeItem('tts-reloads'); // l'opération est allée au bout : on remet le plafond de rechargements à zéro
      busyChanged();
      sessionStorage.removeItem('tts-fresh');
      scanStatus('');
      await save();
      if (tab === 'cols') renderBody();
      if (progress && workLeft()) scheduleSync(3000); // des rangements sont arrivés pendant la synchro
    }
  }

  function importFile(file) {
    const reader = new FileReader();
    reader.onload = async () => {
      const found = new Map();
      for (const m of String(reader.result).matchAll(/https?:[^\s"'\\]*?\/video\/(\d{8,})[^\s"'\\]*/g)) {
        if (!found.has(m[1])) found.set(m[1], { id: m[1], url: m[0].split('?')[0] });
      }
      const n = addVideos([...found.values()]);
      await save();
      toast(`${n} vidéos importées`);
      render();
    };
    reader.readAsText(file);
  }

  // ── Actions de tri ──
  const delConfirmText = () =>
    `Les vidéos glissées à ${SET.swap ? 'gauche' : 'droite'} seront RETIRÉES de tes favoris TikTok (automatiquement, en arrière-plan). Continuer ?`;

  async function act(kind, collection) {
    if (accountChanged()) return false;
    const id = pile()[0];
    if (!id) return false;
    const v = S.videos[id];
    if (kind === 'del' && !(await riskGate())) return false;
    hist.push({ id, status: v.status, collection: v.collection });
    if (kind === 'keep') {
      v.status = 'kept';
      logAct('keep', id);
    }
    if (kind === 'col') {
      Object.assign(v, { status: 'kept', collection, synced: false });
      touchRecent(collection);
      logAct('col', id, collection);
      scheduleSync(); // envoyé à TikTok quelques secondes plus tard, sans action de ta part
    }
    if (kind === 'del') {
      v.status = 'deleted';
      logAct('del', id);
      const r = await send({ type: 'enqueue', items: [{ id, url: v.url, account: ACCOUNT }] });
      if (r?.rejected?.includes(id)) {
        // quota gratuit atteint : la vidéo reste dans la pile, rien n'est retiré
        v.status = 'new';
        hist.pop();
        S.log.shift();
        upsell('limit');
        refreshPlan();
        await save();
        renderBody();
        return false;
      }
      refreshPlan();
      showUndoBar(id);
    }
    await save();
    renderBody();
    return true;
  }

  // Bandeau « Annuler » avec compte à rebours : un retrait part vraiment après le délai de grâce (réglage).
  let undoTimer = null;
  function showUndoBar(id) {
    clearInterval(undoTimer);
    const until = Date.now() + SET.grace * 1000;
    let bar = ov.querySelector('#undo-bar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'undo-bar';
      bar.className = 'undobar';
      ov.append(bar);
    }
    const paint = () => {
      const left = Math.ceil((until - Date.now()) / 1000);
      if (left <= 0) {
        clearInterval(undoTimer);
        bar.remove();
        return;
      }
      bar.innerHTML = `🗑 Retirée de tes favoris <button data-undo="${id}">↺ Annuler (${left} s)</button>`;
    };
    paint();
    undoTimer = setInterval(paint, 500);
    bar.onclick = (e) => {
      if (!e.target.dataset.undo) return;
      clearInterval(undoTimer);
      bar.remove();
      undoDelete(e.target.dataset.undo);
    };
  }

  async function undoDelete(id) {
    const r = await send({ type: 'cancel', id });
    if (!r?.ok) return toast('Déjà parti : impossible d’annuler.');
    S.videos[id].status = 'new';
    S.order = [id, ...S.order.filter((x) => x !== id)];
    hist = hist.filter((h) => h.id !== id);
    logAct('undo', id);
    await save();
    renderBody();
  }
  async function undo() {
    const h = hist.pop();
    if (!h) return toast('Rien à annuler');
    const v = S.videos[h.id];
    if (v.status === 'deleted') {
      const r = await send({ type: 'cancel', id: h.id });
      if (!r?.ok) {
        toast('Déjà retiré de TikTok, impossible d’annuler');
        return;
      }
    }
    if (v.collection && v.synced) v.removeFrom = v.collection; // l'annulation retire aussi la vidéo de la collection TikTok
    logAct('undo', h.id);
    Object.assign(v, { status: h.status, collection: h.collection, synced: false });
    scheduleSync();
    // remet la vidéo en tête de pile
    S.order = [h.id, ...S.order.filter((x) => x !== h.id)];
    await save();
    renderBody();
  }

  function pickCollection() {
    return new Promise((resolve) => {
      const m = document.createElement('div');
      m.className = 'modal';
      m.innerHTML = `<div class="box"><b>Ranger dans une collection</b><div style="height:10px"></div>
        ${S.collections.map((c, i) => `<button class="opt" data-i="${i}">📁 ${esc(c)}</button>`).join('')}
        <input placeholder="Nouvelle collection…" maxlength="40"><button class="pri" style="margin:6px 0 0">Créer et ranger</button>
        <button class="sec" style="margin:6px 0 0">Annuler</button></div>`;
      const done = (val) => { m.remove(); resolve(val); };
      m.addEventListener('click', (e) => {
        const t = e.target;
        if (t === m || t.classList.contains('sec')) return done(null);
        if (t.dataset.i) return done(S.collections[+t.dataset.i]);
        if (t.classList.contains('pri')) {
          const name = m.querySelector('input').value.trim();
          if (!name) return;
          if (!S.collections.includes(name)) S.collections.push(name);
          done(name);
        }
      });
      m.querySelector('input').addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') m.querySelector('.pri').click();
      });
      root.append(m);
    });
  }

  async function doCollection() {
    const name = await pickCollection();
    if (!name) return false;
    return act('col', name);
  }

  // ── Rendu ──
  // Déplacer les données d'un compte vers un autre : on les « met de côté » (clé « state »), puis on les reprend
  // depuis l'autre compte. Les retraits en attente sont annulés pour ne rien exécuter sur le mauvais compte.
  async function accountMenu() {
    const { state: shelf } = await chrome.storage.local.get('state');
    const shelfN = Object.keys(shelf?.videos || {}).length;
    const mineN = Object.keys(S.videos).length;
    const m = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = `<div class="box"><b>Compte actuel : ${esc(ACCOUNT)}</b>
      <p class="hint" style="max-width:none">${mineN} vidéos ici · ${shelfN} mises de côté</p>
      <button class="opt" data-a="shelve" ${mineN ? '' : 'disabled'}>📤 Mettre de côté les données de ce compte</button>
      <button class="opt" data-a="restore" ${shelfN ? '' : 'disabled'}>📥 Reprendre les données mises de côté (${shelfN})</button>
      <hr>
      <button class="opt" data-a="settings">⚙ Réglages (délais, sens des gestes)</button>
      <button class="opt" data-a="export">⬇ Exporter mes données (sauvegarde)</button>
      <label class="opt" style="display:block;cursor:pointer">⬆ Restaurer une sauvegarde<input type="file" accept=".json" hidden data-a="restore-file"></label>
      <hr>
      <button class="opt danger" data-a="reset">🗑 Tout réinitialiser (comme une nouvelle installation)</button>
      <button class="sec" style="margin:6px 0 0">Fermer</button></div>`;
    m.addEventListener('click', async (e) => {
      const t = e.target;
      if (t === m || t.classList.contains('sec')) return m.remove();
      if (t.dataset.a === 'settings') {
        m.remove();
        return settingsMenu();
      }
      if (t.dataset.a === 'export') return exportData();
      if (t.dataset.a === 'shelve') {
        if (shelfN && !confirm(`Remplacer les ${shelfN} vidéos déjà mises de côté ?`)) return;
        for (const v of Object.values(S.videos)) {
          if (v.status !== 'deleted') continue;
          const r = await send({ type: 'cancel', id: v.id });
          if (r?.ok) v.status = 'new'; // retrait pas encore parti : on l'annule
        }
        await chrome.storage.local.set({ state: S });
        S = { videos: {}, order: [], collections: [], confirmed: S.confirmed };
        normalizeState();
        await save();
        m.remove();
        render();
        toast('Données mises de côté. Ouvre l’autre compte pour les reprendre.');
      } else if (t.dataset.a === 'reset') {
        const warning =
          'Tout réinitialiser ?\n\nCela efface, pour TOUS les comptes, ton tri, tes collections locales, les données mises de côté ' +
          'et la file des retraits en attente.\nRien n’est modifié sur TikTok : tes favoris et tes collections TikTok restent intacts.';
        if (!confirm(warning)) return;
        if (!confirm('Dernière confirmation : repartir de zéro ?')) return;
        cancelOp = true; // arrête l’import ou la synchronisation en cours
        clearTimeout(syncTimer);
        await chrome.storage.local.clear();
        sessionStorage.removeItem('tts-resume');
        sessionStorage.removeItem('tts-fresh');
        S = { videos: {}, order: [], collections: [], confirmed: false, errors: {} };
        normalizeState();
        J = {};
        hist = [];
        legacyState = null;
        ACCOUNT = '';
        await loadAccount(); // relit le compte et prévient l’arrière-plan
        m.remove();
        tab = 'deck';
        render();
        toast('Extension réinitialisée : tout repart de zéro.');
      } else if (t.dataset.a === 'restore') {
        if (mineN && !confirm(`Remplacer les ${mineN} vidéos de ${ACCOUNT} par celles mises de côté ?`)) return;
        S = shelf;
        normalizeState();
        await chrome.storage.local.remove('state');
        await save();
        m.remove();
        render();
        toast('Données reprises pour ' + ACCOUNT);
      }
    });
    m.querySelector('[data-a="restore-file"]').onchange = (e) => {
      if (!e.target.files[0]) return;
      m.remove();
      restoreBackup(e.target.files[0]);
    };
    root.append(m);
  }

  function shell() {
    ov.innerHTML = `<header><div class="tabs">
      ${[['deck', 'Trier'], ['kept', 'Gardés'], ['cols', 'Collections'], ['del', 'Retirés'], ['state', 'État']]
        .map(([k, l]) => `<button class="tab ${tab === k ? 'on' : ''}" data-tab="${k}">${l}${k === 'state' && problemCount() ? ` <span class="badge">${problemCount()}</span>` : ''}</button>`).join('')}
      </div><button class="tab" id="stop" title="Arrêter l’opération en cours" ${scanning || syncing ? "" : "hidden"}>✕ Stop</button><span class="acct" id="scan-status"></span><span class="acct">${esc(ACCOUNT)}</span><button class="tab" id="settings-btn" title="Réglages (langue, gestes, vitesse)">⚙ Réglages</button><button class="tab acct-btn" title="Déplacer les données vers un autre compte">Comptes</button><button class="tab" id="lang-btn" title="FR / EN">${typeof TTS_I18N !== 'undefined' && TTS_I18N.lang === 'en' ? 'FR' : 'EN'}</button><button class="x" title="Fermer">✕</button></header><main id="body"></main>`;
  }

  function render() {
    shell();
    renderBody();
  }

  function renderBody() {
    const body = ov.querySelector('#body');
    if (!body) return;
    body.innerHTML = '';
    ({ deck: renderDeck, kept: renderKept, cols: renderCols, del: renderDel, state: renderState })[tab](body);
    paintQueueChip();
  }

  function renderDeck(body) {
    const ids = pile();
    if (!ids.length) {
      const total = S.order.length;
      body.innerHTML = `<div class="empty"><h2>${total ? 'Tout est trié 🎉' : 'Importe tes favoris'}</h2>
        <p>${total ? 'Tu peux réimporter pour récupérer les nouveaux favoris.' : 'Deux façons de faire :'}</p>
        <button class="pri" id="scan">${importIncomplete() ? `↻ Reprendre l’importation (${S.order.length} / ${S.importTotal})` : "Importer depuis mon profil TikTok"}</button>
        ${pendingSync() ? `<button class="sec" id="deck-sync">⇄ Synchroniser les collections (${pendingSync()})</button>` : ""}
        <label class="sec" style="display:inline-block;cursor:pointer">Importer l’export JSON
          <input type="file" accept=".json,.txt" hidden id="file"></label>
        <div id="scan-count" class="hint"></div>
        <p class="hint">« Depuis mon profil » lit ton onglet Favoris (défilement automatique). L’export JSON s’obtient dans TikTok : Paramètres → Compte → Télécharger tes données.</p>
        <p class="hint" style="color:#e6a5aa">⚠ ${RISK_SHORT}</p></div>`;
      body.querySelector('#scan').onclick = scanFavorites;
      body.querySelector('#deck-sync')?.addEventListener('click', () => syncCollections());
      body.querySelector('#file').onchange = (e) => e.target.files[0] && importFile(e.target.files[0]);
      return;
    }
    const id = ids[0];
    const nextId = ids[1];
    const total = S.order.length;
    const done = total - ids.length;
    const swap = SET.swap;
    const keepBtn = `<button class="rb keep" title="Garder (${swap ? '→' : '←'})">♥</button>`;
    const colBtn = '<button class="rb col" title="Collection (↑)">📁</button>';
    const delBtn = `<button class="rb del" title="Retirer des favoris (${swap ? '←' : '→'})">✕</button>`;
    const player = (vid) =>
      `https://www.tiktok.com/player/v1/${vid}?controls=1&progress_bar=1&play_button=1&volume_control=1&fullscreen_button=0&timestamp=0&music_info=0&description=0&rel=0&loop=1`;
    body.innerHTML = `<div class="deckwrap ${swap ? 'swap' : ''}"><aside class="cols"><h4>Collections (${S.collections.length})</h4>
      <button class="syncbtn" id="deck-sync" title="Envoie tes rangements et retraits de collections à TikTok">${syncing ? '⏳ Synchronisation…' : `⇄ Synchroniser les collections (${pendingSync()})`}</button>
      <input class="colsearch" id="colsearch" placeholder="🔍 Chercher une collection…" value="${esc(deckSearch)}" autocomplete="off">
      <button class="chip new" data-new="1">＋ Nouvelle collection</button>
      <div class="chips">${chipsHtml()}</div></aside>
      <div class="deckmain"><div class="count">${ids.length} à trier</div>
      <button class="sec small" id="resume" title="Lit ton onglet Favoris sur TikTok. Les vidéos déjà importées ne sont pas dupliquées : ça reprend un import interrompu ou récupère les nouveaux favoris.">${importIncomplete() ? `↻ Reprendre l’import (${S.order.length} / ${S.importTotal})` : '↻ Importer les nouveaux favoris'}</button>
      <div class="bar"><i style="width:${(done / total) * 100}%"></i></div>
      <div class="stage">${nextId ? `<div class="nextcard" style="background-image:url('${esc(S.videos[nextId].thumb)}')"></div>` : ''}<div class="card">
        <iframe src="${player(id)}" allow="autoplay; encrypted-media; fullscreen"></iframe>
        <div class="drag top"></div><div class="drag mid"></div><div class="drag bot"></div>
        <div class="tag keep">GARDER</div><div class="tag del">RETIRER</div><div class="tag col">📁 RANGER</div>
      </div></div>
      ${nextId ? `<iframe class="pre" src="${player(nextId)}" tabindex="-1" aria-hidden="true"></iframe>` : ''}
      <div class="btns"><button class="rb undo" title="Annuler (Z)">↺</button>
        ${swap ? `${delBtn}${colBtn}${keepBtn}` : `${keepBtn}${colBtn}${delBtn}`}</div>
      <div class="hint">${swap ? '← retirer des favoris · → garder' : '← garder · → retirer des favoris'} · ↑ ranger · touches 1-9 : collection numérotée. Glisse la carte de n’importe où ; ▶ au centre pour lire. Dépose-la sur une collection pour la ranger.</div></div></div>`;
    const card = body.querySelector('.card');
    body.querySelector('.cols').addEventListener('click', (e) => {
      const pin = e.target.closest('[data-pin]');
      if (pin) return togglePin(pin.dataset.pin);
      const chip = e.target.closest('.chip');
      if (chip) dropOn(card, chip);
    });
    body.querySelector('#colsearch').addEventListener('input', (e) => {
      deckSearch = e.target.value;
      body.querySelector('.chips').innerHTML = chipsHtml();
    });
    body.querySelector('#deck-sync')?.addEventListener('click', () => syncCollections());
    body.querySelector('#resume')?.addEventListener('click', () => scanFavorites());
    body.querySelector('.rb.undo').onclick = undo;
    body.querySelector('.rb.del').onclick = () => fly(card, 'del');
    body.querySelector('.rb.keep').onclick = () => fly(card, 'keep');
    body.querySelector('.rb.col').onclick = () => fly(card, 'col');
    body.querySelectorAll('.drag').forEach((d) => attachDrag(card, d));
  }

  // Panneau des collections : épinglées d'abord, puis récentes ; les 9 premières ont un raccourci clavier (touches 1-9).
  let deckSearch = '';
  function chipsHtml() {
    const counts = {};
    for (const v of Object.values(S.videos)) if (v.status === 'kept' && v.collection) counts[v.collection] = (counts[v.collection] || 0) + 1;
    const q = deckSearch.trim().toLowerCase();
    return orderedCollections()
      .filter((c) => !q || c.toLowerCase().includes(q))
      .map((c, i) => {
        const pinned = (S.pinned || []).includes(c);
        return `<button class="chip" data-name="${esc(c)}"><span>${i < 9 ? `<kbd>${i + 1}</kbd>` : ''}${esc(c)}</span><small>${counts[c] || 0}</small>
          <i class="pin ${pinned ? 'on' : ''}" data-pin="${esc(c)}" title="${pinned ? 'Désépingler' : 'Épingler en haut'}">${pinned ? '★' : '☆'}</i></button>`;
      })
      .join('');
  }

  async function togglePin(name) {
    S.pinned = (S.pinned || []).includes(name) ? S.pinned.filter((c) => c !== name) : [...(S.pinned || []), name];
    await save();
    const chips = ov.querySelector('.chips');
    if (chips) chips.innerHTML = chipsHtml();
  }

  const dirs = () => ({ keep: [keepSign(), 0], del: [-keepSign(), 0], col: [0, -1] });

  // Collection sous le pointeur (le panneau est dans le shadow DOM : elementsFromPoint traverse la carte déplacée).
  const chipAt = (x, y) => root.elementsFromPoint(x, y).find((el) => el.classList?.contains('chip'));

  // Range la vidéo dans la collection de la pastille (clic ou dépôt) ; « Nouvelle collection » demande un nom.
  async function dropOn(card, chip) {
    let name = chip.dataset.name;
    if (chip.dataset.new) {
      name = await pickCollection();
      if (!name) return snapBack(card);
    }
    // arrivée : le centre de la carte, réduite, sur la pastille (l'origine du zoom est le point saisi pendant le glissement)
    const s = card.parentElement.getBoundingClientRect();
    const r = chip.getBoundingClientRect();
    const k = 0.15;
    const ox = Number(card.dataset.ox ?? s.width / 2);
    const oy = Number(card.dataset.oy ?? s.height / 2);
    const tx = r.left + r.width / 2 - s.left - ox - k * (s.width / 2 - ox);
    const ty = r.top + r.height / 2 - s.top - oy - k * (s.height / 2 - oy);
    card.style.transition = 'transform .25s ease-in, opacity .25s';
    card.style.transform = `translate(${tx}px, ${ty}px) scale(${k})`;
    card.style.opacity = '0';
    setTimeout(() => act('col', name), 230);
  }

  async function fly(card, kind) {
    if (kind === 'col') {
      const name = await pickCollection();
      if (!name) return snapBack(card);
      return flyOut(card, kind, name);
    }
    if (kind === 'del' && !(await riskGate())) return snapBack(card);
    flyOut(card, kind);
  }

  function flyOut(card, kind, name) {
    const [dx, dy] = dirs()[kind];
    card.style.transition = 'transform .25s ease-in, opacity .25s';
    card.style.transform = `translate(${dx * 700}px, ${dy * 700}px) rotate(${dx * 25}deg)`;
    card.style.opacity = '0';
    setTimeout(() => act(kind, name), 230);
  }

  function snapBack(card) {
    card.style.transition = 'transform .2s';
    card.style.transform = '';
    card.querySelectorAll('.tag').forEach((t) => (t.style.opacity = 0));
  }

  function attachDrag(card, el) {
    let sx, sy, dx, dy, t0, moved, hot;
    const tags = { keep: card.querySelector('.tag.keep'), del: card.querySelector('.tag.del'), col: card.querySelector('.tag.col') };
    // Un dépôt sur une collection n'est pris en compte que si le pointeur y reste un instant (DWELL) : sans cela, un
    // balayage rapide qui se termine par hasard au-dessus du panneau rangerait la vidéo au lieu de la garder.
    const DWELL = 220;
    let hotSince = 0;
    let hotTimer = null;
    const setHot = (chip) => {
      if (chip === hot) return;
      clearTimeout(hotTimer);
      hot?.classList.remove("hot", "ready");
      hot = chip;
      hotSince = Date.now();
      hot?.classList.add("hot");
      hotTimer = setTimeout(() => hot === chip && chip?.classList.add("ready"), DWELL);
    };
    el.addEventListener('pointerdown', (e) => {
      el.setPointerCapture(e.pointerId);
      [sx, sy, dx, dy, t0, moved] = [e.clientX, e.clientY, 0, 0, Date.now(), false];
      // la carte rétrécit autour du point saisi : le curseur reste sur le même endroit de la vidéo
      const st = card.parentElement.getBoundingClientRect();
      card.dataset.ox = e.clientX - st.left;
      card.dataset.oy = e.clientY - st.top;
      card.style.transformOrigin = `${card.dataset.ox}px ${card.dataset.oy}px`;
      card.style.transition = 'none';
    });
    el.addEventListener('pointermove', (e) => {
      if (sx === undefined) return;
      dx = e.clientX - sx;
      dy = e.clientY - sy; // la carte suit aussi vers le bas, pour atteindre les collections du panneau
      if (Math.abs(dx) + Math.abs(dy) > 6) moved = true;
      // plus le pointeur approche du panneau des collections, plus la carte rétrécit : on voit précisément où on dépose
      let k = 1;
      const panel = ov.querySelector('.cols')?.getBoundingClientRect();
      if (panel && moved) {
        const gapX = Math.max(panel.left - e.clientX, 0, e.clientX - panel.right);
        const gapY = Math.max(panel.top - e.clientY, 0, e.clientY - panel.bottom);
        k = 1 - 0.7 * (1 - Math.min(1, Math.hypot(gapX, gapY) / 320)); // 1 loin → 0,3 sur le panneau
      }
      card.style.transform = `translate(${dx}px, ${dy}px) rotate(${dx / 18}deg) scale(${k})`;
      setHot(moved ? chipAt(e.clientX, e.clientY) : null);
      const horiz = Math.abs(dx) > Math.abs(dy);
      const off = hot ? 0 : 1; // au-dessus d'une collection, on n'affiche plus les tags de balayage
      const sw = dx * keepSign();
      tags.keep.style.opacity = horiz && sw > 0 ? off * Math.min(1, sw / 100) : 0;
      tags.del.style.opacity = horiz && sw < 0 ? off * Math.min(1, -sw / 100) : 0;
      tags.col.style.opacity = hot || (!horiz && dy < 0) ? Math.min(1, hot ? 1 : -dy / 100) : 0;
    });
    el.addEventListener('pointerup', (e) => {
      if (sx === undefined) return;
      sx = undefined;
      const over = moved ? chipAt(e.clientX, e.clientY) : null;
      const chip = over && over === hot && Date.now() - hotSince >= DWELL ? over : null; // pointeur resté assez longtemps
      setHot(null);
      if (!moved) return snapBack(card); // simple appui : rien
      if (chip) return dropOn(card, chip); // déposée sur une collection : prioritaire sur le balayage
      const horiz = Math.abs(dx) > Math.abs(dy);
      const sw = dx * keepSign(); // > 0 : vers le côté « garder »
      if (horiz && sw < -100) fly(card, 'del');
      else if (horiz && sw > 100) fly(card, 'keep');
      else if (!horiz && dy < -100) fly(card, 'col');
      else snapBack(card);
    });
  }

  // ── Pagination : des milliers de vignettes d'un coup ralentissent l'écran ──
  const PAGE = 120;
  const limits = {};
  function paged(list, key) {
    const n = limits[key] || PAGE;
    const more = list.length > n ? `<button class="sec" data-more="${esc(key)}">Afficher plus (${list.length - n} restantes)</button>` : '';
    return { items: list.slice(0, n), more };
  }

  // ── Sélection multiple (onglet Gardés) ──
  let selectMode = false;
  const sel = new Set();

  function gridItem(v, extra = '', inCollection = false, selectable = false) {
    const on = selectable && selectMode;
    const picked = on && sel.has(v.id);
    return `<div class="item ${picked ? 'picked' : ''}" style="background-image:url('${esc(v.thumb)}')" ${on ? `data-sel="${v.id}"` : ''}>
      ${on ? `<div class="chk">${picked ? '☑' : '☐'}</div>` : `<a href="${esc(v.url)}" target="_blank" rel="noopener"></a>`}
      ${on ? '' : `<div class="lbl"><span>${extra}</span><span class="acts">
        <button data-back="${v.id}" title="Remettre dans la pile">↩</button>
        ${inCollection ? `<button data-uncol="${v.id}" title="Sortir de la collection (reste dans les favoris)">⊖</button>` : ''}
        <button data-unfav="${v.id}" title="Retirer des favoris TikTok">🗑</button></span></div>`}</div>`;
  }

  // Retire des favoris TikTok une liste de vidéos (même file d'attente que le glissement).
  async function unfavorite(vids) {
    const before = vids.map((v) => ({ id: v.id, status: v.status, collection: v.collection, synced: v.synced, removeFrom: v.removeFrom }));
    for (const v of vids) {
      delete v.removeFrom;
      Object.assign(v, { status: 'deleted', collection: null, synced: false });
      logAct('unfav', v.id);
    }
    const r = await send({ type: 'enqueue', items: vids.map((v) => ({ id: v.id, url: v.url, account: ACCOUNT })) });
    if (r?.rejected?.length) {
      // quota gratuit : on remet exactement l'état d'avant pour les vidéos refusées
      for (const b of before) {
        if (!r.rejected.includes(b.id)) continue;
        const { id, ...prev } = b;
        Object.assign(S.videos[id], prev);
        S.log.shift();
      }
      upsell('limit');
    }
    refreshPlan();
    await save();
  }

  function bindBack(body) {
    body.querySelectorAll('[data-more]').forEach((b) => {
      b.onclick = () => {
        limits[b.dataset.more] = (limits[b.dataset.more] || PAGE) + PAGE;
        renderBody();
      };
    });
    body.querySelectorAll('[data-back]').forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        const v = S.videos[b.dataset.back];
        if (v.synced && v.collection) v.removeFrom = v.collection; // déjà rangée sur TikTok : on l'en retire aussi
        Object.assign(v, { status: 'new', collection: null, synced: false });
        S.order = [v.id, ...S.order.filter((x) => x !== v.id)];
        logAct('back', v.id);
        await save();
        renderBody();
        scheduleSync();
      };
    });
    // sortir de la collection, sans quitter les favoris
    body.querySelectorAll('[data-uncol]').forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        const v = S.videos[b.dataset.uncol];
        if (v.synced && v.collection) v.removeFrom = v.collection;
        logAct('uncol', v.id, v.collection);
        Object.assign(v, { collection: null, synced: false });
        await save();
        renderBody();
        scheduleSync();
      };
    });
    // retirer des favoris TikTok
    body.querySelectorAll('[data-unfav]').forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        if (accountChanged()) return;
        if (!(await riskGate())) return;
        await unfavorite([S.videos[b.dataset.unfav]]);
        renderBody();
      };
    });
  }

  function renderKept(body) {
    const list = S.order.map((id) => S.videos[id]).filter((v) => v.status === 'kept' && !v.collection);
    const { items, more } = paged(list, 'kept');
    const bar = list.length
      ? `<div class="selbar">${
          selectMode
            ? `<b>${sel.size} sélectionnée(s)</b>
               <button class="sec" id="sel-all">Tout sélectionner (${list.length})</button>
               <button class="pri" id="sel-col" ${sel.size ? '' : 'disabled'}>📁 Ranger dans…</button>
               <button class="sec danger" id="sel-del" ${sel.size ? '' : 'disabled'}>🗑 Retirer des favoris</button>
               <button class="sec" id="sel-off">Terminer</button>`
            : '<button class="sec" id="sel-on">☑ Sélectionner plusieurs vidéos</button>'
        }</div>`
      : '';
    body.innerHTML = list.length
      ? `<div class="count">${list.length} gardées</div>${bar}<div class="grid">${items.map((v) => gridItem(v, '', false, true)).join('')}</div>${more}`
      : '<div class="empty"><p>Rien de gardé pour l’instant.</p></div>';
    bindBack(body);
    body.querySelector('#sel-on')?.addEventListener('click', () => {
      selectMode = true;
      sel.clear();
      renderBody();
    });
    body.querySelector('#sel-off')?.addEventListener('click', () => {
      selectMode = false;
      sel.clear();
      renderBody();
    });
    body.querySelector('#sel-all')?.addEventListener('click', () => {
      list.forEach((v) => sel.add(v.id));
      renderBody();
    });
    body.querySelectorAll('[data-sel]').forEach((el) => {
      el.onclick = () => {
        const id = el.dataset.sel;
        if (sel.has(id)) sel.delete(id);
        else sel.add(id);
        renderBody();
      };
    });
    body.querySelector('#sel-col')?.addEventListener('click', async () => {
      const name = await pickCollection();
      if (!name) return;
      for (const id of sel) {
        Object.assign(S.videos[id], { status: 'kept', collection: name, synced: false });
        logAct('col', id, name);
      }
      touchRecent(name);
      toast(`${sel.size} vidéo(s) rangée(s) dans « ${name} »`);
      sel.clear();
      selectMode = false;
      await save();
      renderBody();
      scheduleSync();
    });
    body.querySelector('#sel-del')?.addEventListener('click', async () => {
      if (accountChanged()) return;
      if (!(await riskGate())) return;
      if (!confirm(`Retirer ${sel.size} vidéo(s) de tes favoris TikTok (automatiquement, en arrière-plan) ?`)) return;
      await unfavorite([...sel].map((id) => S.videos[id]));
      toast(`${sel.size} retrait(s) mis en file`);
      sel.clear();
      selectMode = false;
      renderBody();
    });
  }

  // Renomme une collection qui n'existe pas encore sur TikTok (par ex. quand TikTok refuse son nom).
  async function renameCollection(old) {
    const vids = Object.values(S.videos).filter((v) => v.collection === old);
    if (vids.some((v) => v.synced)) {
      alert('Cette collection existe déjà sur TikTok : renomme-la dans TikTok (⋯ → Changer de nom), puis clique sur « Relire mes collections TikTok ».');
      return;
    }
    const name = prompt(`Nouveau nom pour « ${old} » :`, old)?.trim();
    if (!name || name === old) return;
    if (S.collections.some((c) => c.toLowerCase() === name.toLowerCase())) {
      alert('Une collection porte déjà ce nom.');
      return;
    }
    S.collections = S.collections.map((c) => (c === old ? name : c));
    S.pinned = (S.pinned || []).map((c) => (c === old ? name : c));
    S.recent = (S.recent || []).map((c) => (c === old ? name : c));
    for (const v of vids) v.collection = name;
    delete S.errors?.[old];
    await save();
    renderBody();
    scheduleSync(3000);
  }

  function renderCols(body) {
    const groups = S.collections
      .map((c) => [c, S.order.map((id) => S.videos[id]).filter((v) => v.status === 'kept' && v.collection === c)])
      .filter(([, l]) => l.length);
    const pending = pendingSync();
    body.innerHTML = groups.length
      ? `<div class="count">${pending ? `${pending} à ranger sur TikTok` : 'Tout est rangé sur TikTok'}</div>
         <button class="pri" id="sync" ${pending && !syncing ? '' : 'disabled'}>${syncing ? 'Synchronisation…' : 'Synchroniser maintenant'}</button>
         <div class="hint">Le rangement part tout seul quelques secondes après chaque glissement. ⊖ sort la vidéo de la collection, 🗑 la retire des favoris.</div>` +
        groups
          .map(([c, l]) => {
            const { items, more } = paged(l, `col:${c}`);
            return `<h3>📁 ${esc(c)} <small>(${l.length})</small> <button class="ren" data-ren="${esc(c)}" title="Renommer">✎</button></h3>${S.errors?.[c] ? `<div class="err">⚠ ${esc(S.errors[c])}</div>` : ''}<div class="grid">${items.map((v) => gridItem(v, v.synced ? '✓ TikTok' : '⏳', true)).join('')}</div>${more}`;
          })
          .join('')
      : '<div class="empty"><p>Aucune collection. Glisse une vidéo vers le haut pour en créer une.</p></div>';
    body.insertAdjacentHTML('afterbegin', '<button class="sec" id="reread">↻ Relire mes collections TikTok</button>');
    body.querySelector('#reread').addEventListener('click', () => refreshCollections());
    body.querySelector('#sync')?.addEventListener('click', () => syncCollections());
    body.querySelectorAll('[data-ren]').forEach((b) => (b.onclick = () => renameCollection(b.dataset.ren)));
    bindBack(body);
  }

  function renderDel(body) {
    const list = S.order.map((id) => S.videos[id]).filter((v) => v.status === 'deleted');
    const label = (id) => {
      const j = J[id];
      if (!j) return '…';
      return ({ pending: '⏳ en attente', running: '⏳ en cours', done: '✓ retiré', unverified: '✓ à vérifier', error: '⚠ échec' })[j.status] || j.status;
    };
    const pend = list.filter((v) => ['pending', 'running'].includes(J[v.id]?.status)).length;
    const { items, more } = paged(list, 'del');
    body.innerHTML = list.length
      ? `<div class="count">${list.length} retirées · ${pend} en attente${pend ? ` (${etaText(pend)})` : ""}</div>${pauseBanner()}
         <div class="grid">${items.map((v) => `<div class="item" style="background-image:url('${esc(v.thumb)}')"><a href="${esc(v.url)}" target="_blank" rel="noopener"></a>
          <div class="lbl"><span title="${esc(J[v.id]?.note || '')}">${label(v.id)}</span>
          ${J[v.id]?.status === 'error' ? `<button data-retry="${v.id}">↻</button>` : ''}</div></div>`).join('')}</div>${more}`
      : '<div class="empty"><p>Aucune vidéo retirée.</p></div>';
    bindBack(body);
    body.querySelectorAll('[data-retry]').forEach((b) => (b.onclick = () => send({ type: 'retry', id: b.dataset.retry })));
  }

  // ── Avertissement : risque de limitation / suspension / bannissement du compte TikTok ──
  // À accepter une fois (case à cocher) avant la première action automatisée : import, synchronisation, retrait.
  const RISK_SHORT = 'Outil non officiel, non affilié à TikTok. TikTok interdit l’automatisation : ton compte peut être limité, suspendu ou banni définitivement.';
  function riskGate() {
    if (SET.riskAccepted) return Promise.resolve(true);
    return new Promise((resolve) => {
      const m = document.createElement('div');
      m.className = 'modal';
      m.innerHTML = `<div class="box"><b>⚠ Avant de continuer</b>
        <p class="warn">Cet outil pilote TikTok à ta place : clics, défilement, ouverture de vidéos en arrière-plan.
          <b>TikTok interdit l’automatisation dans ses conditions d’utilisation.</b> Ton compte peut être <b>limité, suspendu ou banni définitivement</b>,
          même avec des pauses entre les actions. Ce risque existe et personne ne peut le supprimer.</p>
        <p class="warn">Tu utilises l’extension <b>à tes propres risques</b>. Elle n’est pas affiliée à TikTok et son auteur n’est pas responsable des sanctions
          prises contre ton compte. Conseils : petits lots, rythme prudent, teste d’abord sur un compte secondaire.</p>
        <label class="fld chk"><input type="checkbox" id="risk-ok"> Je comprends que mon compte TikTok peut être suspendu ou banni, et j’accepte ce risque.</label>
        <button class="pri" data-a="ok" disabled style="margin:6px 0 0">J’accepte et je continue</button>
        <button class="sec" data-a="no" style="margin:6px 0 0">Annuler</button></div>`;
      const done = (v) => {
        m.remove();
        resolve(v);
      };
      m.addEventListener('change', () => {
        m.querySelector('[data-a="ok"]').disabled = !m.querySelector('#risk-ok').checked;
      });
      m.addEventListener('click', async (e) => {
        const a = e.target.dataset?.a;
        if (e.target === m || a === 'no') return done(false);
        if (a === 'ok' && m.querySelector('#risk-ok').checked) {
          SET.riskAccepted = true;
          await saveSettings();
          done(true);
        }
      });
      root.append(m);
    });
  }

  function riskSection() {
    return `<section><h3>⚠ Avertissement</h3><p style="margin:0">${RISK_SHORT} Utilisation à tes propres risques ; fais des pauses et de petits lots.</p></section>`;
  }

  function donateSection() {
    if (!PLAN.donateUrl) return '';
    return `<section><h3>☕ Soutenir le projet</h3>
      <p>L’extension est faite et entretenue par une seule personne. Si elle te fait gagner du temps, un don, même petit, aide à la garder à jour quand TikTok change.</p>
      <button class="sec" id="donate">☕ Faire un don</button></section>`;
  }

  // ── Version gratuite / Pro (voir config.js et license.js) ──
  let PLAN = { configured: false, pro: true, used: 0, limit: 200, buyUrl: '', price: '5 €', donateUrl: '', email: '', keyTail: '', error: '' };
  async function refreshPlan() {
    try {
      const p = await send({ type: 'license-status' });
      if (p && typeof p.pro === 'boolean') PLAN = p;
    } catch {
      /* arrière-plan indisponible : on garde le dernier état connu */
    }
    if (ov && !ov.hidden && tab === 'state') renderBody();
  }
  function upsell(reason) {
    toast(
      reason === 'limit'
        ? `Limite gratuite atteinte : ${PLAN.limit} retraits par jour. Passe en Pro (${PLAN.price}) dans l’onglet État.`
        : `Fonction réservée à la version Pro (${PLAN.price}). Voir l’onglet État.`,
    );
  }

  function planSection() {
    if (!PLAN.configured) {
      return '<section><h3>⭐ Version</h3><p class="hint" style="text-align:left;max-width:none;margin:0">Mode développement : tout est débloqué (aucune boutique configurée dans config.js).</p></section>';
    }
    if (PLAN.pro) {
      return `<section><h3>⭐ Pro activée</h3><p>Merci ! ${PLAN.email ? `${esc(PLAN.email)} · ` : ''}clé ${esc(PLAN.keyTail)} · retraits illimités, onglets en parallèle, sauvegarde.</p>
        <button class="sec" id="lic-off">Désactiver sur cet ordinateur</button> <span id="lic-msg"></span></section>`;
    }
    return `<section><h3>⭐ Version gratuite</h3>
      <p>Retraits aujourd’hui : <b>${PLAN.used} / ${PLAN.limit}</b> · 1 onglet de retrait · pas de sauvegarde de données</p>
      ${PLAN.error ? `<p class="bad">${esc(PLAN.error)}</p>` : ''}
      <button class="pri" id="lic-buy">Passer en Pro : ${esc(PLAN.price)} (achat unique)</button>
      <p class="hint" style="text-align:left;max-width:none">Pro : retraits illimités, jusqu’à 3 onglets en parallèle avec chargement allégé (plus rapide), sauvegarde et restauration.</p>
      <input class="colsearch" id="lic-key" placeholder="Clé de licence reçue par e-mail" style="max-width:340px" autocomplete="off">
      <button class="sec" id="lic-on">Activer</button> <span id="lic-msg"></span></section>`;
  }

  function bindPlan(body) {
    const msg = (t, bad) => {
      const el = body.querySelector('#lic-msg');
      if (el) el.innerHTML = `<span class="${bad ? 'bad' : ''}">${esc(t)}</span>`;
    };
    body.querySelector('#donate')?.addEventListener('click', () => window.open(PLAN.donateUrl, '_blank', 'noopener'));
    body.querySelector('#lic-buy')?.addEventListener('click', () => {
      if (PLAN.buyUrl) window.open(PLAN.buyUrl, '_blank', 'noopener');
      else msg('Page d’achat non configurée.', true);
    });
    body.querySelector('#lic-on')?.addEventListener('click', async () => {
      msg('Vérification…');
      const r = await send({ type: 'license-activate', key: body.querySelector('#lic-key').value });
      if (!r?.ok) return msg(r?.error || 'Échec de l’activation.', true);
      await refreshPlan();
      toast('Licence Pro activée. Merci !');
    });
    body.querySelector('#lic-off')?.addEventListener('click', async () => {
      if (!confirm('Désactiver la licence sur cet ordinateur ? Tu pourras l’utiliser sur un autre.')) return;
      await send({ type: 'license-deactivate' });
      await refreshPlan();
    });
  }

  // ── Onglet État : tout ce qui est en attente, en erreur, et le journal des actions ──
  // Durée estimée des retraits restants : mesure réelle de background.js (moyenne mobile), sinon estimation d'après les réglages.
  const etaText = (n) => {
    const per = QS.perVideoMs || (((SET.pauseMin + SET.pauseMax) / 2 + 6) * 1000) / Math.max(1, SET.workers);
    const min = Math.ceil((n * per) / 60000);
    return min < 1 ? 'moins d’1 min' : `environ ${min} min`;
  };
  const pauseBanner = () =>
    QS.pausedUntil > Date.now()
      ? `<p class="bad">⏸ ${esc(QS.note || 'File en pause.')} Reprise dans ${QS.pausedUntil - Date.now() < 60000 ? `${Math.ceil((QS.pausedUntil - Date.now()) / 1000)} s` : `${Math.ceil((QS.pausedUntil - Date.now()) / 60000)} min`}. <button class="sec" id="st-resume">Reprendre maintenant</button></p>`
      : '';

  // ── Pastille en bas à droite : retraits restants, pause de sécurité (visible sur tous les onglets sauf État) ──
  const pauseLeft = () => {
    const ms = QS.pausedUntil - Date.now();
    return ms < 60000 ? `${Math.max(1, Math.ceil(ms / 1000))} s` : `${Math.ceil(ms / 60000)} min`;
  };
  function queueChipHtml() {
    if (tab === 'state') return '';
    let pend = 0;
    let run = 0;
    let err = 0;
    for (const v of Object.values(S.videos)) {
      if (v.status !== 'deleted') continue;
      const s = J[v.id]?.status;
      if (s === 'pending') pend++;
      else if (s === 'running') run++;
      else if (s === 'error') err++;
    }
    const left = pend + run;
    const paused = QS.pausedUntil > Date.now();
    if (!left && !paused && !err) return '';
    return (
      (left ? `<div><b>🗑 Retraits : ${left} restants</b> · ${etaText(left)}${run ? ` · ${run} en cours` : ''}</div>` : '') +
      (paused ? `<div class="bad">⏸ ${esc(QS.note || 'File en pause.')} Reprise dans ${pauseLeft()}. <button id="q-resume">Reprendre maintenant</button></div>` : '') +
      (err ? `<div class="bad">⚠ ${err} en échec · <button id="q-state">Voir</button></div>` : '')
    );
  }
  function paintQueueChip() {
    if (!ov || ov.hidden) return;
    const html = queueChipHtml();
    let el = ov.querySelector('#qchip');
    if (!html) return el?.remove();
    if (!el) {
      el = document.createElement('div');
      el.id = 'qchip';
      el.className = 'qchip';
      ov.append(el);
    }
    if (el.dataset.h !== html) {
      el.dataset.h = html;
      el.innerHTML = html;
    }
  }
  setInterval(() => {
    if (ov && !ov.hidden && (QS.pausedUntil > Date.now() - 1500 || ov.querySelector('#qchip'))) paintQueueChip();
  }, 1000);

  const problemCount = () =>
    Object.keys(S.errors || {}).length + Object.values(S.videos).filter((v) => v.status === 'deleted' && J[v.id]?.status === 'error').length;

  const LOG_LABELS = {
    keep: '♥ Gardée',
    col: '📁 Rangée',
    del: '🗑 Retirée des favoris',
    unfav: '🗑 Retirée des favoris',
    undo: '↺ Annulée',
    back: '↩ Remise dans la pile',
    uncol: '⊖ Sortie de la collection',
  };

  function renderState(body) {
    const deleted = Object.values(S.videos).filter((v) => v.status === 'deleted');
    const by = { pending: 0, running: 0, done: 0, unverified: 0, error: 0, none: 0 };
    for (const v of deleted) by[J[v.id]?.status || 'none']++;
    const errCols = Object.entries(S.errors || {});
    const fmt = (t) => new Date(t).toLocaleString(typeof TTS_I18N !== 'undefined' ? TTS_I18N.locale() : 'fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    const log = (S.log || [])
      .slice(0, 80)
      .map((l) => {
        const v = S.videos[l.id];
        const link = v ? `<a href="${esc(v.url)}" target="_blank" rel="noopener">vidéo ${esc(l.id.slice(-6))}</a>` : '';
        return `<li><span class="t">${fmt(l.t)}</span> ${LOG_LABELS[l.a] || esc(l.a)} ${link}${l.name ? ` → <i>${esc(l.name)}</i>` : ''}</li>`;
      })
      .join('');
    const limitedBanner = S.limitedAt && Date.now() - S.limitedAt < 3600000 ? `<section><p class="bad">⚠ ${RATE_MSG} <small>(détecté à ${fmt(S.limitedAt)})</small></p></section>` : '';
    body.innerHTML = `<div class="state">${planSection()}${riskSection()}${donateSection()}${limitedBanner}
      <section><h3>🗑 Retraits des favoris TikTok</h3>
        <p>${by.pending} en attente · ${by.running} en cours · ${by.done + by.unverified} faits · <b class="${by.error ? 'bad' : ''}">${by.error} en échec</b></p>
        ${by.pending + by.running ? `<p>⏱ ${etaText(by.pending + by.running)} restantes · ${SET.workers} onglet(s) en parallèle</p>` : ""}${pauseBanner()}
        <button class="sec" id="st-cancel" ${by.pending ? '' : 'disabled'}>Annuler les ${by.pending} en attente</button>
        <button class="sec" id="st-retry" ${by.error ? '' : 'disabled'}>↻ Réessayer les ${by.error} échecs</button></section>
      <section><h3>📁 Collections</h3>
        <p>${pendingSync()} à envoyer à TikTok${errCols.length ? ` · <b class="bad">${errCols.length} collection(s) en erreur</b>` : ''}</p>
        ${errCols.map(([n, m]) => `<div class="err">⚠ <b>${esc(n)}</b> — ${esc(m)} <button class="ren" data-ren="${esc(n)}" title="Renommer">✎</button></div>`).join('')}
        <button class="sec" id="st-sync" ${syncing ? 'disabled' : ''}>⇄ Synchroniser maintenant</button></section>
      <section><h3>⬇ Import depuis TikTok</h3>
        <p>${S.order.length} vidéos importées${S.importTotal ? ` sur ${S.importTotal} favoris` : ''}${S.lastImport ? ` · dernier import : ${fmt(S.lastImport)}` : ''}</p>
        <button class="sec" id="st-import">↻ Importer les nouveaux favoris (rapide)</button>
        <button class="sec" id="st-import-full">Tout relire (lent)</button>
        <button class="sec" id="st-cols">↻ Relire les collections modifiées</button>
        <button class="sec" id="st-cols-full">Relire toutes les collections (lent)</button></section>
      <section><h3>💾 Sauvegarde</h3>
        <p class="hint" style="margin:0 0 8px;text-align:left;max-width:none">Un fichier avec ton tri, tes collections locales et tes réglages. Rien n'est envoyé nulle part.</p>
        <button class="sec" id="st-export">⬇ Exporter mes données</button>
        <label class="sec" style="display:inline-block;cursor:pointer">⬆ Restaurer une sauvegarde<input type="file" accept=".json" hidden id="st-restore"></label></section>
      <section><h3>📜 Journal (80 dernières actions)</h3>
        <p class="hint" style="margin:0 0 8px;text-align:left;max-width:none">Un retrait est irréversible : retrouve ici la vidéo et remets-la en favori à la main si besoin.</p>
        ${log ? `<ul class="log">${log}</ul>` : '<p class="hint" style="text-align:left">Rien pour l’instant.</p>'}</section></div>`;
    const $ = (s) => body.querySelector(s);
    $('#st-cancel').onclick = async () => {
      let n = 0;
      for (const v of deleted.filter((x) => J[x.id]?.status === 'pending')) {
        const r = await send({ type: 'cancel', id: v.id });
        if (!r?.ok) continue;
        v.status = 'new';
        S.order = [v.id, ...S.order.filter((x) => x !== v.id)];
        logAct('undo', v.id);
        n++;
      }
      await save();
      toast(`${n} retrait(s) annulé(s) : les vidéos sont revenues dans la pile`);
      renderBody();
    };
    bindPlan(body);
    body.querySelector('#st-resume')?.addEventListener('click', () => send({ type: 'resume-queue' }));
    $('#st-retry').onclick = () => deleted.filter((x) => J[x.id]?.status === 'error').forEach((v) => send({ type: 'retry', id: v.id }));
    $('#st-sync').onclick = () => syncCollections();
    $('#st-import').onclick = () => scanFavorites();
    $('#st-import-full').onclick = () => scanFavorites({ full: true });
    $('#st-cols').onclick = () => refreshCollections();
    $('#st-cols-full').onclick = () => refreshCollections({ full: true });
    $('#st-export').onclick = exportData;
    $('#st-restore').onchange = (e) => e.target.files[0] && restoreBackup(e.target.files[0]);
    body.querySelectorAll('[data-ren]').forEach((b) => (b.onclick = () => renameCollection(b.dataset.ren)));
  }

  // ── Sauvegarde / restauration ──
  async function exportData() {
    if (!PLAN.pro) return upsell('feature');
    const all = await chrome.storage.local.get(null);
    const data = {};
    for (const [k, v] of Object.entries(all)) if (k.startsWith('state:') || k === 'settings') data[k] = v;
    const blob = new Blob([JSON.stringify({ app: 'tiktok-swipe-favoris', version: 1, exportedAt: new Date().toISOString(), data })], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `tiktok-swipe-sauvegarde-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    toast(`Sauvegarde exportée (${Object.keys(data).length} élément(s))`);
  }

  function restoreBackup(file) {
    if (!PLAN.pro) return upsell('feature');
    const reader = new FileReader();
    reader.onload = async () => {
      let obj;
      try {
        obj = JSON.parse(reader.result);
      } catch {
        return toast('Fichier illisible.');
      }
      if (obj?.app !== 'tiktok-swipe-favoris' || !obj.data) return toast('Ce fichier n’est pas une sauvegarde de l’extension.');
      const keys = Object.keys(obj.data).filter((k) => k.startsWith('state:') || k === 'settings');
      if (!keys.length) return toast('Sauvegarde vide.');
      const accounts = keys.filter((k) => k !== 'settings').map((k) => k.slice(6));
      if (!confirm(`Restaurer la sauvegarde ? Elle REMPLACE les données actuelles de : ${accounts.join(', ') || 'réglages'}.`)) return;
      await chrome.storage.local.set(Object.fromEntries(keys.map((k) => [k, obj.data[k]])));
      ACCOUNT = '';
      await loadAccount(); // relit l'état restauré
      render();
      toast('Sauvegarde restaurée.');
    };
    reader.readAsText(file);
  }

  // ── Réglages ──
  function settingsMenu() {
    const m = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = `<div class="box"><b>⚙ Réglages</b>
      <label class="fld">Langue de l’interface<select id="s-lang"><option value="auto" ${SET.lang === 'auto' ? 'selected' : ''}>Automatique (langue de TikTok)</option><option value="fr" ${SET.lang === 'fr' ? 'selected' : ''}>Français</option><option value="en" ${SET.lang === 'en' ? 'selected' : ''}>English</option></select></label>
      <label class="fld chk"><input type="checkbox" id="s-swap" ${SET.swap ? 'checked' : ''}> Inverser les gestes (droite = garder, gauche = retirer)</label>
      <label class="fld">Délai pour annuler un retrait (secondes)<input type="number" id="s-grace" min="3" max="120" value="${SET.grace}"></label>
      <details class="adv"><summary>Avancé (vitesse et pauses)</summary>
      <label class="fld">Onglets de retrait en parallèle (1 à 3)${PLAN.pro ? "" : " — Pro"}<input type="number" id="s-workers" min="1" max="3" value="${SET.workers}" ${PLAN.pro ? "" : "disabled"}></label>
      <label class="fld">Envoyer les rangements aux collections après (secondes d’inactivité)<input type="number" id="s-sync" min="3" max="600" value="${SET.syncDelay}"></label>
      <label class="fld chk"><input type="checkbox" id="s-block" ${SET.blockMedia ? "checked" : ""} ${PLAN.pro ? "" : "disabled"}> Retraits plus rapides : ne pas charger images et vidéos dans les onglets de retrait${PLAN.pro ? "" : " — Pro"}</label>
      <label class="fld">Pause entre deux retraits : min (s)<input type="number" id="s-pmin" min="2" max="120" value="${SET.pauseMin}"></label>
      <label class="fld">Pause entre deux retraits : max (s)<input type="number" id="s-pmax" min="2" max="180" value="${SET.pauseMax}"></label>
      <label class="fld">Pause de sécurité quand TikTok semble bloquer (secondes)${PLAN.pro ? "" : " — Pro"}<input type="number" id="s-safety" min="5" max="1800" value="${PLAN.pro ? SET.safetyPause : 300}" ${PLAN.pro ? "" : "disabled"}></label>
      <p class="hint" style="max-width:none;text-align:left">Plus d’onglets et des pauses courtes = retraits plus rapides, mais plus de risque que TikTok te ralentisse ou te bloque. L’extension se met en pause d’elle-même (5 minutes en version gratuite, réglable en Pro) si TikTok refuse plusieurs retraits de suite. Une pause trop courte augmente le risque de limitation du compte.</p>
      </details>
      <button class="pri" data-a="save" style="margin:6px 0 0">Enregistrer</button>
      <button class="sec" data-a="close" style="margin:6px 0 0">Annuler</button></div>`;
    m.addEventListener('click', async (e) => {
      const t = e.target;
      if (t === m || t.dataset.a === 'close') return m.remove();
      if (t.dataset.a !== 'save') return;
      const num = (id, min, max, def) => Math.min(max, Math.max(min, Number(m.querySelector(id).value) || def));
      const pmin = num('#s-pmin', 2, 120, 6);
      SET = {
        ...SET, // conserve aussi riskAccepted
        grace: num('#s-grace', 3, 120, 15),
        workers: num('#s-workers', 1, 3, 3),
        syncDelay: num('#s-sync', 3, 600, 20),
        blockMedia: m.querySelector('#s-block').checked,
        pauseMin: pmin,
        pauseMax: Math.max(pmin, num('#s-pmax', 2, 180, 12)),
        safetyPause: PLAN.pro ? num('#s-safety', 5, 1800, 20) : SET.safetyPause,
        swap: m.querySelector('#s-swap').checked,
        lang: m.querySelector('#s-lang').value,
      };
      await saveSettings();
      if (typeof TTS_I18N !== 'undefined') TTS_I18N.set(SET.lang);
      send({ type: 'reset-block' });
      m.remove();
      render();
      toast('Réglages enregistrés.');
    });
    root.append(m);
  }
  // ── Init ──
  // Compte réellement connecté : le lien du profil (mis à jour par l'appli) prime sur les données de la page
  // (figées au chargement), qui ne servent que de secours.
  const ssrHandle = () => {
    try {
      const d = JSON.parse(document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__').textContent);
      const u = d.__DEFAULT_SCOPE__['webapp.app-context'].user?.uniqueId;
      return u ? `@${u}` : '';
    } catch {
      return '';
    }
  };
  const liveHandle = () => currentHandle() || ssrHandle();

  // Recharge les données si le compte a changé depuis la dernière lecture (changement de compte sans rechargement).
  async function loadAccount() {
    const { settings } = await chrome.storage.local.get('settings');
    SET = { ...DEFAULT_SET, ...(settings || {}) };
    if (typeof TTS_I18N !== 'undefined') TTS_I18N.set(SET.lang);
    const handle = (await waitFor(currentHandle, 8000)) || ssrHandle() || '@guest';
    if (handle === ACCOUNT) return;
    ACCOUNT = handle;
    send({ type: 'account', account: ACCOUNT });
    const st = await chrome.storage.local.get([stateKey(), 'state', 'jobs', 'queueState']);
    QS = st.queueState || {};
    await refreshPlan();
    S = st[stateKey()] || { videos: {}, order: [], collections: [], confirmed: false };
    normalizeState();
    J = st.jobs || {};
    hist = [];
    const old = st.state;
    legacyState = !st[stateKey()] && old && Object.keys(old.videos || {}).length ? old : null;
  }

  // Champs ajoutés au fil des versions : un ancien état enregistré doit rester utilisable.
  function normalizeState() {
    S.errors ||= {};
    S.log ||= [];
    S.pinned ||= [];
    S.recent ||= [];
    S.colCounts ||= {};
    S.colInfo ||= {};
  }

  // Refuse d'agir si le compte a changé sous nos pieds : on ne touche jamais aux favoris d'un autre compte.
  function accountChanged() {
    const h = liveHandle();
    if (h && h !== ACCOUNT) {
      toast(`Le compte a changé (${h}). Ferme puis rouvre l’extension.`);
      return true;
    }
    return false;
  }

  async function open() {
    await (ready = loadAccount());
    if (legacyState && confirm(`Des favoris triés avant la séparation par compte ont été trouvés. Les reprendre pour ${ACCOUNT} ?`)) {
      S = legacyState;
      normalizeState();
      legacyState = null;
      await save();
      await chrome.storage.local.remove('state'); // un seul compte peut les reprendre
    }
    ov.hidden = false;
    render();
  }
  function close() {
    ov.hidden = true;
  }

  async function initUI() {
    ready = loadAccount();

    host = document.createElement('div');
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style><button class="fab">⇄ Trier mes favoris</button><div class="ov" hidden></div>`;
    document.documentElement.append(host);
    ov = root.querySelector('.ov');
    if (typeof TTS_I18N !== 'undefined') TTS_I18N.attach(root);

    root.querySelector('.fab').onclick = open;
    ov.addEventListener('click', (e) => {
      const t = e.target;
      if (t.classList.contains('x')) close();
      if (t.classList.contains("acct-btn")) accountMenu();
      if (t.id === 'settings-btn') settingsMenu();
      if (t.id === 'q-resume') send({ type: 'resume-queue' });
      if (t.id === 'q-state') {
        tab = 'state';
        render();
      }
      if (t.id === 'lang-btn') {
        SET.lang = TTS_I18N.lang === 'en' ? 'fr' : 'en';
        saveSettings();
        TTS_I18N.set(SET.lang);
        render();
      }
      if (t.id === "stop") {
        cancelOp = true;
        toast("Arrêt en cours…");
      }
      if (t.dataset.tab) {
        tab = t.dataset.tab;
        render();
      }
    });
    document.addEventListener(
      'keydown',
      (e) => {
        if (ov.hidden || root.querySelector('.modal')) return;
        const target = e.composedPath()[0];
        const typing = ['INPUT', 'TEXTAREA'].includes(target?.tagName);
        if (e.key === 'Escape') {
          if (typing) target.blur();
          else close();
          return;
        }
        if (tab !== 'deck' || typing) return;
        const card = ov.querySelector('.card');
        const keepLeft = keepSign() < 0;
        const map = { ArrowLeft: keepLeft ? 'keep' : 'del', ArrowRight: keepLeft ? 'del' : 'keep', ArrowUp: 'col' };
        if (map[e.key] && card) {
          e.preventDefault();
          e.stopPropagation();
          fly(card, map[e.key]);
        } else if (/^[1-9]$/.test(e.key) && card) {
          // touches 1 à 9 : ranger dans la collection numérotée du panneau
          const chip = ov.querySelectorAll('.chips .chip')[Number(e.key) - 1];
          if (chip) {
            e.preventDefault();
            e.stopPropagation();
            dropOn(card, chip);
          }
        } else if (e.key.toLowerCase() === 'z') undo();
      },
      true,
    );
    chrome.storage.onChanged.addListener((ch) => {
      if (ch.license || ch.usage) refreshPlan();
      if (ch.queueState) {
        QS = ch.queueState.newValue || {};
        paintQueueChip();
        if (!ov.hidden && tab === 'state') renderBody();
      }
      if (ch.jobs) {
        J = ch.jobs.newValue || {};
        paintQueueChip();
        if (!ov.hidden && (tab === 'del' || tab === 'state')) renderBody();
      }
    });

    // reprise d'une action interrompue par un rechargement de la page (voir openMyFavorites)
    const resume = sessionStorage.getItem('tts-resume');
    if (resume) {
      sessionStorage.removeItem('tts-resume');
      await open();
      if (resume === 'scan') scanFavorites();
      else if (resume === 'collections') refreshCollections(); // ne relance PAS toute la lecture des favoris
      else if (resume === 'sync') {
        tab = 'cols';
        render();
        syncCollections();
      } else if (resume === 'sync-auto') syncCollections({ auto: true }); // on reste sur l'écran de tri
    }
  }

  (async () => {
    const who = await send({ type: 'whoami' });
    if (who?.job) runJob(who.job, who.account);
    else initUI();
  })();
})();
