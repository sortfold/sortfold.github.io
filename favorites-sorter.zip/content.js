(() => {
  if (window.top !== window) return;
  const _tr = (s) => (typeof TTS_I18N !== 'undefined' ? TTS_I18N.tr(s) : s);
  const confirm = (m) => window.confirm(_tr(m));
  const alert = (m) => window.alert(_tr(m));
  const prompt = (m, d) => window.prompt(_tr(m), d);

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const send = (msg) => chrome.runtime.sendMessage(msg);

  // ───────────────────────── Mode « job » : retirer un favori ─────────────────────────
  // Vérifié sur tiktok.com (FR) : le bouton est un <div role="button" data-e2e="favorite-icon">.
  // Son aria-label ne change JAMAIS (« Ajouter aux Favoris… » même si déjà favori) :
  // l'état se lit sur la couleur de l'icône (jaune #FACE15 = favori, blanc = non favori).
  // La page contient plusieurs vidéos (flux) : on prend le bouton visible dans la fenêtre.
  function findFavButton() {
    const all = [...document.querySelectorAll('[data-e2e="favorite-icon"]')];
    return (
      all.find((el) => {
        const r = el.getBoundingClientRect();
        return r.height > 0 && r.top >= -10 && r.bottom <= innerHeight + 10;
      }) ||
      all[0] ||
      null
    );
  }

  // true = actuellement en favori, false = pas en favori, null = indéterminé
  function favState(btn) {
    const svg = btn?.querySelector('svg');
    if (!svg) return null;
    const m = getComputedStyle(svg).color.match(/\d+(\.\d+)?/g);
    if (!m) return null;
    const [r, g, b] = m.map(Number);
    return r > 200 && g > 170 && b < 90;
  }

  async function runJob(id, account) {
    const report = (status, note = '') => send({ type: 'job-result', id, status, note });
    // garde-fou : le retrait ne doit s'exécuter que sous le compte qui l'a demandé
    const handle = await waitFor(() => currentHandle(), 15000, 150);
    if (account && handle !== account) return report('error', `Ce retrait appartient à ${account} (connecté : ${handle || 'personne'})`);
    // Attentes actives (on agit dès que la page est prête) plutôt que des pauses fixes : c'est ce qui coûtait ~4 s par vidéo.
    // Le flux peut enchaîner sur une autre vidéo : on ne clique que sur le bouton de la bonne.
    const btn = await waitFor(() => location.href.includes(id) && findFavButton(), 25000, 150);
    if (!btn) return report('error', location.href.includes(id) ? 'Bouton favori introuvable (connexion ? captcha ?)' : 'La page affiche une autre vidéo');
    // L'icône est d'abord blanche le temps que TikTok charge l'état : on attend de la voir jaune (favori).
    let st = null;
    for (const end = Date.now() + 6000; Date.now() < end; ) {
      st = favState(findFavButton() || btn);
      if (st === true) break;
      await sleep(150);
    }
    if (st !== true) {
      // toujours pas jaune : deux lectures espacées avant de conclure « déjà retiré »
      await sleep(1200);
      st = favState(findFavButton() || btn);
      if (st === false) return report('done', 'Déjà retiré');
      if (st !== true) return report('error', 'État du favori illisible');
    }
    (findFavButton() || btn).click();
    // vérification : dès que l'icône n'est plus jaune (pas d'attente fixe)
    let after = true;
    for (const end = Date.now() + 5000; Date.now() < end; ) {
      await sleep(150);
      after = favState(findFavButton() || btn);
      if (after === false) break;
    }
    if (after === false) return report('done');
    if (after === true) return report('error', 'Le clic n’a pas retiré le favori');
    return report('unverified', 'Clic effectué, état non vérifiable');
  }
  // ───────────────────────── Mode « interface » ─────────────────────────
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, Segoe UI, sans-serif; }
    button { cursor: pointer; font: inherit; color: inherit; }
    .fab { position: fixed; right: 20px; bottom: 20px; z-index: 2147483646; background: #fe2c55; color: #fff; border: 0;
      border-radius: 999px; padding: 12px 18px; font-weight: 700; box-shadow: 0 6px 20px #0006; }
    .ov { position: fixed; inset: 0; z-index: 2147483647; background: #0b0b10; color: #f4f4f6; display: flex; flex-direction: column; }
    .ov[hidden] { display: none; }
    header { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-bottom: 1px solid #ffffff18; }
    .acct { color: #8a8a96; font-size: 12px; }
    header .tabs { display: flex; gap: 6px; flex: 1; flex-wrap: nowrap; overflow-x: auto; scrollbar-width: none; }
    .tab { background: transparent; border: 1px solid #ffffff25; border-radius: 999px; padding: 6px 13px; white-space: nowrap; }
    /* en-tête sur une seule ligne : sur les écrans moyens, les boutons secondaires ne gardent que leur icône (nom dans l'infobulle) */
    @media (max-width: 1500px) { .tab.ico .lbl { display: none; } .tab.ico { padding: 6px 10px; } header .acct { display: none; } }
    .tab.on { background: #fff; color: #000; border-color: #fff; }
    .x { background: transparent; border: 0; font-size: 22px; }
    main { flex: 1; overflow: auto; display: flex; flex-direction: column; align-items: center; padding: 16px; }
    /* hauteur de la carte calée sur l'écran : les boutons sous la carte restent visibles, même sur un portable de 768 px de haut */
    .stage { position: relative; height: clamp(280px, calc(100vh - 290px), 680px); aspect-ratio: 9 / 16; max-width: 90vw; margin-top: 4px; flex-shrink: 0; }
    .toprow { display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 2px; }
    .toprow .count { margin: 0; }
    .toprow .sec.small { margin: 0; }
    .card { position: absolute; inset: 0; border-radius: 18px; overflow: hidden; background: #000; box-shadow: 0 10px 40px #000a;
      touch-action: none; will-change: transform; }
    .card iframe { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: #111; }
    /* avant ▶ : vignette (ou fond violet si elle a expiré) et début de la description */
    .poster, .noplay { position: absolute; inset: 0; background: linear-gradient(160deg, #2a1d4a, #15151c) center/cover; }
    .poster .desc, .noplay .desc { position: absolute; left: 0; right: 0; top: 0; padding: 16px 14px 30px; font-size: 14px; line-height: 1.4; color: #fff;
      background: linear-gradient(#000d 60%, #0000); display: -webkit-box; -webkit-line-clamp: 5; -webkit-box-orient: vertical; overflow: hidden;
      text-shadow: 0 1px 2px #000; pointer-events: none; }
    .poster[data-nothumb] .desc, .noplay[data-nothumb] .desc { top: 24px; font-size: 16px; -webkit-line-clamp: 12; background: none; }
    /* ▶ au centre, dans le trou de la couche de glissement */
    .play { position: absolute; left: 50%; top: calc(50% + 22px); translate: -50% -50%; width: 72px; height: 72px; border-radius: 50%;
      border: 2px solid #ffffff60; background: #000a; color: #fff; font-size: 28px; padding: 0 0 0 6px; cursor: pointer; box-shadow: 0 6px 20px #0008; }
    .play:hover, .play:focus-visible { background: #fe2c55; border-color: #fe2c55; }
    .drag { position: absolute; left: 0; right: 0; cursor: grab; }
    /* La couche de glissement couvre toute la carte (on glisse de n'importe où) sauf : un trou autour du ▶ central,
       pour lancer/mettre en pause la vidéo, et les 44 px du bas où se trouvent les commandes du lecteur. */
    .drag.top, .drag.bot { display: none; }
    .drag.mid { top: 0; bottom: 44px; clip-path: polygon(evenodd, 0 0, 100% 0, 100% 100%, 0 100%, 0 0,
      calc(50% - 44px) calc(50% - 22px), calc(50% + 44px) calc(50% - 22px), calc(50% + 44px) calc(50% + 66px),
      calc(50% - 44px) calc(50% + 66px), calc(50% - 44px) calc(50% - 22px)); }
    .tag { position: absolute; top: 60px; padding: 6px 14px; border: 4px solid; border-radius: 12px; font-weight: 800; font-size: 32px;
      opacity: 0; pointer-events: none; letter-spacing: 1px; background: #0009; }
    .tag.keep { right: 16px; color: #3ddc84; transform: rotate(12deg); }
    .tag.del { left: 16px; color: #ff4d5e; transform: rotate(-12deg); }
    .undobar { position: fixed; left: 50%; bottom: 22px; translate: -50% 0; background: #1a1a22; border: 1px solid #ffffff25; border-radius: 12px; padding: 8px 10px 8px 14px; z-index: 6; box-shadow: 0 8px 30px #000a; display: flex; gap: 10px; align-items: center; font-size: 13px; }
    .undobar button { background: #fe2c55; border: 0; border-radius: 8px; padding: 6px 10px; color: #fff; font-weight: 700; }
    .tag.col { left: 50%; top: auto; bottom: 90px; color: #4db8ff; translate: -50% 0; }
    .btns { display: flex; gap: 10px; margin-top: 10px; align-items: flex-end; }
    .rb { width: 76px; height: 64px; border-radius: 16px; border: 2px solid; background: #15151c; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; padding: 2px; position: relative; transition: transform .12s, background .12s; }
    .rb:hover { background: #1f1f29; transform: translateY(-2px); }
    .rb .ic { font-size: 22px; line-height: 1; }
    .rb small { font-size: 11px; font-weight: 600; color: #e6e6ee; }
    .rb kbd { position: absolute; top: 3px; right: 5px; font: 600 9px system-ui; color: #8a8a96; }
    .rb.del { color: #ff4d5e; } .rb.keep { color: #3ddc84; } .rb.col { color: #4db8ff; }
    .rb.undo { width: 56px; height: 52px; color: #ccc; border-color: #ffffff30; }
    .rb.undo .ic { font-size: 17px; }
    /* accessibilité : repère de focus visible au clavier, animations réduites si le système le demande */
    button:focus-visible, input:focus-visible, select:focus-visible, summary:focus-visible, a:focus-visible { outline: 3px solid #4db8ff; outline-offset: 2px; }
    @media (prefers-reduced-motion: reduce) { * { transition-duration: .01ms !important; animation-duration: .01ms !important; animation-iteration-count: 1 !important; } }
    .hint { color: #8a8a96; font-size: 12px; margin-top: 10px; text-align: center; max-width: 420px; }
    .count { color: #8a8a96; font-size: 13px; margin-bottom: 8px; }
    .empty { text-align: center; max-width: 460px; margin: auto; line-height: 1.5; }
    .empty h2 { margin: 0 0 8px; }
    .pri { background: #fe2c55; border: 0; border-radius: 10px; padding: 12px 18px; font-weight: 700; color: #fff; margin: 6px; }
    .sec { background: #ffffff14; border: 1px solid #ffffff25; border-radius: 10px; padding: 10px 16px; margin: 6px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 10px; width: 100%; max-width: 1000px; }
    .item { position: relative; aspect-ratio: 9/14; background: #1b1b24 center/cover; border-radius: 10px; overflow: hidden; }
    .item a { position: absolute; inset: 0; }
    .item .lbl { position: absolute; left: 0; right: 0; bottom: 0; padding: 6px; font-size: 11px; background: #000b; display: flex; gap: 6px; align-items: center; justify-content: space-between; }
    .item .lbl button { background: #ffffff22; border: 0; border-radius: 6px; padding: 2px 6px; font-size: 11px; }
    .item .lbl .acts { display: flex; gap: 3px; }
    .syncbtn { background: #fe2c55; border: 0; border-radius: 10px; padding: 10px 12px; font-weight: 700; font-size: 13px; color: #fff; text-align: left; }
    .syncbtn:disabled { background: #3a3a46; color: #8a8a96; cursor: default; }
    .sec.small { padding: 5px 12px; font-size: 12px; margin: 0 0 6px; }
    .err { color: #ff4d5e; font-size: 13px; max-width: 1000px; width: 100%; margin: 0 0 8px; }
    .ren { background: none; border: 0; color: #8a8a96; font-size: 14px; }
    h3 { align-self: flex-start; max-width: 1000px; width: 100%; margin: 18px auto 10px; }
    .modal { position: fixed; inset: 0; background: #000a; display: grid; place-items: center; z-index: 2147483647; }
    .box { background: #1a1a22; border-radius: 16px; padding: 18px; width: min(360px, 92vw); max-height: 80vh; overflow: auto; }
    .box button.opt { display: block; width: 100%; text-align: left; background: #ffffff10; border: 0; border-radius: 10px; padding: 12px; margin-bottom: 8px; }
    .box input { width: 100%; padding: 10px; border-radius: 10px; border: 1px solid #ffffff30; background: #0b0b10; color: #fff; margin: 6px 0; }
    /* couleurs explicites : sans elles, le texte de la fenêtre suit la couleur de la page TikTok */
    .modal { color: #f4f4f6; font-size: 14px; }
    .box { color: #f4f4f6; border: 1px solid #ffffff18; box-shadow: 0 10px 40px #000a; }
    .box b { font-size: 15px; }
    .box .hint { color: #8a8a96; }
    .box button.opt { color: #f4f4f6; font-size: 14px; line-height: 1.35; }
    .box button.opt:hover:not(:disabled) { background: #ffffff1c; }
    .box button.opt.danger { color: #ff6b7a; background: #ff4d5e18; }
    .box button.opt.danger:hover:not(:disabled) { background: #ff4d5e2e; }
    .box button:disabled { opacity: .4; cursor: default; }
    .box .sec { color: #f4f4f6; }
    .box label.opt { box-sizing: border-box; width: 100%; text-align: left; background: #ffffff10; border-radius: 10px; padding: 12px; margin-bottom: 8px; font-size: 14px; line-height: 1.35; color: #f4f4f6; }
    .box label.opt:hover { background: #ffffff1c; }
    .box hr { border: 0; border-top: 1px solid #ffffff18; margin: 10px 0; }
    .qchip { position: fixed; right: 16px; bottom: 16px; z-index: 6; max-width: 330px; background: #1a1a22; border: 1px solid #ffffff25; border-radius: 12px; padding: 10px 14px; font-size: 13px; line-height: 1.45; box-shadow: 0 8px 30px #000a; } .qchip > div + div { margin-top: 6px; } .qchip .bad { color: #ff8a97; } .qchip button { background: #ffffff18; border: 1px solid #ffffff30; border-radius: 8px; padding: 3px 9px; margin-left: 2px; font-size: 12px; color: #f4f4f6; }
    .adv { margin: 10px 0 4px; border-top: 1px solid #ffffff18; padding-top: 8px; } .adv summary { cursor: pointer; color: #4db8ff; margin-bottom: 6px; } .box select { width: 100%; padding: 9px; border-radius: 10px; border: 1px solid #ffffff30; background: #0b0b10; color: #fff; margin-top: 4px; }
    .quick { text-align: left; max-width: 440px; margin: 10px auto 16px; padding-left: 22px; line-height: 1.55; } .quick li { margin: 6px 0; }
    .tab.don { border-color: #ffb454aa; color: #ffcf8a; }
    .prog { background: #1b1830; border-bottom: 1px solid #ffffff20; padding: 10px 16px 8px; font-size: 14px; } .prog-row { display: flex; align-items: center; gap: 10px; } .prog-sub { color: #cfc8ff; margin-left: auto; font-variant-numeric: tabular-nums; max-width: 55%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .prog small { display: block; color: #a9a3c9; margin-top: 4px; font-size: 12px; line-height: 1.4; } .prog .bar { max-width: none; margin: 8px 0 4px; height: 8px; } .bar.ind i { width: 30%; animation: indet 1.3s ease-in-out infinite; } @keyframes indet { 0% { margin-left: -30%; } 100% { margin-left: 100%; } } .spin { width: 16px; height: 16px; border: 3px solid #ffffff30; border-top-color: #fe2c55; border-radius: 50%; animation: spin .8s linear infinite; flex: none; } .spin.big { width: 44px; height: 44px; border-width: 5px; margin: 0 auto 14px; } @keyframes spin { to { transform: rotate(360deg); } }
    .tab.pro { background: linear-gradient(135deg, #ff2d75, #8a4dff); border-color: transparent; color: #fff; font-weight: 700; } .perks { margin: 8px 0 10px; padding-left: 20px; line-height: 1.65; }
    .rep { white-space: pre-wrap; word-break: break-word; background: #0b0b10; border: 1px solid #ffffff18; border-radius: 8px; padding: 8px; font-size: 11px; max-height: 260px; overflow: auto; color: #cfcfe0; user-select: text; }
    .toast { position: fixed; bottom: 24px; left: 50%; translate: -50% 0; background: #fff; color: #000; padding: 10px 16px; border-radius: 10px; z-index: 2147483647; }
    .deckwrap { display: flex; gap: 56px; justify-content: center; align-items: flex-start; width: 100%; }
    .deckmain { display: flex; flex-direction: column; align-items: center; }
    .cols { width: 200px; max-height: calc(100vh - 130px); overflow: auto; display: flex; flex-direction: column; gap: 6px; padding-right: 4px; }
    .cols h4 { margin: 0 0 4px; font-size: 12px; color: #8a8a96; text-transform: uppercase; letter-spacing: .5px; }
    .chip { display: flex; justify-content: space-between; align-items: center; gap: 8px; text-align: left; background: #1a1a22;
      border: 1px solid #ffffff20; border-radius: 10px; padding: 9px 12px; font-size: 13px; }
    .chip span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .chip small { color: #8a8a96; }
    .chip.new { border-style: dashed; color: #4db8ff; }
    .chip:hover { background: #23232e; }
    .chip.hot { background: #1e3a5f; border-color: #4db8ff; transform: scale(1.04); }
    .chip.ready { box-shadow: 0 0 0 2px #4db8ff; }
    .badge { display: inline-block; min-width: 16px; padding: 0 5px; margin-left: 4px; border-radius: 9px; background: #fe2c55; color: #fff; font-size: 11px; font-weight: 700; text-align: center; }
    .selbar { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin: 0 0 10px; }
    .selbar b { margin-right: 6px; }
    .item.picked { outline: 3px solid #4db8ff; }
    .item .chk { position: absolute; top: 6px; left: 6px; font-size: 20px; background: #000a; border-radius: 6px; padding: 0 4px; }
    .item[data-sel] { cursor: pointer; }
    .sec.danger { color: #ff6b7a; border-color: #ff4d5e55; }
    .state { width: 100%; max-width: 760px; }
    .state section { background: #15151c; border: 1px solid #ffffff14; border-radius: 12px; padding: 14px 16px; margin-bottom: 12px; }
    .state h3 { margin: 0 0 8px; width: auto; max-width: none; }
    .state p { margin: 0 0 8px; }
    .state .bad { color: #ff6b7a; }
    .state .sec { margin: 4px 6px 4px 0; }
    .state .err { max-width: none; margin: 0 0 8px; }
    .log { list-style: none; padding: 0; margin: 0; max-height: 320px; overflow: auto; font-size: 13px; line-height: 1.7; }
    .log .t { color: #8a8a96; margin-right: 6px; font-variant-numeric: tabular-nums; }
    .log a { color: #4db8ff; }
    .fld { display: block; margin: 10px 0; font-size: 13px; color: #c8c8d2; }
    .fld input[type="number"] { display: block; width: 100%; margin-top: 4px; }
    .fld.chk { display: flex; gap: 8px; align-items: center; }
    .fld.chk input { width: auto; margin: 0; }
    .warn { font-size: 13px; line-height: 1.5; color: #e6c6c9; margin: 8px 0; }
    .colsearch { width: 100%; padding: 8px 10px; border-radius: 10px; border: 1px solid #ffffff25; background: #0b0b10; color: #f4f4f6; font-size: 13px; }
    .chips { display: flex; flex-direction: column; gap: 6px; }
    .chip kbd { display: inline-block; min-width: 18px; margin-right: 6px; padding: 0 4px; border-radius: 5px; background: #ffffff18; color: #b5b5c0; font: 11px system-ui; text-align: center; }
    .chip .pin { font-style: normal; color: #6a6a78; opacity: 0; margin-left: 4px; }
    .chip:hover .pin, .chip .pin.on { opacity: 1; }
    .chip .pin.on { color: #ffcf4d; }
    .stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin: 14px auto 16px; max-width: 380px; }
    .stats div { background: #15151c; border: 1px solid #ffffff18; border-radius: 12px; padding: 10px 12px; }
    .stats b { display: block; font-size: 24px; background: linear-gradient(135deg, #ff2d75, #8a4dff); -webkit-background-clip: text; background-clip: text; color: transparent; }
    .stats span { color: #a9a9b6; font-size: 12px; }
    .nudge { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 8px; max-width: 420px; margin: 14px auto 0; padding: 10px 12px; background: #1b1830; border: 1px solid #8a4dff55; border-radius: 12px; font-size: 13px; line-height: 1.4; text-align: left; }
    .nudge span { flex: 1 1 220px; }
    .nudge .pri { margin: 0; padding: 7px 12px; font-size: 13px; background: linear-gradient(135deg, #ff2d75, #8a4dff); }
    .nudge .sec { margin: 0; padding: 6px 10px; font-size: 13px; }
    .ob { text-align: center; width: min(400px, 92vw); } .ob-ico { font-size: 40px; margin: 4px 0 8px; } .ob b { font-size: 18px; }
    .ob-keys { display: grid; gap: 6px; margin: 10px 0 12px; color: #f4f4f6; } .ob-keys kbd { display: inline-block; min-width: 30px; padding: 2px 8px; margin-right: 8px; border-radius: 7px; background: #ffffff18; border: 1px solid #ffffff30; text-align: center; font: 600 15px system-ui; }
    .ob-dots { display: flex; justify-content: center; gap: 6px; margin: 12px 0; } .ob-dots i { width: 8px; height: 8px; border-radius: 50%; background: #ffffff30; } .ob-dots i.on { background: #fe2c55; }
    .ob-nav { display: flex; justify-content: space-between; align-items: center; } .ob-nav .pri { margin: 0; }
    /* bordure du choix en cours : un « box-shadow » sans flou ne recalcule pas la mise en page */
    .card.c-keep { box-shadow: 0 0 0 3px #3ddc8488, 0 10px 40px #000a; }
    .card.c-del { box-shadow: 0 0 0 3px #ff4d5e88, 0 10px 40px #000a; }
    .card.c-col { box-shadow: 0 0 0 3px #4db8ff88, 0 10px 40px #000a; }
    .card.c-keep.c-sure { box-shadow: 0 0 0 6px #3ddc84, 0 0 34px #3ddc8466; }
    .card.c-del.c-sure { box-shadow: 0 0 0 6px #ff4d5e, 0 0 34px #ff4d5e66; }
    .card.c-col.c-sure { box-shadow: 0 0 0 6px #4db8ff, 0 0 34px #4db8ff66; }
    /* rangement automatique (bêta) */
    .suggest { position: absolute; top: 10px; left: 50%; translate: -50% 0; z-index: 3; max-width: 92%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; background: #10233acc; backdrop-filter: blur(6px); border: 1px solid #4db8ff; border-radius: 999px; padding: 6px 12px; color: #fff; font-weight: 700; font-size: 13px; box-shadow: 0 4px 18px #0008; }
    .suggest small { color: #9fd6ff; font-weight: 600; } .suggest kbd { font: 600 10px system-ui; background: #ffffff22; border-radius: 5px; padding: 1px 5px; margin-left: 4px; }
    .suggest:hover { background: #1e3a5f; }
    .chip.sugg { border-color: #4db8ff; box-shadow: 0 0 0 2px #4db8ff66; background: #16283c; }
    .tagbeta { display: inline-block; background: linear-gradient(135deg, #ff2d75, #8a4dff); color: #fff; border-radius: 6px; padding: 0 6px; font-size: 11px; margin-left: 4px; vertical-align: 1px; }
    .fld.beta { align-items: flex-start; background: #ffffff0a; border: 1px solid #8a4dff55; border-radius: 10px; padding: 10px; }
    .fld.beta small { display: block; color: #a9a3c9; margin-top: 3px; line-height: 1.4; }
    .auto { width: 100%; max-width: 1000px; }
    .betanote { background: #1b1830; border: 1px solid #8a4dff66; border-radius: 12px; padding: 10px 14px; font-size: 13px; line-height: 1.5; margin: 0 0 8px; }
    .item[data-nothumb] { background: linear-gradient(160deg, #2a1d4a, #15151c); }
    .item .desc { position: absolute; left: 0; right: 0; top: 0; padding: 34px 8px 10px; font-size: 11px; line-height: 1.35; color: #fff; background: linear-gradient(#000d 60%, #0000); display: -webkit-box; -webkit-line-clamp: 6; -webkit-box-orient: vertical; overflow: hidden; pointer-events: none; text-shadow: 0 1px 2px #000; }
    .howto { margin: 0 0 8px; padding: 8px 14px 8px 30px; background: #15151c; border: 1px solid #ffffff14; border-radius: 12px; font-size: 13px; line-height: 1.6; color: #d8d8e2; }
    .auto .item .acts button { font-size: 13px; padding: 2px 8px; }
    .auto .item.auto-it { cursor: pointer; } .auto .item.auto-it:not(.picked) { opacity: .55; }
    .autobar { position: sticky; bottom: 0; padding: 12px 0; background: linear-gradient(transparent, #0b0b10 40%); text-align: center; }
    .auto input { width: 100%; padding: 8px 10px; border-radius: 10px; border: 1px solid #ffffff30; background: #0b0b10; color: #f4f4f6; }
    .fld.rule { display: grid; grid-template-columns: 180px 1fr; align-items: center; gap: 8px; margin: 6px 0; } .fld.rule input { margin: 0; }
    /* lecteur refusé par TikTok : vignette ou description à la place, bouton au centre (dans le trou de la couche de glissement) */
    .noplay-msg { position: absolute; left: 12px; right: 12px; bottom: 56px; text-align: center; font-size: 12px; color: #d8d8e2; background: #000a; border-radius: 8px; padding: 6px 8px; }
    .noplay-open { position: absolute; left: 50%; top: calc(50% + 22px); translate: -50% -50%; z-index: 2; white-space: nowrap; background: #fe2c55; color: #fff; text-decoration: none; font-weight: 700; font-size: 13px; padding: 9px 14px; border-radius: 999px; box-shadow: 0 6px 20px #0008; }
    .card.top { z-index: 2; transition: transform .18s ease-out, opacity .18s; }
    .card.next { z-index: 1; transform: scale(.94) translateY(16px); opacity: .45; pointer-events: none; }
    .swap .tag.keep { right: auto; left: 16px; transform: rotate(-12deg); }
    .swap .tag.del { left: auto; right: 16px; transform: rotate(12deg); }
    @media (max-width: 860px) { .cols { display: none; } }
    .bar { width: 100%; max-width: 420px; height: 6px; background: #ffffff20; border-radius: 3px; overflow: hidden; margin: 10px auto; }
    .bar i { display: block; height: 100%; background: #fe2c55; }
  `;

  const EMPTY_STATE = { videos: {}, order: [], collections: [], confirmed: false };
  let S = EMPTY_STATE;
  let J = {};
  let QS = {}; // état de la file de retraits (durée moyenne par vidéo, pause de sécurité) écrit par background.js
  let tab = 'deck';
  let hist = [];
  let host, root, ov;
  let scanning = false;
  let ready = Promise.resolve();
  let syncing = false;
  let cancelOp = false; // « ✕ Stop » : les boucles longues (import, synchro) s'arrêtent à la prochaine étape
  const checkCancel = () => {
    if (cancelOp) throw new Error('Arrêté par toi.');
  };
  // Bouton « Synchroniser les collections » de l'écran de tri : libellé et état à jour sans redessiner la carte.
  const updateSyncBtn = () => {
    const b = ov?.querySelector('#deck-sync');
    if (!b) return;
    const n = pendingSync();
    b.textContent = syncing ? '⏳ Synchronisation…' : `⇄ Synchroniser les collections (${n})`;
    b.disabled = syncing || scanning || !n;
  };
  // L'import s'est-il arrêté avant la fin (page fermée en cours de route) ? Le total vient de « Publications N ».
  const importIncomplete = () => !!S.importTotal && Object.keys(S.videos).length < S.importTotal * 0.98;
  // Reprise automatique de l'import quand TikTok a cessé de donner la suite de la liste (limitation passagère, vue sur
  // un vrai compte : arrêts à 574 puis 862 / 5264). On ne prend jamais la main sur l'onglet pendant que l'utilisateur
  // navigue sur TikTok : la reprise n'a lieu que panneau ouvert (sinon à sa prochaine ouverture).
  const AUTO_RESUME_MS = 12 * 60e3;
  const hhmm = (t) => new Date(t).toLocaleTimeString(typeof TTS_I18N !== 'undefined' ? TTS_I18N.locale() : 'fr-FR', { hour: '2-digit', minute: '2-digit' });
  const resumeLabel = () =>
    importIncomplete()
      ? `↻ Reprendre l’import (${S.order.length} / ${S.importTotal})${S.importResumeAt ? ` · auto à ${hhmm(S.importResumeAt)}` : ''}`
      : '↻ Importer les nouveaux favoris';
  let autoResumeTimer = null;
  function armAutoResume() {
    clearTimeout(autoResumeTimer);
    if (!S.importResumeAt) return;
    autoResumeTimer = setTimeout(() => {
      if (!S.importResumeAt || !importIncomplete()) return;
      if (ov.hidden || scanning || syncing) return armAutoResume.retry(); // pas maintenant : on réessaie dans 1 min
      delete S.importResumeAt;
      trace('import : reprise automatique');
      scanFavorites();
    }, Math.max(0, S.importResumeAt - Date.now()));
  }
  armAutoResume.retry = () => {
    clearTimeout(autoResumeTimer);
    autoResumeTimer = setTimeout(armAutoResume, 60e3);
  };
  const busyChanged = () => {
    const b = ov?.querySelector('#stop');
    if (b) b.hidden = !(scanning || syncing);
    const r = ov?.querySelector('#resume');
    if (r) r.hidden = scanning;
    updateSyncBtn();
  };
  // Fin d'une opération longue : si la carte affichée est toujours la bonne, on ne met à jour que ce qui a changé autour
  // d'elle (compteurs, collections, boutons), sans recharger la vidéo qu'on est peut-être en train de regarder.
  function softRender() {
    const top = tab === 'deck' && !ov.hidden ? topCard() : null;
    const ids = pile();
    if (!top || top.dataset.id !== ids[0]) return render();
    const c = ov.querySelector('.deckmain .count');
    if (c) c.textContent = `${ids.length} à trier`;
    const bar = ov.querySelector('.deckmain .bar i');
    if (bar) bar.style.width = `${((S.order.length - ids.length) / S.order.length) * 100}%`;
    const r = ov.querySelector('#resume');
    if (r) r.textContent = resumeLabel();
    ensureNext();
    paintSuggestion();
    refreshChips();
    busyChanged();
    const st = ov.querySelector('[data-tab="state"]');
    const pc = problemCount();
    if (st) st.innerHTML = `Suivi${pc ? ` <span class="badge">${pc}</span>` : ''}`;
    paintQueueChip();
    paintProgress();
  }
  const busyGuard = () => {
    if (!(scanning || syncing)) return false;
    toast('Une opération est déjà en cours (import ou synchronisation). Clique sur ✕ Stop pour l’arrêter.');
    return true;
  };

  // Les données sont séparées par compte TikTok (clé « state:@pseudo »), sinon un changement de compte
  // afficherait les favoris de l'autre.
  let ACCOUNT = '';
  let legacyState = null; // données d'avant la séparation par compte (clé « state »)
  const stateKey = () => `state:${ACCOUNT}`;
  // Écritures regroupées : l'état complet pèse plusieurs Mo avec des milliers de vidéos, et chaque écriture le recopie en
  // entier. On attend donc un court instant (SAVE_DELAY) pour n'écrire qu'une fois après une série de gestes, sans jamais
  // retarder plus de SAVE_MAX une écriture demandée. L'écran n'attend pas l'écriture (voir act) ; elle est forcée quand la
  // page se ferme ou passe en arrière-plan.
  const SAVE_DELAY = 150;
  const SAVE_MAX = 1500;
  let saving = null;
  let dirty = false;
  let saveTimer = null;
  let saveFirstAsk = 0;
  let saveWaiters = [];
  const writeState = () => {
    saving ||= (async () => {
      try {
        while (dirty) {
          dirty = false;
          await chrome.storage.local.set({ [stateKey()]: S });
        }
      } finally {
        saving = null;
      }
    })();
    return saving;
  };
  const flushSave = async () => {
    clearTimeout(saveTimer);
    saveTimer = null;
    saveFirstAsk = 0;
    const waiters = saveWaiters;
    saveWaiters = [];
    try {
      if (dirty) await writeState();
      else if (saving) await saving;
    } finally {
      waiters.forEach((w) => w());
    }
  };
  const save = () => {
    dirty = true;
    const now = Date.now();
    saveFirstAsk ||= now;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(flushSave, now - saveFirstAsk >= SAVE_MAX ? 0 : SAVE_DELAY);
    return new Promise((r) => saveWaiters.push(r));
  };
  addEventListener('pagehide', () => dirty && flushSave());
  document.addEventListener('visibilitychange', () => document.hidden && dirty && flushSave());

  // Réglages (globaux, pas par compte)
  const DEFAULT_SET = { grace: 15, pauseMin: 2, pauseMax: 5, workers: 3, syncDelay: 20, blockMedia: true, swap: false, riskAccepted: false, lang: 'auto', safetyPause: 20 };
  let SET = { ...DEFAULT_SET };
  const saveSettings = () => chrome.storage.local.set({ settings: SET });
  const keepSign = () => (SET.swap ? 1 : -1); // sens du glissement « garder » : -1 = vers la gauche

  // Journal des actions (les 300 dernières) : un retrait est irréversible, on garde de quoi retrouver la vidéo.
  const logAct = (a, id, name) => {
    S.log ||= [];
    S.log.unshift({ t: Date.now(), a, id, name });
    if (S.log.length > 300) S.log.length = 300;
  };

  // Collections dans l'ordre du panneau : épinglées, puis utilisées récemment, puis les autres.
  const orderedCollections = () => {
    const pin = (S.pinned || []).filter((c) => S.collections.includes(c));
    const rec = (S.recent || []).filter((c) => S.collections.includes(c) && !pin.includes(c));
    const rest = S.collections.filter((c) => !pin.includes(c) && !rec.includes(c));
    return [...pin, ...rec, ...rest];
  };
  const touchRecent = (name) => {
    S.recent = [name, ...(S.recent || []).filter((c) => c !== name)].slice(0, 30);
  };
  const profilePath = () => (document.querySelector('[data-e2e="nav-profile"]')?.getAttribute('href') || '').split(/[?#]/)[0]; // sans « ?lang=en » ni ancre
  const currentHandle = () => profilePath().replace(/^\//, '');
  const pile = () => S.order.filter((id) => S.videos[id].status === 'new');
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  function toast(text) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = text;
    root.append(t);
    setTimeout(() => t.remove(), 2800);
  }

  function addVideos(list) {
    let added = 0;
    const newer = []; // favoris plus récents que tout ce qu'on connaissait (ré-import)
    for (const v of list) {
      const known = S.videos[v.id];
      if (known) {
        // les vidéos importées avant l'ajout de la clé de vignette la récupèrent (nécessaire au rangement TikTok)
        if (!known.key && v.key) Object.assign(known, { key: v.key, thumb: known.thumb || v.thumb || '' });
        if (thumbOk(v.thumb) && v.thumb !== known.thumb) known.thumb = v.thumb; // adresse de vignette fraîche (les anciennes expirent)
        if (v.text && known.text !== v.text) known.text = v.text; // texte récupéré lors d'un nouvel import
        continue;
      }
      // une vidéo lue dans une collection avant d'être importée (les collections sont lues en premier) arrive déjà rangée
      const filedIn = S.filedIds?.[v.id];
      S.videos[v.id] = { id: v.id, url: v.url, thumb: v.thumb || '', key: v.key || null, text: v.text || '', status: filedIn ? 'kept' : 'new', collection: filedIn || null, synced: !!filedIn };
      if (filedIn) delete S.filedIds[v.id];
      if (v.newer) newer.push(v.id);
      else S.order.push(v.id);
      added++;
    }
    if (newer.length) {
      // Les plus récents passent juste APRÈS la carte affichée : jamais avant, car les boutons agissent sur la
      // première vidéo de la pile, qui doit rester celle qu'on a sous les yeux.
      const shownId = pile()[0];
      const at = shownId ? S.order.indexOf(shownId) + 1 : 0;
      S.order.splice(at, 0, ...newer);
    }
    return added;
  }

  // ── Utilitaires TikTok (comportements vérifiés sur le site) ──
  // Les vignettes de la liste des favoris et celles de la fenêtre « Sélectionner des vidéos » partagent la même clé
  // (nom de fichier sans signature) ; c'est le seul lien entre une case à cocher et une vidéo. Les images pas encore
  // chargées sont des data: URL, d'où le null.
  // ── Journal de diagnostic (sans données personnelles : noms de collections, compteurs, étapes) ──
  // Sert à comprendre pourquoi une synchronisation ne fait rien : l'utilisateur le copie depuis l'onglet Suivi.
  let TRACE = [];
  const trace = (msg) => {
    const t = new Date().toISOString().slice(11, 19);
    TRACE.push(`${t} ${msg}`);
    if (TRACE.length > 120) TRACE = TRACE.slice(-120);
    chrome.storage.local.set({ synclog: TRACE }).catch?.(() => {});
  };
  const traceReport = () =>
    [
      `Favorites Cleaner for TikTok ${chrome.runtime.getManifest?.().version || ''} · TikTok lang=${document.documentElement.lang} · ${navigator.userAgent.match(/Chrome\/[\d.]+/)?.[0] || ''}`,
      `videos=${Object.keys(S.videos || {}).length} pending=${pendingSync()} errors=${JSON.stringify(S.errors || {})}`,
      ...TRACE,
    ].join('\n');

  const keyOf = (src) => {
    if (!src || src.startsWith('data:')) return null;
    try {
      return new URL(src).pathname.split('~')[0].split('.')[0].split('/').pop() || null;
    } catch {
      return null;
    }
  };

  async function waitFor(fn, ms = 4000, every = 250) {
    for (const end = Date.now() + ms; Date.now() < end; ) {
      const r = fn();
      if (r) return r;
      await sleep(every);
    }
    return null;
  }

  // Certains boutons de TikTok (sous-onglets) ignorent un simple .click() : on rejoue la séquence complète.
  function realClick(el) {
    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
    }
  }

  // Appelle une fonction de bridge.js (contexte de la page) et attend sa réponse.
  function bridge(fn, args = {}, timeout = 2500) {
    return new Promise((resolve) => {
      const reqId = Math.random().toString(36).slice(2);
      const done = (res) => {
        window.removeEventListener('message', onMsg);
        clearTimeout(timer);
        resolve(res);
      };
      const onMsg = (e) => {
        if (e.source === window && e.data?.tts === 'result' && e.data.reqId === reqId) done(e.data);
      };
      const timer = setTimeout(() => done({ ok: false }), timeout);
      window.addEventListener('message', onMsg);
      window.postMessage({ tts: 'call', fn, args, reqId }, '*');
    });
  }

  // Change de sous-onglet du profil : « posts » | « collections ».
  const setSubTab = async (id) => !!(await bridge('subtab', { id })).ok;

  // libellés de TikTok selon la langue du site (sous-onglets du profil)
  const SUB_RE = { Publications: '(Publications|Videos|Vidéos|Posts|Publicaciones|Publicações|Post)', Collections: '(Collections|Colecciones|Coleções|Raccolte)' };
  // Repérage des éléments de TikTok : d'abord par leurs repères data-e2e (identiques dans toutes les langues, vérifiés en FR,
  // EN, ES et DE), le texte ne sert qu'en secours. Libellés relevés sur le vrai site (« Favoritos », « 5319 Beiträge »…).
  const TIKTOK_ERROR_RE = /Une erreur est survenue|Something went wrong|Nous sommes désolés|Algo salió mal|Se ha producido un error|Ocurrió un error|Etwas ist schiefgelaufen|Ein Fehler ist aufgetreten|Algo deu errado|Ocorreu um erro|Qualcosa è andato storto|Si è verificato un errore/;
  const FAV_TAB_RE = /^(Favoris|Favorites|Favourites|Favoritos|Favoriten|Preferiti)$/;
  const COLS_TEXT_RE = /Tes collections|Your collections|Tus colecciones|Deine Sammlungen|Suas coleções|Le tue raccolte/;
  const VIDEO_COUNT_RE = /(\d+)\s+v[ií]d[eé]o/i; // « 12 vidéos », « 12 vídeos », « 12 Videos », « 1 video »
  const subTabEl = (sub) =>
    document.querySelector(sub === 'Collections' ? '[data-e2e="sub-tab-collections"]' : '[data-e2e="sub-tab-posts"]') ||
    buttonByText(new RegExp('^' + (SUB_RE[sub] || sub)));
  const firstNumber = (t) => Number((String(t || '').match(/\d+/) || [])[0]) || 0;
  // Lien de collection → identifiant (le lien peut finir par « ?lang=es » quand TikTok est ouvert avec une langue forcée).
  const colIdOf = (href) => (String(href || '').split(/[?#]/)[0].match(/(\d+)\/?$/) || [])[1];
  const buttonByText =(re, root = document) => [...root.querySelectorAll('button, [role="button"]')].find((b) => re.test(b.textContent.trim()));

  // TikTok limite parfois l'accès à la liste (réponses vides) : la page affiche alors « Une erreur est survenue ». Mieux vaut
  // s'arrêter et le dire que d'insister, ce qui prolongerait la limitation.
  // Lire tout le texte de la page force le navigateur à recalculer sa mise en page : avec des milliers de vignettes chargées,
  // c'est très lent. On ne relit donc la page qu'une fois par seconde au plus (les boucles d'attente l'appellent bien plus souvent).
  let textAt = 0;
  let textCache = '';
  const pageText = () => {
    const now = Date.now();
    if (now - textAt >= 1000) {
      textAt = now;
      textCache = document.body.innerText;
    }
    return textCache;
  };
  // à chaque nouvelle étape (ouverture d'un onglet, nouvelle opération) : on relit la page, jamais l'ancien texte
  const pageTextReset = () => (textAt = 0);
  const tiktokError = () => TIKTOK_ERROR_RE.test(pageText());
  const RATE_MSG = 'TikTok limite l’accès à tes favoris en ce moment (« Une erreur est survenue »). Attends 10 à 30 minutes, recharge tiktok.com, puis relance.';
  function limited() {
    S.limitedAt = Date.now();
    save();
    return new Error(RATE_MSG);
  }

  // Ouvre Profil → Favoris → sous-onglet `sub` (« Publications » = les favoris, « Collections »).
  // Navigation interne à la page (sans rechargement), donc l'extension reste active.
  async function openMyFavorites(sub, resume) {
    pageTextReset();
    const nav = document.querySelector('[data-e2e="nav-profile"]');
    const href = profilePath();
    if (!href || !href.includes('@')) throw new Error('Connecte-toi à TikTok.');
    const norm = (p) => {
      try {
        return decodeURIComponent(p).toLowerCase().replace(/\/$/, '');
      } catch {
        return p.toLowerCase();
      }
    };
    const onProfile = () => norm(location.pathname) === norm(href);
    if (!onProfile()) {
      nav.click();
      if (!(await waitFor(onProfile, 6000))) {
        // le clic interne n'a pas abouti : on recharge sur le profil, puis l'action reprend toute seule.
        // Au plus 2 rechargements d'affilée : sans ce plafond, une page qui ne s'ouvre pas relancerait l'import en boucle.
        const reloads = Number(sessionStorage.getItem('tts-reloads') || 0);
        if (reloads >= 2) throw new Error('Impossible d’ouvrir ton profil (plusieurs rechargements sans succès).');
        sessionStorage.setItem('tts-reloads', String(reloads + 1));
        sessionStorage.setItem('tts-resume', resume || '');
        location.href = href;
        await sleep(20000);
        throw new Error('Impossible d’ouvrir ton profil.');
      }
    }
    const favTab = await waitFor(() => document.querySelector('[data-e2e="favorites-tab"]') || [...document.querySelectorAll('[role="tab"]')].find((t) => FAV_TAB_RE.test(t.textContent.trim())), 15000);
    if (!favTab) throw new Error('Onglet « Favoris » introuvable sur ton profil.');
    favTab.click();
    // Le sous-onglet se réinitialise parfois pendant le chargement de la liste : on clique puis on vérifie
    // que le bon contenu s'affiche, sinon on recommence.
    const shown =
      sub === 'Collections'
        ? () => document.querySelector('a[href*="/collection/"]') || COLS_TEXT_RE.test(pageText())
        : () => document.querySelector('[data-e2e="favorites-item-list"] a[href*="/video/"]');
    for (let attempt = 0; attempt < 4; attempt++) {
      const subBtn = await waitFor(() => subTabEl(sub), 10000);
      if (!subBtn) throw new Error(`Sous-onglet « ${sub} » introuvable.`);
      // pont vers la page (bridge.js) ; à défaut, un clic simulé (qui n'aboutit pas toujours)
      if (!(await setSubTab(sub === 'Collections' ? 'collections' : 'posts'))) realClick(subBtn);
      pageTextReset();
      if (await waitFor(() => shown() || tiktokError(), 6000)) {
        if (tiktokError() && !shown()) throw limited();
        return;
      }
    }
    throw new Error(`Le sous-onglet « ${sub} » ne s’est pas ouvert.`);
  }

  // ── Import ──
  async function scanFavorites(opts = {}) {
    const full = opts.full === true; // « Tout relire » : ne pas s'arrêter aux vidéos déjà connues
    if (accountChanged() || busyGuard()) return;
    if (!(await riskGate())) return;
    cancelOp = false;
    delete S.importResumeAt; // reprise faite (à la main ou automatique) : plus de reprise programmée
    clearTimeout(autoResumeTimer);
    scanning = true;
    busyChanged();
    if (tab === 'deck') renderBody(); // l'écran d'accueil laisse la place au message de chargement
    try {
      // Première importation (ou reprise d'un import interrompu) : on lit d'abord les collections, pour que les vidéos déjà
      // rangées n'arrivent jamais dans la pile à trier. Un ré-import court garde l'ordre habituel (favoris d'abord, rapide).
      const collectionsFirst = !S.order.length || importIncomplete();
      let colsDone = null;
      if (collectionsFirst) {
        setProgress({ title: 'Lecture de tes collections', sub: 'ouverture de ton profil…', pct: null, note: COLS_NOTE });
        try {
          colsDone = await importCollections();
        } catch (e) {
          if (cancelOp) throw e;
          toast('Collections non lues : ' + e.message);
        }
      }
      setProgress({ title: 'Import de tes favoris', sub: 'ouverture de ta liste…', pct: null, note: colsDone ? FAV_NOTE : SLOW_NOTE });
      await openMyFavorites('Publications', 'scan');
      await waitFor(() => document.querySelector('[data-e2e="favorites-item-list"] a[href*="/video/"]'), 10000);
      const SEL = '[data-e2e="favorites-item-list"] a[href*="/video/"]';
      const found = new Map();
      const status = (t) => {
        const s = ov.querySelector('#scan-status');
        if (s) s.textContent = t;
      };
      // Les vidéos sont ajoutées par paquets pendant le défilement : on peut commencer à trier tout de suite.
      let flushed = 0;
      const flush = async () => {
        const wasEmpty = !pile().length;
        addVideos([...found.values()].slice(flushed));
        flushed = found.size;
        save(); // écriture regroupée, sans ralentir la lecture de la liste
        if (tab !== 'deck') return;
        if (wasEmpty && pile().length) return renderBody();
        const c = ov.querySelector('.count');
        const bar = ov.querySelector('.bar i');
        const n = pile().length;
        if (c) c.textContent = `${n} à trier`;
        if (bar) bar.style.width = `${((S.order.length - n) / S.order.length) * 100}%`;
        ensureNext();
      };

      // Le total annoncé par TikTok (« Publications 5000 ») sert de but et de barre de progression.
      const parseCount = (t) => {
        const m = String(t || '').match(/([\d.,]+)\s*([KkMm])?/);
        if (!m) return 0;
        const n = parseFloat(m[1].replace(',', '.'));
        return Math.round(n * ({ k: 1e3, m: 1e6 }[(m[2] || '').toLowerCase()] || 1));
      };
      const readTotal = () => parseCount(subTabEl('Publications')?.textContent); // « Publications 5000 » ou « 5000 Beiträge »
      let total = readTotal();

      let domCount = 0;
      let stalls = 0;
      // Le total annoncé n'est qu'un repère : des favoris ont pu être ajoutés entre-temps. Une fois atteint, on ne
      // s'arrête qu'après 2 passages sans nouveauté (« settled »), et non dès qu'on l'atteint.
      let settled = 0;
      const hadBefore = S.order.length > 0; // ré-import : les favoris plus récents que tout ce qu'on connaît sont « newer »
      let sawKnown = false;
      // Ré-import court : les nouveaux favoris sont tout en haut ; dès qu'on croise 40 vidéos déjà connues d'affilée, on s'arrête.
      const short = hadBefore && !full && !importIncomplete();
      let knownRun = 0;
      // Moins d'une page de vidéos : la liste est entière, inutile d'attendre longtemps la suite (le total annoncé par TikTok
      // compte parfois des vidéos supprimées ou privées qu'on ne verra jamais).
      let cooldowns = 0;
      let nextBreath = 400; // respiration toutes les 400 vidéos : lire des milliers de favoris d'une traite déclenche la limitation
      let endReason = 'fin de la liste';
      trace(`import ${short ? 'court' : full ? 'complet' : importIncomplete() ? 'repris' : 'premier'} : ${S.order.length} vidéos connues, total annoncé ${total || '?'}`);
      for (;;) {
        if (!(stalls < (found.size < 25 ? 2 : 6) && settled < 2)) {
          // TikTok cesse parfois de servir la suite de la liste bien avant la fin (constaté : arrêt à 574 / 5264), le
          // temps d'une limitation passagère. Plutôt que d'abandonner, on fait une pause puis on réessaie (3 fois au plus).
          // (à moins de 5 % du total, c'est la vraie fin : TikTok compte aussi des vidéos supprimées ou devenues privées)
          if (!short && total && found.size < total * 0.95 && total - found.size > 10 && cooldowns < 3) {
            cooldowns++;
            trace(`import : TikTok ne charge plus la suite à ${found.size} / ${total} — pause ${cooldowns}/3`);
            await flush();
            for (let s = 45; s > 0; s--) {
              checkCancel();
              setProgress({ title: 'Import de tes favoris', sub: `${found.size} / ${total}`, pct: found.size / total, note: `TikTok ne charge plus la suite pour l’instant : nouvel essai dans ${s} s (essai ${cooldowns} sur 3).` });
              await sleep(1000);
            }
            window.scrollBy(0, -1200);
            await sleep(500);
            window.scrollTo(0, document.documentElement.scrollHeight);
            stalls = 0;
            continue;
          }
          if (cooldowns && total && found.size < total * 0.95) endReason = 'TikTok ne donne plus la suite';
          break;
        }
        checkCancel();
        total = Math.max(total, readTotal()); // le compteur de TikTok se met à jour après le chargement
        if (total) S.importTotal = total; // mémorisé : permet de proposer « Reprendre l’import » si la page est fermée
        const anchors = document.querySelectorAll(SEL);
        for (let i = domCount; i < anchors.length; i++) {
          const a = anchors[i];
          const m = a.href.match(/\/video\/(\d{8,})/);
          const imgEl = a.querySelector('img');
          const img = imgEl?.src || '';
          // texte de la vignette : description, hashtags, créateur et musique (sert au rangement automatique)
          const text = (imgEl?.alt || '').replace(/\s+/g, ' ').trim().slice(0, 400);
          if (m) {
            if (S.videos[m[1]]) {
              sawKnown = true;
              knownRun++;
            } else knownRun = 0;
          }
          if (m && !found.has(m[1])) {
            found.set(m[1], { id: m[1], url: a.href.split('?')[0], thumb: img, key: keyOf(img), text, newer: hadBefore && !sawKnown });
          }
        }
        // vignettes chargées après coup (TikTok les charge en défilant) : on reprend leur adresse
        for (let i = Math.max(0, domCount - 300); i < domCount; i++) {
          const a = anchors[i];
          const id = (a.href.match(/\/video\/(\d{8,})/) || [])[1];
          const f = id && found.get(id);
          const src = a.querySelector('img')?.src || '';
          if (!thumbOk(src)) continue;
          if (f && !thumbOk(f.thumb)) Object.assign(f, { thumb: src, key: f.key || keyOf(src) });
          const sv = id && S.videos[id]; // déjà enregistrée : on lui donne aussi l'adresse fraîche
          if (sv && sv.thumb !== src) Object.assign(sv, { thumb: src, key: sv.key || keyOf(src) });
        }
        domCount = anchors.length;
        if (short && knownRun >= 40) {
          endReason = 'rejoint les vidéos déjà connues';
          break; // on a rejoint ce qu'on connaît déjà : la suite est identique
        }
        status(`Import : ${found.size}${total ? ` / ${total}` : ''}…`);
        setProgress({ title: 'Import de tes favoris', sub: `${found.size}${total ? ` / ${total}` : ''}`, pct: total ? found.size / total : null, note: colsDone ? FAV_NOTE : SLOW_NOTE });
        // Les premières vidéos s'affichent tout de suite (dès 6 lues), puis par petits lots : on trie pendant que ça charge.
        if (found.size - flushed >= (flushed === 0 ? 6 : found.size < 100 ? 20 : 60)) await flush();
        if (!short && found.size >= nextBreath) {
          nextBreath += 400;
          await flush();
          for (let s = 15; s > 0; s--) {
            checkCancel();
            setProgress({ title: 'Import de tes favoris', sub: `${found.size}${total ? ` / ${total}` : ''}`, pct: total ? found.size / total : null, note: `Pause de respiration pour ne pas alerter TikTok : reprise dans ${s} s.` });
            await sleep(1000);
          }
        }
        // on défile, puis on repart dès que de nouvelles vidéos apparaissent (au lieu d'une pause fixe)
        if (tiktokError()) {
          await flush(); // on garde ce qui a déjà été lu
          throw limited();
        }
        // rythme humain : une pause aléatoire entre deux pages (un défilement instantané en continu peut déclencher la limitation)
        await sleep(350 + Math.random() * 450);
        anchors[anchors.length - 1]?.scrollIntoView({ block: 'end' });
        window.scrollTo(0, document.documentElement.scrollHeight);
        const atTotal = total && found.size >= total;
        let grew = await waitFor(() => document.querySelectorAll(SEL).length > domCount, atTotal ? 2500 : 5000, 100);
        if (!grew) {
          // TikTok charge parfois la suite seulement après un mouvement : on remonte un peu puis on redescend
          window.scrollBy(0, -600);
          await sleep(400);
          window.scrollTo(0, document.documentElement.scrollHeight);
          grew = await waitFor(() => document.querySelectorAll(SEL).length > domCount, atTotal ? 2500 : 5000, 100);
        }
        stalls = grew ? 0 : stalls + 1;
        settled = atTotal && !grew ? settled + 1 : 0;
      }
      await flush();
      status('');
      S.lastImport = Date.now();
      delete S.limitedAt; // la lecture est allée au bout : TikTok ne limite plus
      await save();
      // Le total annoncé par TikTok compte parfois des vidéos supprimées ou privées : si l'écart est petit et que la liste
      // ne grandit plus, l'import est terminé (sinon « Reprendre l'import (3 / 5) » resterait affiché pour toujours).
      const gap = total - Object.keys(S.videos).length;
      const missing = total && gap > 0;
      if (missing && gap <= 10) {
        S.importTotal = Object.keys(S.videos).length;
        await save();
      }
      if (colsDone) {
        // collections déjà lues au début : les vidéos qu'elles contiennent sont arrivées déjà rangées
        const filed = Object.values(S.videos).filter((v) => v.collection && v.synced).length;
        toast(`${found.size} favoris lus, ${colsDone.names} collections (${filed} vidéos déjà rangées)`);
      } else {
        try {
          setProgress({ title: 'Lecture de tes collections', sub: '', pct: null, note: '' });
          const r = await importCollections();
          toast(`${found.size} favoris lus, ${r.names} collections (${r.placed} vidéos déjà rangées)`);
        } catch (e) {
          toast('Collections non lues : ' + e.message);
        }
      }
      trace(`import terminé : ${found.size} lus, ${Object.keys(S.videos).length} connues / ${total || '?'} — ${endReason}`);
      if (missing && gap > 10) {
        // TikTok bloque la suite pour un moment : reprise automatique plus tard (5 fois au plus par onglet). Note : une
        // erreur « Une erreur est survenue » (exception limited) suit le même chemin dans le catch ci-dessous.
        const n = Number(sessionStorage.getItem('tts-autoresume') || 0);
        if (n < 5) {
          sessionStorage.setItem('tts-autoresume', String(n + 1));
          S.importResumeAt = Date.now() + AUTO_RESUME_MS;
          armAutoResume();
          toast(`TikTok ne donne plus la suite (${Object.keys(S.videos).length} / ${total}) : reprise automatique à ${hhmm(S.importResumeAt)}. Laisse cet onglet TikTok ouvert.`);
        } else toast(`${found.size} favoris lus sur ${total} : relance l’import pour continuer`);
      } else {
        delete S.importResumeAt;
        sessionStorage.removeItem('tts-autoresume');
        if (missing) toast(`${Object.keys(S.videos).length} favoris lus (TikTok en annonce ${total} : certaines vidéos ne sont plus disponibles)`);
      }
    } catch (e) {
      toast(e.message);
      // « Une erreur est survenue » chez TikTok : même reprise automatique, plus tard
      const n = Number(sessionStorage.getItem('tts-autoresume') || 0);
      if (e.message === RATE_MSG && importIncomplete() && n < 5) {
        sessionStorage.setItem('tts-autoresume', String(n + 1));
        S.importResumeAt = Date.now() + AUTO_RESUME_MS;
        armAutoResume();
        trace(`import : TikTok affiche une erreur — reprise automatique à ${hhmm(S.importResumeAt)}`);
      }
    } finally {
      await save(); // résultat enregistré AVANT d'annoncer la fin
      scanning = false;
      setProgress(null);
      sessionStorage.removeItem('tts-reloads'); // l'opération est allée au bout : on remet le plafond de rechargements à zéro
      busyChanged();
      softRender();
    }
  }

  // ── Collections déjà présentes sur TikTok ──
  // Leurs noms alimentent le choix de collection, et les vidéos qu'elles contiennent (reconnues par la clé de
  // vignette) sortent de la pile à trier : elles sont déjà rangées.
  const scanStatus = (t) => {
    const s = ov.querySelector('#scan-status');
    if (s) s.textContent = t;
  };

  // ── Bandeau de progression, bien visible sous les onglets : ce qui se passe, où on en est, et pourquoi c'est lent ──
  let PROG = null; // { title, sub, pct (0..1 ou null = indéterminé), note }
  const SLOW_NOTE = 'Pendant l’import, la page TikTok peut ralentir : c’est normal. Tu peux déjà trier les premières vidéos dès qu’elles apparaissent.';
  const COLS_NOTE = 'Étape 1 sur 2 : je lis d’abord tes collections pour ne pas te montrer des vidéos déjà rangées. Ça peut prendre une ou deux minutes.';
  const FAV_NOTE = `Étape 2 sur 2 : import de tes favoris. ${SLOW_NOTE}`;
  const SYNC_NOTE = 'Les rangements sont envoyés à TikTok : compte quelques secondes par collection.';
  function paintProgress() {
    if (!ov) return;
    let el = ov.querySelector('#prog');
    if (!PROG || ov.hidden) return el?.remove();
    if (!el) {
      el = document.createElement('div');
      el.id = 'prog';
      el.className = 'prog';
      ov.insertBefore(el, ov.querySelector('main'));
    }
    const bar = PROG.pct == null ? '<div class="bar ind"><i></i></div>' : `<div class="bar"><i style="width:${Math.min(100, Math.round(PROG.pct * 100))}%"></i></div>`;
    const html = `<div class="prog-row"><span class="spin"></span><b>${esc(PROG.title)}</b><span class="prog-sub">${esc(PROG.sub || '')}</span></div>${bar}${PROG.note ? `<small>${esc(PROG.note)}</small>` : ''}`;
    if (el.dataset.h !== html) {
      el.dataset.h = html;
      el.innerHTML = html;
    }
  }
  const setProgress = (p) => {
    const started = !PROG && !!p;
    PROG = p;
    paintProgress();
    if (started && tab === 'deck' && !pile().length) renderBody(); // écran de chargement à la place de l'écran d'accueil
  };

  // Identifiants des vidéos d'une collection, lus dans les données de la page (bridge.js). Les vidéos s'affichent par
  // pages : on défile jusqu'au nombre annoncé, ou jusqu'à ce que la liste ne grandisse plus.
  async function readCollectionIds(collectionId, expected) {
    let ids = [];
    let lastGrowth = Date.now();
    const start = Date.now();
    while (Date.now() - start < 40000) {
      checkCancel();
      const res = await bridge('ids', { collectionId });
      const now = (res.data || []).filter(Boolean);
      if (now.length > ids.length) lastGrowth = Date.now();
      ids = now;
      if (expected && ids.length >= expected && Date.now() - lastGrowth > 1500) break; // attendre une fournée de plus : des vidéos ont pu être ajoutées
      // la page met plusieurs secondes à afficher la 1re fournée ; ensuite, 2 s sans nouveauté = c'est fini
      if (ids.length ? Date.now() - lastGrowth > 2000 : Date.now() - start > 20000) break;
      document.querySelector('[data-e2e="collection-item-list"] [data-e2e="collection-item"]:last-child')?.scrollIntoView({ block: 'end' });
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(400);
    }
    return ids;
  }

  async function importCollections(opts = {}) {
    const full = !!opts.full; // relecture complète : ignore le « nombre de vidéos inchangé »
    const listReady = () => document.querySelector('a[href*="/collection/"]') || COLS_TEXT_RE.test(pageText());
    const firstLine = (a) => a.innerText.trim().split('\n')[0].trim();
    const linkEls = () => [...document.querySelectorAll('a[href*="/collection/"]')];
    // On défile la liste jusqu'à ce qu'elle ne grandisse plus : le total annoncé (« Collections 26 ») n'est qu'un repère,
    // des collections ont pu être ajoutées entre-temps. TikTok n'en affiche qu'une partie à la fois (19 sur 26 par ex.).
    const loadList = async () => {
      await waitFor(listReady, 8000);
      for (let stalls = 0; stalls < 3; ) {
        checkCancel();
        const n = linkEls().length;
        const total = firstNumber(subTabEl('Collections')?.textContent);
        if (total && n >= total && stalls >= 1) break; // total atteint, confirmé par un passage sans nouveauté
        linkEls().at(-1)?.scrollIntoView({ block: 'end' });
        window.scrollTo(0, document.documentElement.scrollHeight);
        await sleep(800);
        stalls = linkEls().length > n ? 0 : stalls + 1;
      }
      return [...new Map(linkEls().map((a) => [a.getAttribute('href'), a])).values()]
        .map((a) => ({
          name: firstLine(a),
          href: a.getAttribute('href'),
          id: colIdOf(a.getAttribute('href')),
          expected: Number((a.innerText.match(VIDEO_COUNT_RE) || [])[1]) || 0,
        }))
        .filter((c) => c.name && c.id);
    };

    await openMyFavorites('Collections', 'collections');
    let cols = await loadList();
    const seen = new Set();
    let placed = 0;
    let skipped = 0;
    // Plusieurs passages : après avoir lu les collections connues, on relit la liste pour visiter celles apparues entre-temps.
    for (let pass = 0; pass < 3; pass++) {
      const todo = cols.filter((c) => !seen.has(c.href));
      if (!todo.length) break;
      for (const c of todo) {
        if (!S.collections.includes(c.name)) S.collections.push(c.name);
        S.colInfo[c.name] = { href: c.href, id: c.id }; // mémorisé : permet de rouvrir la collection directement, sans repasser par Profil → Favoris → Collections
      }
      save();
      refreshChips(); // les noms sont déjà utilisables dans le panneau (sans redessiner la carte ni recharger son lecteur)

      for (const c of todo) {
        checkCancel();
        seen.add(c.href);
        // Une collection dont le nombre de vidéos n'a pas changé depuis la dernière lecture n'est pas rouverte (gros gain de temps).
        if (!full && S.colCounts[c.name] === c.expected) {
          skipped++;
          continue;
        }
        // Collection vide côté TikTok : rien à lire (et inutile d'attendre) ; ce qu'on croyait y avoir rangé n'y est pas.
        if (c.expected === 0) {
          for (const v of Object.values(S.videos)) if (v.collection === c.name && v.status === 'kept' && v.synced) v.synced = false;
          S.colCounts[c.name] = 0;
          save();
          continue;
        }
        scanStatus(`Collection ${seen.size}/${cols.length} : « ${c.name} »`);
        setProgress({ title: "Lecture de tes collections", sub: `${seen.size} / ${cols.length} : ${c.name}`, pct: seen.size / cols.length, note: PROG?.note?.startsWith("Étape 1") ? COLS_NOTE : "" });
        history.pushState({}, '', c.href);
        window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
        const ids = await readCollectionIds(c.id, c.expected);
        const shown = pile()[0]; // la carte affichée en ce moment n'est jamais déplacée sous les doigts
        for (const id of ids) {
          const v = S.videos[id];
          // on ne touche ni aux vidéos déjà retirées ni à celles que tu as déjà rangées ailleurs
          if (v && id !== shown && (v.status === 'new' || (v.status === 'kept' && !v.collection))) {
            Object.assign(v, { status: 'kept', collection: c.name, synced: true });
            placed++;
          } else if (!v) {
            S.filedIds[id] = c.name; // pas encore importée : elle arrivera déjà rangée (voir addVideos)
            placed++;
          }
        }
        // rapprochement avec TikTok : ce qui s'y trouve est « synchronisé » ; ce qui était marqué synchronisé mais n'y est
        // pas (lecture complète seulement) sera renvoyé à la prochaine synchronisation.
        const inCol = new Set(ids);
        const complete = ids.length >= Math.max(1, Math.floor(c.expected * 0.9));
        for (const v of Object.values(S.videos)) {
          if (v.collection !== c.name || v.status !== 'kept') continue;
          if (inCol.has(v.id)) v.synced = true;
          else if (complete && v.synced && v.id !== shown) v.synced = false;
        }
        if (complete) S.colCounts[c.name] = c.expected; // lue en entier : la prochaine fois, on peut l'ignorer si rien n'a changé
        save();
      }
      scanStatus('Recherche de nouvelles collections…');
      if (PROG) setProgress({ ...PROG, sub: 'recherche de nouvelles collections…', pct: null });
      await openMyFavorites('Collections', 'collections');
      cols = await loadList();
    }
    scanStatus('');
    return { names: seen.size, placed, skipped };
  }

  async function refreshCollections(opts = {}) {
    if (accountChanged() || busyGuard()) return;
    if (!(await riskGate())) return;
    cancelOp = false;
    scanning = true;
    busyChanged();
    setProgress({ title: 'Lecture de tes collections', sub: 'ouverture de ton profil…', pct: null, note: '' });
    try {
      const r = await importCollections({ full: !!opts.full });
      toast(`${r.names} collections vues (${r.skipped} inchangée(s) ignorée(s)), ${r.placed} vidéos déjà rangées`);
    } catch (e) {
      toast(e.message);
    } finally {
      await save(); // résultat enregistré AVANT d'annoncer la fin
      scanning = false;
      setProgress(null);
      sessionStorage.removeItem('tts-reloads'); // l'opération est allée au bout : on remet le plafond de rechargements à zéro
      busyChanged();
      softRender();
    }
  }

  // ── Rangement dans les collections TikTok (ajouts et retraits) ──
  // Flux vérifié sur le site :
  //  - ajout : « Créer une nouvelle collection » (nom → Suivant) ou, pour une collection existante, sa page →
  //    « Ajouter des vidéos » ; une fenêtre liste alors les favoris avec une case chacun (jusqu'à ~15 s à s'ouvrir
  //    avec des milliers de favoris) ;
  //  - retrait : page de la collection → « Gérer les vidéos » → cases → « Supprimer (N) » → confirmation
  //    (« Tes vidéos seront toujours enregistrées dans les Favoris »).
  // La fenêtre s'affiche tout de suite avec son titre ; les vidéos n'arrivent que quelques secondes plus tard.
  const findSelectDialog = () =>
    [...document.querySelectorAll('[role="dialog"]')].find((d) => /Sélectionner des vidéos|Select videos/i.test(d.innerText) || d.querySelector('[data-e2e="collection-item"]'));
  const dialogsInfo = () =>
    [...document.querySelectorAll('[role="dialog"]')]
      .filter((d) => !isNotifPanel(d))
      .map((d) => d.innerText.split('\n')[0].slice(0, 40))
      .join(' | ') || 'aucune fenêtre';
  const LIST_ITEM = '[data-e2e="collection-item-list"] [data-e2e="collection-item"]';

  // Charge toutes les cartes de la liste des collections (TikTok n'en affiche qu'une partie à la fois).
  async function loadAllCollectionLinks() {
    const linkEls = () => [...document.querySelectorAll('a[href*="/collection/"]')];
    await waitFor(() => linkEls().length || COLS_TEXT_RE.test(pageText()), 10000);
    const total = firstNumber(subTabEl('Collections')?.textContent);
    for (let stalls = 0; stalls < 3 && linkEls().length < total; ) {
      const n = linkEls().length;
      linkEls().at(-1)?.scrollIntoView({ block: 'end' });
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(800);
      stalls = linkEls().length > n ? 0 : stalls + 1;
    }
    return linkEls();
  }

  // Ouvre la page d'une collection existante ; null si elle n'existe pas.
  async function openCollection(name) {
    // Voie rapide : navigation interne de la page vers l'adresse mémorisée de la collection. On évite ainsi de repasser
    // par Profil → Favoris → Collections → (défilement de la liste) pour chaque collection, soit 10 à 15 s économisées.
    const info = S.colInfo?.[name];
    if (info) {
      history.pushState({}, '', info.href);
      window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
      // Juste après la navigation, le contenu de l'ANCIENNE page (et son bouton « Ajouter ») reste affiché un instant : on
      // n'agit que quand toutes les vidéos affichées appartiennent bien à la collection visée (vérifié sur le vrai site).
      const t0 = Date.now();
      let ready = false;
      while (Date.now() - t0 < 12000) {
        const add = document.querySelector('[data-e2e="collection-action-add"]');
        const data = (await bridge('ids', { collectionId: info.id })).data || [];
        const mine = data.filter(Boolean).length;
        if (add && data.length > 0 && mine === data.length) ready = true; // les vidéos affichées sont celles de la bonne collection
        else if (add && data.length === 0 && Date.now() - t0 > 1500) ready = true; // collection vide (rien à comparer) : on laisse la page se poser
        if (ready) break;
        await sleep(150);
      }
      if (ready) return { colId: info.id };
      delete S.colInfo[name]; // adresse périmée (collection renommée ou supprimée) : on la retrouvera par la liste
    }
    await openMyFavorites('Collections', 'sync');
    const link = (await loadAllCollectionLinks()).find((a) => a.innerText.trim().split('\n')[0].trim().toLowerCase() === name.toLowerCase());
    if (!link) return null;
    link.click();
    if (!(await waitFor(() => document.querySelector('[data-e2e="collection-action-add"]'), 25000))) {
      throw new Error(`Page de la collection « ${name} » introuvable.`);
    }
    const href = link.getAttribute('href');
    const colId = colIdOf(href);
    S.colInfo[name] = { href, id: colId };
    return { colId };
  }

  // La croix est le DERNIER bouton sans texte de la fenêtre (le premier est la flèche « retour » à l'étape 2).
  const closeDialog = (dlg) => [...dlg.querySelectorAll('button')].filter((b) => !b.textContent.trim()).at(-1)?.click();

  // Le panneau des notifications de TikTok est aussi une « fenêtre » (role=dialog) : on le reconnaît à ses onglets.
  const isNotifPanel = (d) => d.getAttribute('aria-label') === 'Notifications' || !!d.querySelector('[id^="inbox-tab"]');
  // Fenêtre « Nouvelle collection » : celle qui contient le champ du nom (titre traduit selon la langue de TikTok).
  const nameDialog = () => [...document.querySelectorAll('[role="dialog"]')].find((x) => x.querySelector('input.TUXTextInputCore-input') || /Nouvelle collection|New collection/i.test(x.innerText));
  // Message de refus affiché par TikTok sous le champ du nom (ex. « Ce nom est inapproprié. Réessaie. »).
  const NAME_ERR_RE = /inappropri|invalid|already|exist|try again|invalide|déjà|existe|réessaie|apropiado|no válido|inténtalo|unangemessen|ungültig|bereits|versuch|inadequado|inválido|já existe|tente|non valido|esiste già|riprova/i;
  const nameError = () => nameDialog()?.innerText.split('\n').find((l) => NAME_ERR_RE.test(l)) || '';
  // Bouton « Suivant » de la fenêtre du nom : son seul bouton avec du texte (l'autre est la croix).
  const nameNextBtn = () => {
    const d = nameDialog();
    return (d && [...d.querySelectorAll('button')].filter((b) => b.textContent.trim()).at(-1)) || buttonByText(/^(Suivant|Next|Siguiente|Weiter|Avançar|Avanti)$/);
  };

  // Coche dans la fenêtre « Sélectionner des vidéos » les vidéos voulues (reconnues par leur identifiant, lu par
  // bridge.js). La liste ne charge la suite que si on fait défiler SON conteneur interne (vérifié : scrollIntoView
  // ne suffit pas, elle restait bloquée à 28 vidéos ; scrollTop = scrollHeight en charge ~20 par seconde).
  async function fillModal(wanted) {
    const ITEM = '[role="dialog"] [data-e2e="collection-item"]';
    // les vidéos apparaissent plusieurs secondes après la fenêtre (jusqu'à ~40 s avec une page chargée)
    const appeared = await waitFor(() => document.querySelector(ITEM), 40000);
    const scroller = () => {
      for (let el = document.querySelector(ITEM)?.parentElement; el && el !== document.body; el = el.parentElement) {
        if (el.scrollHeight > el.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(el).overflowY)) return el;
      }
      return null;
    };
    // Lecture de secours : si l'identifiant de la vidéo n'est pas lisible dans la page (TikTok a changé sa structure),
    // on reconnaît la vidéo à sa vignette, comme à l'origine (clé = nom de fichier de l'image sans signature).
    const byKey = new Map();
    for (const id of wanted.keys()) {
      const k = S.videos[id]?.key;
      if (k) byKey.set(k, id);
    }
    const picked = new Set();
    const stat = { scanned: 0, idless: 0, viaKey: 0, appeared: !!appeared, stalls: 0, limit: 0 };
    // au-delà, la recherche prendrait trop de temps ; la limite suit la taille de la liste de favoris importée
    stat.limit = Math.max(2500, Object.keys(S.videos).length + 300);
    let scanned = 0;
    let stalls = 0;
    let lastFound = 0;
    const startedAt = Date.now();
    let lastFoundAt = startedAt;
    // Arrêt anticipé : sur le vrai TikTok, la liste charge parfois moins d'un favori par seconde (constaté : 24 en
    // 22 s) — un seuil compté en nombre de favoris ne suffit pas, il faut une limite de TEMPS depuis la dernière
    // trouvaille (45 s), avec un plafond de favoris en secours pour les connexions rapides. Sans ce garde-fou, un lot
    // ne contenant AUCUNE des vidéos voulues (le cas le plus fréquent) parcourait toute la liste, plusieurs minutes,
    // sans jamais s'arrêter avant.
    const tooFar = () => Date.now() - lastFoundAt > 45000 || scanned - lastFound > 1500;
    while (picked.size < wanted.size && stalls < 6 && scanned < stat.limit && !tooFar()) {
      checkCancel();
      const items = [...document.querySelectorAll(ITEM)];
      const ids = (await bridge('modalIds')).data || [];
      // le parcours peut durer : on montre où on en est plutôt que de laisser croire que ça ne fait rien
      if (PROG) setProgress({ ...PROG, sub: `${PROG.sub.replace(/ · .*$/, '')} · ${items.length} favoris parcourus, ${picked.size}/${wanted.size} trouvées`, note: 'TikTok charge sa liste par petits paquets : ça peut prendre plusieurs minutes si tes vidéos sont loin dans la liste.' });
      for (let i = scanned; i < items.length; i++) {
        let id = ids[i];
        if (!id) {
          stat.idless++;
          const k = keyOf(items[i].querySelector('img')?.src);
          if (k && byKey.has(k)) {
            id = byKey.get(k);
            stat.viaKey++;
          }
        }
        if (id && wanted.has(id) && !picked.has(id)) {
          items[i].querySelector('input[type="checkbox"]')?.click();
          picked.add(id);
          lastFound = i;
          lastFoundAt = Date.now();
        }
      }
      scanned = items.length;
      if (picked.size >= wanted.size) break;
      const box = scroller();
      if (box) {
        box.scrollTop = box.scrollHeight;
        // l'événement « scroll » naturel n'arrive pas si la page ne s'affiche pas (onglet en arrière-plan) : on l'émet
        box.dispatchEvent(new Event('scroll', { bubbles: true }));
      } else items.at(-1)?.scrollIntoView({ block: 'end' });
      const grew = await waitFor(() => document.querySelectorAll(ITEM).length > scanned, 6000);
      stalls = grew ? 0 : stalls + 1;
    }
    stat.scanned = scanned;
    stat.stalls = stalls;
    // « définitif » = cette tentative n'a pas trouvé le reste (fin de liste, limite, ou arrêt anticipé) : compte comme un
    // essai raté. Deux essais ratés de suite (miss >= 2) mettent la vidéo de côté ; ↩ la remet dans la pile pour réessayer.
    stat.definitive = stat.appeared && picked.size < wanted.size;
    fillModal.stat = stat;
    trace(`fenêtre : ${Math.round((Date.now() - startedAt) / 1000)} s, ${scanned} favoris parcourus, ${picked.size}/${wanted.size} cochées${stat.idless ? `, ${stat.idless} sans identifiant (${stat.viaKey} reconnues par vignette)` : ''}${stat.appeared ? '' : ', la liste ne s’est jamais affichée'}${stalls >= 6 ? ', fin de liste atteinte' : ''}`);
    return picked;
  }

  // Attend que TOUTES les vidéos `wanted` soient dans la collection (ou, avec gone:true, qu'aucune n'y soit plus). On sort
  // dès que c'est vrai (souvent en 1 s), au lieu d'attendre que la liste « se stabilise » ; on défile un peu à chaque tour
  // car une collection de plus de 50 vidéos n'affiche que la première page.
  async function waitForIds(collectionId, wanted, { gone = false, timeout = 15000 } = {}) {
    const start = Date.now();
    let seen = new Set();
    while (Date.now() - start < timeout) {
      const data = (await bridge('ids', { collectionId })).data || [];
      seen = new Set(data.filter(Boolean));
      const ok = gone ? [...wanted].every((id) => !seen.has(id)) : [...wanted].every((id) => seen.has(id));
      if (ok) break;
      document.querySelector(`${LIST_ITEM}:last-child`)?.scrollIntoView({ block: 'end' });
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(250);
    }
    return seen;
  }

  async function addToCollection(name, vids) {
    const wanted = new Map(vids.map((v) => [v.id, v]));
    trace(`« ${name} » : ${vids.length} vidéo(s) à ranger, ouverture de la collection`);
    const col = await openCollection(name);
    trace(`« ${name} » : ${col ? 'collection ouverte' : 'collection introuvable, création'}`);
    let dlg;
    if (col) {
      // le clic ne prend pas toujours si la page n'est pas encore prête : on réessaie
      for (const wait of [40000, 20000, 20000]) {
        document.querySelector('[data-e2e="collection-action-add"]')?.click();
        dlg = await waitFor(findSelectDialog, wait);
        if (dlg) break;
      }
    } else {
      const create = document.querySelector('[data-e2e="collection-action-create"]');
      if (!create) throw new Error('Bouton « Créer une nouvelle collection » introuvable.');
      create.click();
      const input = await waitFor(() => document.querySelector('input.TUXTextInputCore-input'), 8000);
      if (!input) throw new Error('Champ du nom de collection introuvable.');
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, name);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(700);
      const refused = () => {
        const msg = nameError();
        if (!msg) return null;
        const d = nameDialog();
        if (d) closeDialog(d);
        return new Error(`TikTok refuse le nom « ${name} » : ${msg.trim()} Renomme la collection (✎).`);
      };
      const early = refused();
      if (early) throw early;
      const next = nameNextBtn();
      if (!next) throw new Error('Bouton « Suivant » introuvable.');
      next.click();
      // soit la fenêtre de sélection arrive, soit TikTok affiche un refus sous le champ du nom
      dlg = await waitFor(() => findSelectDialog() || nameError(), 60000);
      if (typeof dlg === 'string') throw refused() || new Error(`TikTok refuse le nom « ${name} » : ${dlg.trim()}`);
    }
    if (!dlg) {
      throw new Error(`Fenêtre de sélection introuvable pour « ${name} » (${col ? 'collection existante' : 'nouvelle collection'} ; à l'écran : ${dialogsInfo()}).`);
    }

    trace(`« ${name} » : fenêtre de sélection ouverte`);
    const picked = await fillModal(wanted);
    // bouton de validation : celui qui affiche le nombre coché (« Ajouter des vidéos (3) », « Añadir vídeos (3) »…)
    const confirmBtn = [...dlg.querySelectorAll('button')].filter((b) => /\(\d+\)/.test(b.textContent)).at(-1) || buttonByText(/^(Ajouter des vidéos|Terminé|Add videos|Done)/, dlg);
    if (!picked.size || !confirmBtn || confirmBtn.disabled) {
      const st = fillModal.stat || {};
      const why = !st.appeared
        ? 'la liste des favoris ne s’est pas affichée dans la fenêtre de TikTok (page trop lente ? recharge tiktok.com)'
        : !picked.size
          ? `aucune des ${vids.length} vidéos n’a été trouvée parmi les ${st.scanned || 0} favoris parcourus (elles ne sont peut-être plus dans tes favoris)`
          : 'le bouton « Ajouter » de TikTok est resté inactif';
      trace(`« ${name} » : rien ajouté — ${why}`);
      // parcours complet sans les trouver : après deux fois, on cesse de les envoyer (elles s'affichent en ⚠ dans Collections)
      if (fillModal.stat?.definitive) for (const v of vids) v.miss = (v.miss || 0) + 1;
      closeDialog(dlg);
      return { done: [], missed: vids.length, why: `${why}${vids.some((v) => v.miss >= 2) ? ' — mises de côté : remets-les dans la pile avec ↩' : ''}` };
    }
    // garde-fou : le compteur du bouton doit refléter ce qu'on a coché
    const count = Number((confirmBtn.textContent.match(/\((\d+)\)/) || [])[1]);
    if (count !== picked.size) {
      trace(`« ${name} » : compteur du bouton ${count} ≠ ${picked.size} cochées`);
      closeDialog(dlg);
      throw new Error(`Sélection incohérente pour « ${name} » (${count} ≠ ${picked.size}).`);
    }
    trace(`« ${name} » : clic sur « ${confirmBtn.textContent.trim()} »`);
    confirmBtn.click();
    // TikTok referme la fenêtre puis affiche la collection : on vérifie que les vidéos y sont VRAIMENT avant de les
    // marquer « synchronisées » (un clic qui ne prend pas ne doit pas passer pour un succès).
    await waitFor(() => !findSelectDialog(), 15000);
    const colId = col?.colId || (await waitFor(() => (location.pathname.match(/\/collection\/.*?(\d+)\/?$/) || [])[1], 20000));
    let confirmed = [...picked];
    if (colId) {
      const inCol = await waitForIds(colId, new Set(picked));
      confirmed = confirmed.filter((id) => inCol.has(id));
      trace(`« ${name} » : ${confirmed.length}/${picked.size} confirmées dans la collection par TikTok`);
    } else trace(`« ${name} » : identifiant de collection illisible, vérification impossible`);
    if (fillModal.stat?.definitive) for (const [id, v] of wanted) if (!picked.has(id)) v.miss = (v.miss || 0) + 1; // parcours complet : absente des favoris
    return {
      done: confirmed.map((id) => wanted.get(id)),
      missed: vids.length - confirmed.length,
      why: confirmed.length < picked.size ? 'TikTok n’a pas confirmé l’ajout (clic non pris en compte ?)' : '',
    };
  }

  async function removeFromCollection(name, vids) {
    const wanted = new Map(vids.map((v) => [v.id, v]));
    const col = await openCollection(name);
    if (!col) return { done: vids, missed: 0 }; // la collection n'existe plus : rien à retirer
    // attendre que la 1re fournée de vidéos soit affichée
    const loaded = await (async () => {
      for (const end = Date.now() + 25000; Date.now() < end; ) {
        if (((await bridge('ids', { collectionId: col.colId })).data || []).some(Boolean)) return true;
        await sleep(400);
      }
      return false;
    })();
    if (!loaded) return { done: [], missed: vids.length };

    document.querySelector('[data-e2e="collection-action-manage"]')?.click();
    if (!(await waitFor(() => document.querySelector('[data-e2e="collection-manage-header"]'), 8000))) {
      throw new Error(`Mode « Gérer les vidéos » introuvable pour « ${name} ».`);
    }
    const picked = new Set();
    let stalls = 0;
    let lastCount = 0;
    while (picked.size < wanted.size && stalls < 4) {
      checkCancel();
      const items = [...document.querySelectorAll(LIST_ITEM)];
      const ids = (await bridge('ids', { collectionId: col.colId })).data || [];
      let progress = items.length > lastCount;
      lastCount = items.length;
      items.forEach((it, i) => {
        const id = ids[i];
        const box = it.querySelector('input[type="checkbox"]');
        if (id && box && wanted.has(id) && !picked.has(id)) {
          box.click();
          picked.add(id);
          progress = true;
        }
      });
      items.at(-1)?.scrollIntoView({ block: 'end' });
      await sleep(900);
      stalls = progress ? 0 : stalls + 1;
    }
    // En-tête du mode « Gérer les vidéos » (vérifié en FR, EN, ES) : [Supprimer (N)] [Tout sélectionner] [Annuler].
    const header = () => document.querySelector('[data-e2e="collection-manage-header"]');
    const headerBtns = () => [...(header()?.querySelectorAll('button') || [])];
    const cancel = () => (headerBtns().at(-1) || buttonByText(/^(Annuler|Cancel|Cancelar|Abbrechen|Annulla)$/))?.click();
    if (!picked.size) {
      cancel();
      return { done: [], missed: vids.length };
    }
    const del = await waitFor(() => headerBtns().find((b) => /\(\d+\)/.test(b.textContent)) || buttonByText(/^(Supprimer|Delete|Remove) \(\d+\)/), 5000);
    if (!del) {
      cancel();
      throw new Error('Bouton « Supprimer » introuvable dans « Gérer les vidéos ».');
    }
    // Le bouton de la confirmation porte le même mot que celui qu'on clique, sans le nombre (« Eliminar (1) » → « Eliminar »).
    const delWord = del.textContent.replace(/\(\d+\)/, '').trim();
    del.click();
    // La confirmation doit parler de VIDÉOS de CETTE collection (et non de la suppression de la collection entière) :
    // « Eliminar 1 vídeo de Salle · Tus vídeos seguirán guardados en Favoritos ».
    const confirmBtnOf = (d) => [...d.querySelectorAll('button')].find((b) => b.textContent.trim() === delWord);
    const dlg = await waitFor(
      () => [...document.querySelectorAll('[role="dialog"]')].find((d) => !isNotifPanel(d) && confirmBtnOf(d) && /\d/.test(d.innerText) && (d.innerText.includes(name) || (/vidéo|video/i.test(d.innerText) && /collection|Favoris|Favorites/i.test(d.innerText)))),
      8000,
    );
    if (!dlg) {
      cancel();
      throw new Error('Confirmation de retrait introuvable.');
    }
    confirmBtnOf(dlg).click();
    const remaining = await waitForIds(col.colId, new Set(picked), { gone: true, timeout: 12000 });
    for (const id of [...picked]) if (remaining.has(id)) picked.delete(id); // pas retirée : on ne la déclare pas retirée
    return { done: [...picked].map((id) => wanted.get(id)), missed: vids.length - picked.size };
  }

  // Synchronisation automatique : quelques secondes après le dernier rangement, on l'envoie à TikTok.
  let syncTimer = null;
  const pendingSync = () =>
    Object.values(S.videos).filter((v) => v.removeFrom || (v.status === 'kept' && v.collection && !v.synced && !(v.miss >= 2))).length;
  // Les rangements sont envoyés en un seul lot après un moment d'inactivité (réglage), ou tout de suite dès 10 en attente :
  // chaque ouverture de la fenêtre de sélection de TikTok coûte 10 à 15 s, autant la partager entre plusieurs vidéos.
  // « ✕ Stop » suspend aussi les synchronisations automatiques déjà programmées : elles ne repartent qu'après une nouvelle
  // action de l'utilisateur (un rangement, « Synchroniser maintenant »…).
  let autoHeld = false;
  function scheduleSync(ms, fromSync = false) {
    if (!fromSync) autoHeld = false;
    if (autoHeld) return;
    if (ms === undefined) ms = pendingSync() >= 10 ? 2000 : SET.syncDelay * 1000;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      if (autoHeld) return;
      if (scanning || syncing) return scheduleSync(5000, true);
      if (workLeft()) syncCollections({ auto: true });
    }, ms);
  }

  // Ferme d'éventuelles fenêtres restées ouvertes après une erreur (hors notifications).
  const closeStrayDialogs = () =>
    [...document.querySelectorAll('[role="dialog"]')].filter((d) => !isNotifPanel(d)).forEach(closeDialog);

  const workLeft = () =>
    Object.values(S.videos).filter(
      (v) => (v.removeFrom && !S.errors?.[v.removeFrom]) || (v.status === 'kept' && v.collection && !v.synced && !S.errors?.[v.collection]),
    ).length;

  async function syncCollections({ auto = false } = {}) {
    if (accountChanged()) return;
    if (syncing || scanning) {
      if (!auto) busyGuard();
      return;
    }
    // pas de synchronisation automatique tant que l'avertissement n'a pas été accepté ; en manuel, on le présente
    if (auto ? !SET.riskAccepted : !(await riskGate())) return;
    cancelOp = false;
    if (!auto) {
      autoHeld = false;
      S.errors = {}; // « Synchroniser maintenant » retente aussi les collections en erreur
    }
    S.errors ||= {};
    const adds = {};
    const removals = {};
    for (const id of S.order) {
      const v = S.videos[id];
      if (v.removeFrom && !S.errors[v.removeFrom]) (removals[v.removeFrom] ||= []).push(v);
      if (v.status === 'kept' && v.collection && !v.synced && !(v.miss >= 2) && !S.errors[v.collection]) (adds[v.collection] ||= []).push(v);
    }
    if (!Object.keys(adds).length && !Object.keys(removals).length) {
      if (auto) return;
      // rien en attente d'après l'extension : on vérifie auprès de TikTok (une vidéo marquée rangée peut ne pas l'être)
      toast('Rien en attente. Vérification auprès de TikTok…');
      await refreshCollections();
      if (workLeft()) syncCollections();
      return;
    }
    // Une page TikTok chargée de milliers de favoris (après l'import) devient très lente : la fenêtre de sélection
    // met alors une éternité à s'ouvrir. On repart d'une page neuve, puis la synchronisation reprend toute seule.
    const profileHref = profilePath();
    if (profileHref && document.getElementsByTagName('*').length > 12000 && !sessionStorage.getItem('tts-fresh')) {
      sessionStorage.setItem('tts-fresh', '1');
      sessionStorage.setItem('tts-resume', auto ? 'sync-auto' : 'sync');
      location.href = profileHref;
      return;
    }
    syncing = true;
    busyChanged();
    if (tab === 'cols') renderBody();
    let progress = 0;
    let missed = 0;
    let failed = 0;
    // une erreur sur une collection est mémorisée (et affichée dans l'onglet Collections) sans bloquer les autres
    const run = async (name, work, apply) => {
      try {
        closeStrayDialogs();
        const r = await work();
        for (const v of r.done) apply(S.videos[v.id]);
        progress += r.done.length;
        missed += r.missed;
        // rien n'a pu être ajouté : on l'écrit (onglet Collections) au lieu de réessayer en silence à chaque synchronisation
        if (!r.done.length && r.missed && r.why) S.errors[name] = r.why;
        else delete S.errors[name];
        delete S.colCounts[name]; // la collection a changé côté TikTok : à relire la prochaine fois
      } catch (e) {
        closeStrayDialogs();
        if (!cancelOp) {
          failed++;
          S.errors[name] = e.message;
        }
      }
      save();
      if (tab === 'cols') renderBody();
    };
    try {
      for (const [name, vids] of Object.entries(removals)) {
        if (cancelOp) break;
        scanStatus(`Retrait de « ${name} »…`);
        setProgress({ title: "Envoi à TikTok", sub: `retrait de « ${name} »`, pct: null, note: SYNC_NOTE });
        await run(name, () => removeFromCollection(name, vids), (v) => delete v.removeFrom);
      }
      // Les rangements partent par lots (une fenêtre de sélection TikTok avec des centaines de cases est fragile) ;
      // si un lot n'avance pas, on s'arrête pour cette collection et on dit pourquoi.
      const BATCH = 40;
      const totalAdds = Object.values(adds).reduce((n, l) => n + l.length, 0);
      let sentAdds = 0;
      trace(`synchronisation${auto ? ' automatique' : ''} : ${totalAdds} à ranger dans ${Object.keys(adds).length} collection(s), ${Object.values(removals).reduce((n, l) => n + l.length, 0)} retrait(s)`);
      for (const [name, vids] of Object.entries(adds)) {
        for (let i = 0; i < vids.length; i += BATCH) {
          if (cancelOp) break;
          const part = vids.slice(i, i + BATCH);
          scanStatus(`Rangement dans « ${name} »…`);
          setProgress({ title: 'Envoi à TikTok', sub: `rangement dans « ${name} » (${Math.min(i + BATCH, vids.length)} / ${vids.length})`, pct: totalAdds ? sentAdds / totalAdds : null, note: SYNC_NOTE });
          const before = progress;
          await run(name, () => addToCollection(name, part), (v) => (v.synced = true));
          sentAdds += progress - before;
          if (progress === before) break; // aucun ajout dans ce lot : inutile d'insister
        }
      }
      if (cancelOp) toast("Synchronisation arrêtée.");
      else if (!auto || missed || failed) {
        toast(
          failed || Object.keys(S.errors).length
            ? `${progress} synchronisées, ${Math.max(failed, Object.keys(S.errors).length)} collection(s) en erreur (voir l’onglet Collections)`
            : missed
              ? `${progress} synchronisées, ${missed} introuvables dans la liste TikTok`
              : `${progress} vidéos synchronisées avec TikTok`,
        );
      }
    } finally {
      await save(); // résultat enregistré AVANT d'annoncer la fin (bouton Stop masqué)
      syncing = false;
      setProgress(null);
      sessionStorage.removeItem('tts-reloads'); // l'opération est allée au bout : on remet le plafond de rechargements à zéro
      busyChanged();
      sessionStorage.removeItem('tts-fresh');
      scanStatus('');
      if (tab === 'cols') renderBody();
      if (progress && workLeft()) scheduleSync(3000, true); // des rangements sont arrivés pendant la synchro
    }
  }

  function importFile(file) {
    const reader = new FileReader();
    reader.onload = async () => {
      const found = new Map();
      for (const m of String(reader.result).matchAll(/https?:[^\s"'\\]*?\/video\/(\d{8,})[^\s"'\\]*/g)) {
        if (!found.has(m[1])) found.set(m[1], { id: m[1], url: m[0].split('?')[0] });
      }
      const n = addVideos([...found.values()]);
      await save();
      toast(`${n} vidéos importées`);
      render();
    };
    reader.readAsText(file);
  }

  // ── Actions de tri ──
  const delConfirmText = () =>
    `Les vidéos glissées à ${SET.swap ? 'gauche' : 'droite'} seront RETIRÉES de tes favoris TikTok (automatiquement, en arrière-plan). Continuer ?`;

  async function act(kind, collection) {
    if (accountChanged()) return false;
    const id = pile()[0];
    if (!id) return false;
    const v = S.videos[id];
    if (kind === 'del' && !(await riskGate())) return false;
    hist.push({ id, status: v.status, collection: v.collection });
    if (kind === 'keep') {
      v.status = 'kept';
      logAct('keep', id);
    }
    if (kind === 'col') {
      // auto = rangée en acceptant une proposition : elle ne sert pas à l'apprentissage (une erreur ne s'auto-entretient pas)
      Object.assign(v, { status: 'kept', collection, synced: false, auto: colFromSuggestion });
      colFromSuggestion = false;
      touchRecent(collection);
      logAct('col', id, collection);
      scheduleSync(); // envoyé à TikTok quelques secondes plus tard, sans action de ta part
    }
    if (kind === 'del') {
      v.status = 'deleted';
      logAct('del', id);
      const r = await send({ type: 'enqueue', items: [{ id, url: v.url, account: ACCOUNT }] });
      if (r?.rejected?.includes(id)) {
        // quota gratuit atteint : la vidéo reste dans la pile, rien n'est retiré
        v.status = 'new';
        hist.pop();
        S.log.shift();
        upsell('limit');
        refreshPlan();
        await save();
        renderBody();
        return false;
      }
      refreshPlan();
      showUndoBar(id);
    }
    // l'écran d'abord (carte suivante tout de suite), l'écriture ensuite, regroupée avec les gestes suivants
    if (tab === 'deck') deckChanged();
    else renderBody();
    save();
    return true;
  }

  // Bandeau « Annuler » avec compte à rebours : un retrait part vraiment après le délai de grâce (réglage).
  let undoTimer = null;
  function showUndoBar(id) {
    clearInterval(undoTimer);
    const until = Date.now() + SET.grace * 1000;
    let bar = ov.querySelector('#undo-bar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'undo-bar';
      bar.className = 'undobar';
      ov.append(bar);
    }
    const paint = () => {
      const left = Math.ceil((until - Date.now()) / 1000);
      if (left <= 0) {
        clearInterval(undoTimer);
        bar.remove();
        return;
      }
      bar.innerHTML = `🗑 Retirée de tes favoris <button data-undo="${id}">↺ Annuler (${left} s)</button>`;
    };
    paint();
    undoTimer = setInterval(paint, 500);
    bar.onclick = (e) => {
      if (!e.target.dataset.undo) return;
      clearInterval(undoTimer);
      bar.remove();
      undoDelete(e.target.dataset.undo);
    };
  }

  async function undoDelete(id) {
    const r = await send({ type: 'cancel', id });
    if (!r?.ok) return toast('Déjà parti : impossible d’annuler.');
    S.videos[id].status = 'new';
    S.order = [id, ...S.order.filter((x) => x !== id)];
    hist = hist.filter((h) => h.id !== id);
    logAct('undo', id);
    await save();
    renderBody();
  }
  async function undo() {
    const h = hist.pop();
    if (!h) return toast('Rien à annuler');
    const v = S.videos[h.id];
    if (v.status === 'deleted') {
      const r = await send({ type: 'cancel', id: h.id });
      if (!r?.ok) {
        toast('Déjà retiré de TikTok, impossible d’annuler');
        return;
      }
    }
    if (v.collection && v.synced) v.removeFrom = v.collection; // l'annulation retire aussi la vidéo de la collection TikTok
    logAct('undo', h.id);
    Object.assign(v, { status: h.status, collection: h.collection, synced: false });
    scheduleSync();
    // remet la vidéo en tête de pile
    S.order = [h.id, ...S.order.filter((x) => x !== h.id)];
    await save();
    renderBody();
  }

  function pickCollection() {
    return new Promise((resolve) => {
      const m = document.createElement('div');
      m.className = 'modal';
      m.innerHTML = `<div class="box"><b>Ranger dans une collection</b><div style="height:10px"></div>
        ${S.collections.map((c, i) => `<button class="opt" data-i="${i}">📁 ${esc(c)}</button>`).join('')}
        <input placeholder="Nouvelle collection…" maxlength="30"><button class="pri" style="margin:6px 0 0">Créer et ranger</button>
        <button class="sec" style="margin:6px 0 0">Annuler</button></div>`;
      const done = (val) => { m.remove(); resolve(val); };
      m.addEventListener('click', (e) => {
        const t = e.target;
        if (t === m || t.classList.contains('sec')) return done(null);
        if (t.dataset.i) return done(S.collections[+t.dataset.i]);
        if (t.classList.contains('pri')) {
          const name = m.querySelector('input').value.trim();
          if (!name) return;
          if (!S.collections.includes(name)) S.collections.push(name);
          done(name);
        }
      });
      m.querySelector('input').addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') m.querySelector('.pri').click();
      });
      root.append(m);
    });
  }

  async function doCollection() {
    const name = await pickCollection();
    if (!name) return false;
    return act('col', name);
  }

  // ── Rendu ──
  // Déplacer les données d'un compte vers un autre : on les « met de côté » (clé « state »), puis on les reprend
  // depuis l'autre compte. Les retraits en attente sont annulés pour ne rien exécuter sur le mauvais compte.
  async function accountMenu() {
    const { state: shelf } = await chrome.storage.local.get('state');
    const shelfN = Object.keys(shelf?.videos || {}).length;
    const mineN = Object.keys(S.videos).length;
    const m = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = `<div class="box"><b>Compte actuel : ${esc(ACCOUNT)}</b>
      <p class="hint" style="max-width:none">${mineN} vidéos ici · ${shelfN} mises de côté</p>
      <button class="opt" data-a="shelve" ${mineN ? '' : 'disabled'}>📤 Mettre de côté les données de ce compte</button>
      <button class="opt" data-a="restore" ${shelfN ? '' : 'disabled'}>📥 Reprendre les données mises de côté (${shelfN})</button>
      <hr>
      <button class="opt" data-a="settings">⚙ Réglages (délais, sens des gestes)</button>
      <button class="opt" data-a="export">⬇ Exporter mes données (sauvegarde)</button>
      <label class="opt" style="display:block;cursor:pointer">⬆ Restaurer une sauvegarde<input type="file" accept=".json" hidden data-a="restore-file"></label>
      <hr>
      <button class="opt danger" data-a="reset">🗑 Tout réinitialiser (comme une nouvelle installation)</button>
      <button class="sec" style="margin:6px 0 0">Fermer</button></div>`;
    m.addEventListener('click', async (e) => {
      const t = e.target;
      if (t === m || t.classList.contains('sec')) return m.remove();
      if (t.dataset.a === 'settings') {
        m.remove();
        return settingsMenu();
      }
      if (t.dataset.a === 'export') return exportData();
      if (t.dataset.a === 'shelve') {
        if (shelfN && !confirm(`Remplacer les ${shelfN} vidéos déjà mises de côté ?`)) return;
        for (const v of Object.values(S.videos)) {
          if (v.status !== 'deleted') continue;
          const r = await send({ type: 'cancel', id: v.id });
          if (r?.ok) v.status = 'new'; // retrait pas encore parti : on l'annule
        }
        await chrome.storage.local.set({ state: S });
        S = { videos: {}, order: [], collections: [], confirmed: S.confirmed };
        normalizeState();
        await save();
        m.remove();
        render();
        toast('Données mises de côté. Ouvre l’autre compte pour les reprendre.');
      } else if (t.dataset.a === 'reset') {
        const warning =
          'Tout réinitialiser ?\n\nCela efface, pour TOUS les comptes, ton tri, tes collections locales, les données mises de côté ' +
          'et la file des retraits en attente.\nRien n’est modifié sur TikTok : tes favoris et tes collections TikTok restent intacts.';
        if (!confirm(warning)) return;
        if (!confirm('Dernière confirmation : repartir de zéro ?')) return;
        cancelOp = true; // arrête l’import ou la synchronisation en cours
        clearTimeout(syncTimer);
        // une écriture différée ne doit pas ressusciter l'ancien état juste après l'effacement
        clearTimeout(saveTimer);
        dirty = false;
        if (saving) await saving;
        await chrome.storage.local.clear();
        sessionStorage.removeItem('tts-resume');
        sessionStorage.removeItem('tts-fresh');
        S = { videos: {}, order: [], collections: [], confirmed: false, errors: {} };
        normalizeState();
        J = {};
        hist = [];
        legacyState = null;
        ACCOUNT = '';
        await loadAccount(); // relit le compte et prévient l’arrière-plan
        m.remove();
        tab = 'deck';
        render();
        toast('Extension réinitialisée : tout repart de zéro.');
      } else if (t.dataset.a === 'restore') {
        if (mineN && !confirm(`Remplacer les ${mineN} vidéos de ${ACCOUNT} par celles mises de côté ?`)) return;
        S = shelf;
        normalizeState();
        await chrome.storage.local.remove('state');
        await save();
        m.remove();
        render();
        toast('Données reprises pour ' + ACCOUNT);
      }
    });
    m.querySelector('[data-a="restore-file"]').onchange = (e) => {
      if (!e.target.files[0]) return;
      m.remove();
      restoreBackup(e.target.files[0]);
    };
    root.append(m);
  }

  function shell() {
    ov.innerHTML = `<header><div class="tabs">
      ${[['deck', 'Trier'], ['kept', 'Gardés'], ['cols', 'Collections'], ['del', 'Retirés'], ...(autoOn() ? [['auto', '🪄 Auto (bêta)']] : []), ['state', 'Suivi']]
        .map(([k, l]) => `<button class="tab ${tab === k ? 'on' : ''}" data-tab="${k}">${l}${k === 'state' && problemCount() ? ` <span class="badge">${problemCount()}</span>` : ''}</button>`).join('')}
      </div><button class="tab" id="stop" title="Arrêter l’opération en cours" ${scanning || syncing ? "" : "hidden"}>✕ Stop</button><span class="acct" id="scan-status"></span><span class="acct">${esc(ACCOUNT)}</span>${PLAN.configured ? (PLAN.pro ? '<button class="tab" id="pro-btn" title="Ta licence Pro">⭐ Pro</button>' : '<button class="tab pro" id="pro-btn" title="Retraits illimités, plus rapide : passe en Pro ou saisis ta clé">⭐ Passer en Pro</button>') : ''}<button class="tab ico" id="settings-btn" title="Réglages (langue, gestes, vitesse)" aria-label="Réglages (langue, gestes, vitesse)">⚙<span class="lbl"> Réglages</span></button>${PLAN.donateUrl ? '<button class="tab don ico" id="donate-btn" title="Soutenir le projet (don)" aria-label="Soutenir le projet (don)">☕<span class="lbl"> Faire un don</span></button>' : ''}<button class="tab acct-btn ico" title="Déplacer les données vers un autre compte" aria-label="Comptes">👤<span class="lbl"> Comptes</span></button><button class="tab" id="lang-btn" title="Langue" aria-label="Langue">🌐 ${typeof TTS_I18N !== 'undefined' ? TTS_I18N.lang.toUpperCase() : 'FR'}</button><button class="x" title="Fermer" aria-label="Fermer">✕</button></header><main id="body"></main>`;
  }

  function render() {
    shell();
    renderBody();
  }

  function renderBody() {
    const body = ov.querySelector('#body');
    if (!body) return;
    body.innerHTML = '';
    if (tab === 'auto' && !autoOn()) tab = 'deck';
    ({ deck: renderDeck, kept: renderKept, cols: renderCols, del: renderDel, auto: renderAuto, state: renderState })[tab](body);
    paintQueueChip();
    paintProgress();
  }

  function renderDeck(body) {
    const ids = pile();
    if (!ids.length && scanning && PROG) {
      // import en cours et rien à trier pour l'instant : un message clair plutôt que l'écran d'accueil
      body.innerHTML = `<div class="empty"><div class="spin big"></div><h2>${esc(PROG.title)}…</h2>
        <p>Les premières vidéos à trier apparaissent dans quelques secondes.</p>
        <p class="hint">${esc(PROG.note || SLOW_NOTE)}</p></div>`;
      return;
    }
    if (!ids.length) {
      const total = S.order.length;
      body.innerHTML = `<div class="empty"><h2>${total ? 'Tout est trié 🎉' : 'Importe tes favoris'}</h2>
        ${total ? `${doneStatsHtml()}<p>Tu peux réimporter pour récupérer les nouveaux favoris.</p>${reviewAskHtml(true)}` : `<ol class="quick"><li>Clique sur « Importer depuis mon profil TikTok » : l’extension lit tes favoris.</li><li>Glisse chaque vidéo : ${SET.swap ? '← retirer des favoris · → garder' : '← garder · → retirer des favoris'} · ↑ ranger dans une collection.</li><li>Les retraits et les rangements partent à TikTok tout seuls, en arrière-plan.</li></ol>`}
        <button class="pri" id="scan">${importIncomplete() ? `↻ Reprendre l’importation (${S.order.length} / ${S.importTotal})` : "Importer depuis mon profil TikTok"}</button>
        ${pendingSync() ? `<button class="sec" id="deck-sync">⇄ Synchroniser les collections (${pendingSync()})</button>` : ""}
        <label class="sec" style="display:inline-block;cursor:pointer">Importer l’export JSON
          <input type="file" accept=".json,.txt" hidden id="file"></label>
        <div id="scan-count" class="hint"></div>
        <p class="hint">Autre méthode : importer l’export JSON de TikTok (Paramètres → Compte → Télécharger tes données).</p>
        <p class="hint" style="color:#e6a5aa">⚠ ${RISK_SHORT}</p></div>`;
      body.querySelector('#scan').onclick = scanFavorites;
      bindReviewAsk(body);
      body.querySelector('#deck-sync')?.addEventListener('click', () => syncCollections());
      body.querySelector('#file').onchange = (e) => e.target.files[0] && importFile(e.target.files[0]);
      return;
    }
    const id = ids[0];
    const nextId = ids[1];
    const total = S.order.length;
    const done = total - ids.length;
    const swap = SET.swap;
    const sugHtml = suggestionHtml(); // calculée avant les pastilles, pour allumer la collection proposée
    // boutons avec leur nom et leur touche : on comprend sans lire l'aide
    const actBtn = (cls, ico, label, key, title) =>
      `<button class="rb ${cls}" title="${title}" aria-label="${title}"><span class="ic" aria-hidden="true">${ico}</span><small>${label}</small><kbd aria-hidden="true">${key}</kbd></button>`;
    const keepBtn = actBtn('keep', '♥', 'Garder', swap ? '→' : '←', `Garder (${swap ? '→' : '←'})`);
    const colBtn = actBtn('col', '📁', 'Ranger', '↑', 'Collection (↑)');
    const delBtn = actBtn('del', '✕', 'Retirer', swap ? '←' : '→', `Retirer des favoris (${swap ? '←' : '→'})`);
    body.innerHTML = `<div class="deckwrap ${swap ? 'swap' : ''}"><aside class="cols"><h4>Collections (${S.collections.length})</h4>
      <button class="syncbtn" id="deck-sync" title="Envoie tes rangements et retraits de collections à TikTok">${syncing ? '⏳ Synchronisation…' : `⇄ Synchroniser les collections (${pendingSync()})`}</button>
      <input class="colsearch" id="colsearch" placeholder="🔍 Chercher une collection…" value="${esc(deckSearch)}" autocomplete="off">
      <button class="chip new" data-new="1">＋ Nouvelle collection</button>
      <div class="chips">${chipsHtml()}</div></aside>
      <div class="deckmain"><div class="toprow"><div class="count" role="status">${ids.length} à trier</div>
      <button class="sec small" id="resume" ${scanning ? "hidden" : ""} title="Lit ton onglet Favoris sur TikTok. Les vidéos déjà importées ne sont pas dupliquées : ça reprend un import interrompu ou récupère les nouveaux favoris.">${resumeLabel()}</button></div>
      <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round((done / total) * 100)}"><i style="width:${(done / total) * 100}%"></i></div>
      <div class="stage">${cardHtml(id, true)}${nextId ? cardHtml(nextId, false) : ''}${sugHtml}</div>
      <div class="btns"><button class="rb undo" title="Annuler (Z)" aria-label="Annuler (Z)"><span class="ic" aria-hidden="true">↺</span><small>Défaire</small><kbd aria-hidden="true">Z</kbd></button>
        ${swap ? `${delBtn}${colBtn}${keepBtn}` : `${keepBtn}${colBtn}${delBtn}`}</div>
      <div class="hint">${swap ? '← retirer des favoris · → garder' : '← garder · → retirer des favoris'} · ↑ ranger · touches 1-9 : collection numérotée. Glisse la carte de n’importe où ; ▶ au centre (ou Espace) pour lire. Dépose-la sur une collection pour la ranger.</div>${reviewAskHtml(false)}</div></div>`;
    bindReviewAsk(body);
    body.querySelector('.cols').addEventListener('click', (e) => {
      const pin = e.target.closest('[data-pin]');
      if (pin) return togglePin(pin.dataset.pin);
      const chip = e.target.closest('.chip');
      const card = topCard();
      if (chip && card) dropOn(card, chip);
    });
    body.querySelector('#colsearch').addEventListener('input', (e) => {
      deckSearch = e.target.value;
      body.querySelector('.chips').innerHTML = chipsHtml();
    });
    body.querySelector('#deck-sync')?.addEventListener('click', () => syncCollections());
    body.querySelector('#resume')?.addEventListener('click', () => scanFavorites());
    body.querySelector('.rb.undo').onclick = undo;
    for (const k of ['del', 'keep', 'col']) {
      body.querySelector(`.rb.${k}`).onclick = () => {
        const card = topCard();
        if (card && !card.dataset.gone) fly(card, k);
      };
    }
    armCard(topCard());
  }

  // ── Vignettes ──
  // Les adresses des vignettes TikTok sont signées et EXPIRENT (paramètre x-expires, en secondes) : passé ce délai,
  // l'image ne s'affiche plus. On n'utilise donc que les adresses encore valides ; sinon la tuile montre le début de
  // la description de la vidéo (constaté : tuiles vides dans l'onglet Auto).
  function thumbOk(url) {
    if (!url || !/^https?:/.test(url)) return '';
    const exp = Number((url.match(/[?&]x-expires=(\d+)/) || [])[1]);
    return exp && exp * 1000 < Date.now() + 60e3 ? '' : url;
  }
  const bgStyle = (v) => {
    const u = thumbOk(v?.thumb);
    return u ? `style="background-image:url('${esc(u)}')"` : 'data-nothumb="1"';
  };
  // début de la description (sans « created by … ») : toujours dans l'onglet Auto, sinon seulement sans vignette
  function descHtml(v, always = false) {
    if (!always && thumbOk(v?.thumb)) return '';
    const d = String(v?.text || '').split(/(?:^|\s+)(?:created by|créé par|creado por|erstellt von|criado por|creato da)\s+/i)[0].trim();
    return d ? `<div class="desc" data-nt>${esc(d.slice(0, 110))}</div>` : '';
  }

  // ── Rangement automatique (bêta) ──
  // Le texte de chaque vidéo (description, hashtags, créateur, musique) est celui de sa vignette dans la liste des favoris
  // (« … #gaming #cyberpunk created by X with Y », vérifié sur le vrai site). L'extension apprend, à partir des vidéos déjà
  // rangées, quels mots et hashtags vont avec chaque collection (classement bayésien naïf), et y ajoute les mots-clés que
  // l'utilisateur donne lui-même. Tout est calculé dans le navigateur ; rien n'est envoyé à TikTok sans validation.
  // « … created by X with Y » ; quand la vidéo n'a pas de description, le texte COMMENCE par « created by »
  const AUTHOR_RE = /(?:^|\s+)(?:created by|créé par|cree par|creado por|erstellt von|criado por|creato da)\s+/i;
  // hashtags passe-partout (« pour toi », « viral »…) : ils ne disent rien du sujet
  const GENERIC_TAG = /^(fyp|fy|foryou|foryoupage|fypシ|pourtoi|pourtoii+|parati|paratii|furdich|fuerdich|perte|pertepage|viral|viralvideo|trend|trending|tiktok|xyzbca|xyz|capcut|explore|explorepage)/;
  const STOP = new Set(('les des une pour avec dans sur par pas est que qui mais plus tout tous cette ces son ses leur nous vous ils elle elles aux etre avoir fait faire comme bien tres trop moi toi lui ' +
    'the and for with this that you your are was from have has not but all can just like what when how out get got its it\'s new day part ' +
    'los las del con por para una que como pero mas muy este esta ' +
    'der die das und mit für fur ist nicht ein eine auf den dem des sich auch wie ' +
    'para com uma que nao mais como esse essa ' +
    'gli che per con una non come anche piu ' +
    // formules de TikTok et appels à s'abonner : ne disent rien du sujet de la vidéo
    'created original sound son audio originale sonido suono som follow more content link bio video videos part like comment share subscribe abonne abonnez').split(' '));
  const normTxt = (s) => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const tokCache = new Map();
  function tokensOf(v) {
    const text = v?.text || '';
    const c = tokCache.get(v.id);
    if (c && c.text === text) return c.toks;
    const [desc, rest = ''] = text.split(AUTHOR_RE);
    const toks = [];
    for (const h of desc.matchAll(/#([\p{L}\p{N}_]+)/gu)) {
      const w = normTxt(h[1]);
      if (w.length > 1 && !GENERIC_TAG.test(w)) toks.push('#' + w);
    }
    const words = normTxt(desc.replace(/#[\p{L}\p{N}_]+/gu, ' ').replace(/@[\w.]+/g, ' ')).split(/[^\p{L}\p{N}]+/u);
    for (const w of words) if (w.length >= 3 && !STOP.has(w) && !/^\d+$/.test(w)) toks.push(w);
    const author = rest.split(/\s+(?:with|avec|con|mit|com)\s+/i)[0].trim();
    if (author) toks.push('@' + normTxt(author));
    const out = [...new Set(toks)];
    tokCache.set(v.id, { text, toks: out });
    return out;
  }
  // mots-clés donnés par l'utilisateur pour une collection (« #cuisine, recette ») → jetons comparables
  const ruleToks = (s) => String(s || '').split(/[,;\n]+|\s+/).map((w) => normTxt(w.trim()).replace(/^#/, '')).filter((w) => w.length > 1);
  let AUTO_MODEL = null;
  let autoModelKey = '';
  function autoModel() {
    // n'apprend que des rangements faits à la main (ou lus dans TikTok), jamais de ses propres propositions
    const filed = Object.values(S.videos).filter((v) => v.status === 'kept' && v.collection && v.text && !v.auto);
    const rules = S.colRules || {};
    const key = `${filed.length}|${filed.reduce((n, v) => n + v.collection.length, 0)}|${S.collections.join('/')}|${JSON.stringify(rules)}`;
    if (AUTO_MODEL && key === autoModelKey) return AUTO_MODEL;
    const cls = {};
    const vocab = new Set();
    for (const v of filed) {
      const c = (cls[v.collection] ||= { n: 0, tf: new Map(), total: 0 });
      c.n++;
      for (const t of tokensOf(v)) {
        const w = t[0] === '#' ? 2 : 1; // un hashtag en dit plus qu'un mot de la description
        c.tf.set(t, (c.tf.get(t) || 0) + w);
        c.total += w;
        vocab.add(t);
      }
    }
    AUTO_MODEL = { cls, V: Math.max(1, vocab.size), N: Math.max(1, filed.length), rules, learned: Object.values(cls).filter((c) => c.n >= 3).length, examples: filed.length };
    autoModelKey = key;
    return AUTO_MODEL;
  }
  // Collection proposée pour une vidéo : { collection, p (0..1), rule } ou null
  function suggestFor(v) {
    if (!v?.text) return null;
    const toks = tokensOf(v);
    if (!toks.length) return null;
    const M = autoModel();
    const tokSet = new Set(toks);
    for (const [c, kw] of Object.entries(M.rules)) {
      if (!S.collections.includes(c)) continue;
      if (ruleToks(kw).some((w) => tokSet.has(w) || tokSet.has('#' + w))) return { collection: c, p: 1, rule: true };
    }
    const scores = [];
    for (const [c, d] of Object.entries(M.cls)) {
      if (d.n < 3 || !S.collections.includes(c)) continue; // trop peu d'exemples pour apprendre
      let s = Math.log(d.n / M.N);
      let hits = 0;
      for (const t of toks) {
        const f = d.tf.get(t) || 0;
        // preuve : un hashtag commun compte 2, le même créateur 1,5, un mot de la description 1
        if (f) hits += t[0] === '#' ? 2 : t[0] === '@' ? 1.5 : 1;
        s += Math.log((f + 0.3) / (d.total + 0.3 * M.V));
      }
      scores.push({ c, s, hits });
    }
    if (!scores.length) return null;
    const max = Math.max(...scores.map((x) => x.s));
    const sum = scores.reduce((n, x) => n + Math.exp(x.s - max), 0);
    const best = scores.reduce((a, b) => (b.s > a.s ? b : a));
    // Pas assez de points communs avec la collection (un seul mot banal, par exemple) : pas de proposition. Constaté sur
    // un vrai compte : deux vidéos de jeu proposées dans « Calisthénie » à cause d'un seul mot en commun.
    if (best.hits < 2) return null;
    // la confiance tient compte de la quantité de preuves, pas seulement du classement entre collections
    const p = (Math.exp(best.s - max) / sum) * Math.min(1, best.hits / 4);
    return p >= 0.5 ? { collection: best.c, p, rule: false } : null;
  }
  const autoOn = () => !!SET.autoSort;
  const pct = (p) => `${Math.round(p * 100)} %`;
  // Suggestion pour la carte affichée : pastille au-dessus de la carte, collection en surbrillance, Entrée pour accepter.
  let deckSuggestion = null;
  function suggestionHtml() {
    const id = pile()[0];
    deckSuggestion = autoOn() && id ? suggestFor(S.videos[id]) : null;
    if (!deckSuggestion) return '';
    return `<button class="suggest" id="suggest" title="Entrée : ranger dans cette collection">💡 ${esc(deckSuggestion.collection)} <small>${deckSuggestion.rule ? 'mot-clé' : pct(deckSuggestion.p)}</small> <kbd>Entrée</kbd></button>`;
  }
  function paintSuggestion() {
    const stage = ov?.querySelector('.stage');
    if (!stage) return;
    stage.querySelector('#suggest')?.remove();
    const html = suggestionHtml();
    if (html) stage.insertAdjacentHTML('beforeend', html);
  }
  let colFromSuggestion = false; // le prochain rangement vient d'une proposition acceptée (voir act)
  function acceptSuggestion() {
    const card = topCard();
    if (!card || !deckSuggestion || card.dataset.gone) return false;
    colFromSuggestion = true;
    setTimeout(() => (colFromSuggestion = false), 1500); // rangement abandonné : le drapeau ne déborde pas sur le suivant
    const chip = [...ov.querySelectorAll('.chips .chip')].find((c) => c.dataset.name === deckSuggestion.collection);
    if (chip) dropOn(card, chip);
    else flyOut(card, 'col', deckSuggestion.collection);
    return true;
  }

  // Onglet « Auto (bêta) » : toutes les propositions pour les vidéos à trier, cochées si la confiance est forte.
  const AUTO_CHECK = 0.8;
  const autoPick = new Map(); // id → coché ou non (choix de l'utilisateur, sinon selon la confiance)
  const autoTarget = new Map(); // id → collection choisie à la main (✎) à la place de la proposition
  function renderAuto(body) {
    const M = autoModel();
    const todo = pile();
    const noText = todo.filter((id) => !S.videos[id].text).length;
    const groups = new Map();
    for (const id of todo) {
      const sg = autoTarget.has(id) ? { collection: autoTarget.get(id), p: 1, manual: true } : suggestFor(S.videos[id]);
      if (!sg) continue;
      if (!groups.has(sg.collection)) groups.set(sg.collection, []);
      groups.get(sg.collection).push({ v: S.videos[id], p: sg.p, rule: sg.rule, manual: sg.manual });
    }
    const picked = (x) => (autoPick.has(x.v.id) ? autoPick.get(x.v.id) : x.p >= AUTO_CHECK);
    const all = [...groups.values()].flat();
    const nPicked = all.filter(picked).length;
    const list = [...groups].sort((a, b) => b[1].length - a[1].length);
    body.innerHTML = `<div class="auto">
      <p class="betanote">🧪 <b>Rangement automatique — bêta.</b> Propositions faites d’après la description et les hashtags de chaque vidéo, en s’inspirant de tes collections. Fonction en phase de test : vérifie avant de valider. Rien n’est envoyé à TikTok sans ta validation.</p>
      <ul class="howto"><li>Clique sur une vidéo pour la cocher ou la décocher.</li><li>✎ : la mettre dans une autre collection (ou une nouvelle).</li><li>Les vidéos décochées restent à trier normalement : rien ne leur arrive.</li></ul>
      <p class="hint" style="max-width:none">Appris à partir de ${M.examples} vidéos rangées · ${M.learned} collection(s) reconnue(s) · ${all.length} proposition(s) sur ${todo.length} vidéos à trier.</p>
      ${noText ? `<p class="warn">${noText} vidéos à trier n’ont pas encore de description enregistrée (importées avec une version plus ancienne). <button class="sec small" id="auto-reread">↻ Relire tous mes favoris</button></p>` : ''}
      <details class="adv" id="auto-rules"><summary>Mes mots-clés par collection</summary>
        <p class="hint" style="max-width:none;text-align:left">Une vidéo qui contient l’un de ces mots ou hashtags va dans la collection (prioritaire sur l’apprentissage). Sépare-les par des virgules.</p>
        ${S.collections.map((c) => `<label class="fld rule"><span>📁 ${esc(c)}</span><input data-rule="${esc(c)}" value="${esc((S.colRules || {})[c] || '')}" placeholder="#recette, cuisine"></label>`).join('')}
      </details>
      ${list.length ? '' : `<div class="empty"><p>Aucune proposition pour l’instant. Range quelques vidéos à la main (au moins 3 par collection) ou ajoute des mots-clés : les propositions apparaîtront ici.</p></div>`}
      ${list
        .map(([c, xs]) => {
          xs.sort((a, b) => b.p - a.p);
          const { items, more } = paged(xs, `auto:${c}`);
          return `<h3>📁 ${esc(c)} <small>(${xs.length})</small> <button class="ren" data-autoall="${esc(c)}">tout cocher / décocher</button></h3>
            <div class="grid">${items.map((x) => `<div class="item auto-it ${picked(x) ? 'picked' : ''}" data-auto="${x.v.id}" ${bgStyle(x.v)} title="${esc(x.v.text)}">${descHtml(x.v, true)}<div class="chk">${picked(x) ? '☑' : '☐'}</div><div class="lbl"><span>${x.manual ? 'choisie' : x.rule ? 'mot-clé' : pct(x.p)}</span><span class="acts"><button data-autochg="${x.v.id}" title="Choisir une autre collection">✎</button></span></div></div>`).join('')}</div>${more}`;
        })
        .join('')}
      ${all.length ? `<div class="autobar"><button class="pri" id="auto-apply" ${nPicked ? '' : 'disabled'}>📁 Ranger les ${nPicked} vidéos cochées</button></div>` : ''}
    </div>`;
    bindBack(body);
    body.querySelector('#auto-reread')?.addEventListener('click', () => scanFavorites({ full: true }));
    body.querySelectorAll('[data-rule]').forEach((inp) =>
      inp.addEventListener('change', () => {
        S.colRules = { ...(S.colRules || {}), [inp.dataset.rule]: inp.value.trim() };
        if (!S.colRules[inp.dataset.rule]) delete S.colRules[inp.dataset.rule];
        save();
        const open = body.querySelector('#auto-rules')?.open;
        renderBody();
        if (open) ov.querySelector('#auto-rules')?.setAttribute('open', '');
      }),
    );
    // cocher / décocher sur place (sans redessiner l'onglet : la position dans la liste ne bouge pas)
    const applyBtn = body.querySelector('#auto-apply');
    const recount = () => {
      const n = all.filter(picked).length;
      if (!applyBtn) return;
      applyBtn.textContent = `📁 Ranger les ${n} vidéos cochées`;
      applyBtn.disabled = !n;
    };
    // ✎ : autre collection pour cette vidéo (la tuile passe dans le groupe choisi, cochée) ; la position dans la liste est gardée
    body.querySelectorAll('[data-autochg]').forEach((b) =>
      b.addEventListener('click', async (e) => {
        e.stopPropagation();
        const name = await pickCollection();
        if (!name) return;
        autoTarget.set(b.dataset.autochg, name);
        autoPick.set(b.dataset.autochg, true);
        const top = ov.querySelector('main')?.scrollTop || 0;
        renderBody();
        const main = ov.querySelector('main');
        if (main) main.scrollTop = top;
        toast(`Déplacée dans « ${name} »`);
      }),
    );
    body.querySelectorAll('[data-auto]').forEach((el) =>
      el.addEventListener('click', () => {
        const x = all.find((y) => y.v.id === el.dataset.auto);
        const on = !picked(x);
        autoPick.set(el.dataset.auto, on);
        el.classList.toggle('picked', on);
        el.querySelector('.chk').textContent = on ? '☑' : '☐';
        recount();
      }),
    );
    body.querySelectorAll('[data-autoall]').forEach((b) =>
      b.addEventListener('click', () => {
        const xs = groups.get(b.dataset.autoall) || [];
        const on = !xs.every(picked);
        xs.forEach((x) => autoPick.set(x.v.id, on));
        renderBody();
      }),
    );
    body.querySelector('#auto-apply')?.addEventListener('click', () => {
      if (accountChanged()) return;
      let n = 0;
      for (const [c, xs] of groups) {
        const chosen = xs.filter(picked);
        for (const x of chosen) {
          Object.assign(x.v, { status: 'kept', collection: c, synced: false, auto: !x.manual });
          logAct('col', x.v.id, c);
        }
        if (chosen.length) touchRecent(c);
        n += chosen.length;
      }
      autoPick.clear();
      autoTarget.clear();
      save();
      scheduleSync();
      toast(`${n} vidéo(s) rangée(s) automatiquement : envoi à TikTok en cours`);
      renderBody();
    });
  }

  // ── Bilan et invitation à laisser un avis ──
  function sortStats() {
    const s = { kept: 0, filed: 0, removed: 0 };
    for (const v of Object.values(S.videos)) {
      if (v.status === 'deleted') s.removed++;
      else if (v.status === 'kept') v.collection ? s.filed++ : s.kept++;
    }
    s.sorted = s.kept + s.filed + s.removed;
    return s;
  }
  const fmtN = (n) => n.toLocaleString(typeof TTS_I18N !== 'undefined' ? TTS_I18N.locale() : 'fr-FR');
  const doneStatsHtml = () => {
    const s = sortStats();
    return `<div class="stats"><div><b>${fmtN(s.sorted)}</b><span>vidéos triées</span></div><div><b>${fmtN(s.removed)}</b><span>retirées des favoris</span></div><div><b>${fmtN(s.filed)}</b><span>rangées en collection</span></div><div><b>${fmtN(s.kept)}</b><span>gardées</span></div></div>`;
  };
  // Une seule invitation, discrète : après 150 vidéos triées (ou à la fin du tri), jamais pendant un geste. « Plus tard »
  // la repousse de 10 jours, « Laisser un avis » ou « Non merci » l'arrêtent pour de bon.
  const REVIEW_AFTER = 150;
  function reviewAskHtml(atEnd) {
    if (!PLAN.reviewUrl || SET.review === 'done') return '';
    if (SET.reviewLater && Date.now() - SET.reviewLater < 10 * 864e5) return '';
    if (!atEnd && sortStats().sorted < REVIEW_AFTER) return '';
    return `<div class="nudge" id="review-ask">⭐ <span>Ça te fait gagner du temps ? Un avis sur le Chrome Web Store aide beaucoup l’extension à être trouvée.</span>
      <button class="pri" data-rv="go">Laisser un avis</button><button class="sec" data-rv="later">Plus tard</button><button class="ren" data-rv="never" title="Ne plus demander">✕</button></div>`;
  }
  function bindReviewAsk(body) {
    body.querySelector('#review-ask')?.addEventListener('click', (e) => {
      const a = e.target.closest('[data-rv]')?.dataset.rv;
      if (!a) return;
      if (a === 'go') window.open(PLAN.reviewUrl, '_blank', 'noopener');
      if (a === 'later') SET.reviewLater = Date.now();
      else SET.review = 'done';
      saveSettings();
      body.querySelector('#review-ask')?.remove();
    });
  }

  // ── Pile de cartes ──
  // Deux cartes à l'écran : celle qu'on trie et, juste derrière, la suivante. Après un geste, la suivante passe devant
  // telle quelle et une nouvelle carte se prépare derrière : l'écran n'est pas redessiné en entier (voir advanceDeck).
  // Une carte montre d'abord la vignette et la description ; le lecteur TikTok ne se charge qu'au clic sur ▶ (ou Espace).
  // Avant la 0.9.8, chaque carte (et la suivante, d'avance) chargeait son lecteur : des centaines de chargements par
  // jour, et TikTok a fini par bloquer la lecture intégrée pour toute la connexion (« ratelimit triggered », constaté
  // pendant plus d'un jour, même sans être connecté à TikTok).
  // Deux lecteurs : « player/v1 » (le plus sobre) et « embed/v2 ». Quand player/v1 refuse une vidéo (« Watch this video
  // on TikTok »), on passe à embed/v2, retenu un jour. Quand TikTok répond « ratelimit triggered », on ne charge plus
  // aucun lecteur pendant LIMIT_PAUSE : ▶ propose directement d'ouvrir la vidéo sur TikTok.
  const LIMIT_PAUSE = 30 * 60e3;
  let playerKind = 'v1';
  let embedSince = 0;
  let limitedUntil = 0;
  try {
    const p = JSON.parse(localStorage.getItem('tts-player') || 'null');
    if (p?.kind === 'embed' && Date.now() - p.at < 864e5) [playerKind, embedSince] = ['embed', p.at];
    limitedUntil = Number(p?.limitedUntil) || 0;
  } catch {
    /* stockage du site indisponible */
  }
  function savePlayerPref() {
    try {
      localStorage.setItem('tts-player', JSON.stringify({ kind: playerKind, at: embedSince, limitedUntil }));
    } catch {
      /* tant pis : réglage oublié à la prochaine page */
    }
  }
  const player = (vid) =>
    playerKind === 'embed'
      ? `https://www.tiktok.com/embed/v2/${vid}`
      : `https://www.tiktok.com/player/v1/${vid}?controls=1&progress_bar=1&play_button=1&volume_control=1&fullscreen_button=0&timestamp=0&music_info=0&description=0&rel=0&loop=1&autoplay=1`;
  function useEmbedPlayer() {
    [playerKind, embedSince] = ['embed', Date.now()];
    savePlayerPref();
    ov?.querySelectorAll('.card iframe:not([data-player="embed"])').forEach((f) => {
      f.dataset.player = 'embed';
      f.src = player(f.closest('.card').dataset.id);
    });
  }
  const CARD_PARTS = `<div class="drag top"></div><div class="drag mid"></div><div class="drag bot"></div>
        <div class="tag keep">GARDER</div><div class="tag del">RETIRER</div><div class="tag col">📁 RANGER</div>`;
  // La carte de derrière n'a pas encore ses couches de glissement : elles n'apparaissent qu'au premier plan.
  const cardHtml = (vid, top) =>
    `<div class="card ${top ? 'top' : 'next'}" data-id="${vid}"><div class="poster" ${bgStyle(S.videos[vid])}>${descHtml(S.videos[vid], true)}<button class="play" title="Lire la vidéo (Espace)" aria-label="Lire la vidéo (Espace)" ${top ? '' : 'tabindex="-1"'}>▶</button></div>${top ? CARD_PARTS : ''}</div>`;
  const topCard = () => ov?.querySelector('.stage .card.top');
  function armCard(card) {
    if (!card) return;
    if (!card.querySelector('.drag')) card.insertAdjacentHTML('beforeend', CARD_PARTS);
    card.querySelectorAll('.drag').forEach((d) => attachDrag(card, d));
    const play = card.querySelector('.play');
    if (play && !play.onclick) play.onclick = () => playCard(card);
  }
  // ▶ : charge le lecteur par-dessus la vignette (sauf pendant une limitation de TikTok).
  function playCard(card) {
    if (!card || card.querySelector('iframe, .noplay')) return;
    if (Date.now() < limitedUntil) return showNoPlay(card, true);
    card.querySelector('.poster').insertAdjacentHTML(
      'afterend',
      `<iframe src="${player(card.dataset.id)}" data-player="${playerKind}" allow="autoplay; encrypted-media; fullscreen"></iframe>`,
    );
    watchPlayer(card);
  }
  // Lecture impossible : vignette ou description, la raison, et un bouton pour ouvrir la vidéo dans un nouvel onglet.
  // Sous les couches de glissement : la carte se glisse toujours.
  function showNoPlay(card, limited) {
    const v = S.videos[card.dataset.id];
    if (!v || card.querySelector('.noplay')) return;
    card.querySelector('iframe')?.remove();
    const msg = limited
      ? `TikTok limite la lecture des vidéos ici pour l’instant (trop de vidéos chargées). Nouvel essai possible après ${hhmm(limitedUntil)}.`
      : 'TikTok ne permet pas de lire cette vidéo ici.';
    card.querySelector('.poster').insertAdjacentHTML(
      'afterend',
      `<div class="noplay" ${bgStyle(v)}>${descHtml(v, true)}<div class="noplay-msg">${msg}</div><a class="noplay-open" href="${esc(v.url)}" target="_blank" rel="noopener">▶ Voir sur TikTok</a></div>`,
    );
  }
  // Le lecteur de TikTok refuse parfois une vidéo et affiche « Watch this video on TikTok / Watch now ». Le lecteur est
  // sur le même site (tiktok.com) : on regarde dedans. Sans élément <video> au bout de quelques secondes, player/v1
  // cède la place à embed/v2 ; si celui-ci refuse aussi, la carte montre la vignette ou la description, avec un bouton
  // pour ouvrir la vidéo dans un nouvel onglet : on peut quand même décider.
  function watchPlayer(card) {
    if (!card || card.dataset.watch) return;
    card.dataset.watch = '1';
    let tries = 0;
    let src = '';
    const t = setInterval(() => {
      if (!card.isConnected) return clearInterval(t);
      const frame = card.querySelector('iframe');
      let doc = null;
      try {
        doc = frame?.contentDocument;
      } catch {
        /* lecteur d'un autre site : on ne peut pas regarder */
      }
      if (!doc) return; // illisible pour l'instant (page en cours de chargement…) : on réessaie à la seconde suivante
      if (frame.src !== src) [src, tries] = [frame.src, 0]; // lecteur changé : on recompte
      const embed = frame.dataset.player === 'embed';
      if (doc.querySelector('video')) {
        if (embed) return tidyEmbed(doc, card); // on continue de veiller : la page d'embed/v2 se redessine parfois
        return clearInterval(t); // la vidéo est là
      }
      if (doc.readyState === 'complete' && /ratelimit/i.test(doc.body?.innerText || '')) {
        // limitation de toute la connexion : inutile d'essayer l'autre lecteur, ni d'insister
        clearInterval(t);
        limitedUntil = Date.now() + LIMIT_PAUSE;
        savePlayerPref();
        return showNoPlay(card, true);
      }
      if (++tries < (embed ? 8 : 3) || doc.readyState !== 'complete' || !doc.body?.childElementCount) return;
      if (!embed) return useEmbedPlayer();
      clearInterval(t);
      showNoPlay(card, false);
    }, 1000);
  }
  // La page embed/v2 entoure la vidéo de son cadre (statistiques, « Watch now »…) et contient parfois plusieurs copies
  // de la vidéo. On garde la plus grande copie visible, en plein cadre avec les commandes du navigateur ; tout le reste
  // est caché (les copies en pause). Les transformations de la page sont neutralisées : sinon la vidéo resterait
  // enfermée dans son cadre d'origine, sous les couches de TikTok. La carte de derrière reste en pause ; elle démarre
  // (sans le son) en passant devant.
  const EMBED_CSS = `html, body { overflow: hidden !important; background: #000 !important; }
    body * { visibility: hidden !important; transform: none !important; filter: none !important; contain: none !important;
      perspective: none !important; backdrop-filter: none !important; will-change: auto !important; }
    video[data-tts-main] { visibility: visible !important; position: fixed !important; inset: 0 !important; width: 100vw !important;
      height: 100vh !important; max-width: none !important; max-height: none !important; margin: 0 !important; object-fit: contain !important;
      background: #000 !important; z-index: 2147483647 !important; opacity: 1 !important; }`;
  function tidyEmbed(doc, card) {
    const vids = [...doc.querySelectorAll('video')];
    let main = vids.find((v) => v.hasAttribute('data-tts-main'));
    let style = doc.getElementById('tts-tidy');
    if (!main) {
      if (style) style.disabled = true; // mesurer les copies telles que TikTok les affiche
      let best = 0;
      for (const v of vids) {
        const r = v.getBoundingClientRect();
        const area = r.width * r.height;
        if (getComputedStyle(v).visibility !== 'hidden' && area >= best && area > 0) [main, best] = [v, area];
      }
      if (style) style.disabled = false;
      if (!main) return;
      main.setAttribute('data-tts-main', '');
      main.controls = true;
      main.loop = true;
    }
    if (!style) {
      style = doc.createElement('style');
      style.id = 'tts-tidy';
      style.textContent = EMBED_CSS;
      (doc.head || doc.documentElement).append(style);
    }
    for (const v of vids) {
      if (v === main || v.paused) continue;
      v.muted = true;
      v.pause();
    }
    const top = card.classList.contains('top');
    if (!top && !main.paused) main.pause();
    if (top && !card.dataset.started) {
      card.dataset.started = '1';
      main.play()?.catch(() => {});
    }
  }

  // Après un geste : la carte suivante (déjà chargée) passe devant. Renvoie false si ce n'est pas possible (la pile a
  // changé autrement : annulation, nouveaux favoris insérés en tête…) ; il faut alors tout redessiner.
  function advanceDeck() {
    if (tab !== 'deck' || ov.hidden) return false;
    const stage = ov.querySelector('.stage');
    const next = stage?.querySelector('.card.next');
    const ids = pile();
    if (!next || next.dataset.id !== ids[0]) return false;
    stage.querySelector('.card.top')?.remove();
    next.classList.replace('next', 'top');
    next.querySelector('.play')?.removeAttribute('tabindex');
    armCard(next);
    if (ids[1]) stage.insertAdjacentHTML('beforeend', cardHtml(ids[1], false));
    const total = S.order.length;
    const c = ov.querySelector('.deckmain .count');
    if (c) c.textContent = `${ids.length} à trier`;
    const bar = ov.querySelector('.deckmain .bar i');
    if (bar) bar.style.width = `${((total - ids.length) / total) * 100}%`;
    paintSuggestion(); // avant les pastilles : la collection proposée s'y allume
    refreshChips();
    updateSyncBtn();
    if (!ov.querySelector('#review-ask')) {
      const ask = reviewAskHtml(false);
      if (ask) {
        ov.querySelector('.deckmain')?.insertAdjacentHTML('beforeend', ask);
        bindReviewAsk(ov);
      }
    }
    paintQueueChip();
    paintProgress();
    return true;
  }
  // Pendant l'import, la pile peut passer d'une seule vidéo à plusieurs : on prépare alors la carte de derrière.
  function ensureNext() {
    const stage = ov?.querySelector('.stage');
    const top = stage?.querySelector('.card.top');
    const ids = pile();
    if (!top || stage.querySelector('.card.next') || top.dataset.id !== ids[0] || !ids[1]) return;
    stage.insertAdjacentHTML('beforeend', cardHtml(ids[1], false));
  }
  // Rafraîchit l'écran de tri après un changement de la pile : passage rapide à la carte suivante, sinon rendu complet.
  const deckChanged = () => advanceDeck() || renderBody();

  // Panneau des collections : épinglées d'abord, puis récentes ; les 9 premières ont un raccourci clavier (touches 1-9).
  let deckSearch = '';
  function chipsHtml() {
    const counts = {};
    for (const v of Object.values(S.videos)) if (v.status === 'kept' && v.collection) counts[v.collection] = (counts[v.collection] || 0) + 1;
    const q = deckSearch.trim().toLowerCase();
    return orderedCollections()
      .filter((c) => !q || c.toLowerCase().includes(q))
      .map((c, i) => {
        const pinned = (S.pinned || []).includes(c);
        return `<button class="chip ${deckSuggestion?.collection === c ? 'sugg' : ''}" data-name="${esc(c)}"><span>${i < 9 ? `<kbd>${i + 1}</kbd>` : ''}${esc(c)}</span><small>${counts[c] || 0}</small>
          <i class="pin ${pinned ? 'on' : ''}" data-pin="${esc(c)}" title="${pinned ? 'Désépingler' : 'Épingler en haut'}">${pinned ? '★' : '☆'}</i></button>`;
      })
      .join('');
  }

  // Met à jour le panneau des collections de l'écran de tri sans toucher à la carte (son lecteur n'est pas rechargé).
  function refreshChips() {
    if (tab !== 'deck' || !ov || ov.hidden) return;
    const chips = ov.querySelector('.chips');
    if (chips) chips.innerHTML = chipsHtml();
    const h4 = ov.querySelector('.cols h4');
    if (h4) h4.textContent = `Collections (${S.collections.length})`;
  }

  async function togglePin(name) {
    S.pinned = (S.pinned || []).includes(name) ? S.pinned.filter((c) => c !== name) : [...(S.pinned || []), name];
    refreshChips();
    save();
  }

  const dirs = () => ({ keep: [keepSign(), 0], del: [-keepSign(), 0], col: [0, -1] });

  // Collection sous le pointeur (le panneau est dans le shadow DOM : elementsFromPoint traverse la carte déplacée).
  const chipAt = (x, y) => root.elementsFromPoint(x, y).find((el) => el.classList?.contains('chip'));

  // Range la vidéo dans la collection de la pastille (clic ou dépôt) ; « Nouvelle collection » demande un nom.
  async function dropOn(card, chip) {
    if (card.dataset.gone) return;
    let name = chip.dataset.name;
    if (chip.dataset.new) {
      name = await pickCollection();
      if (!name) return snapBack(card);
    }
    if (card.dataset.gone) return;
    card.dataset.gone = '1';
    markChoice(card, 'col', true);
    // arrivée : le centre de la carte, réduite, sur la pastille (l'origine du zoom est le point saisi pendant le glissement)
    const s = card.parentElement.getBoundingClientRect();
    const r = chip.getBoundingClientRect();
    const k = 0.15;
    const ox = Number(card.dataset.ox ?? s.width / 2);
    const oy = Number(card.dataset.oy ?? s.height / 2);
    const tx = r.left + r.width / 2 - s.left - ox - k * (s.width / 2 - ox);
    const ty = r.top + r.height / 2 - s.top - oy - k * (s.height / 2 - oy);
    card.style.transition = 'transform .25s ease-in, opacity .25s';
    card.style.transform = `translate(${tx}px, ${ty}px) scale(${k})`;
    card.style.opacity = '0';
    setTimeout(() => act('col', name), 230);
  }

  async function fly(card, kind) {
    if (card.dataset.gone) return; // déjà partie : deux appuis rapprochés ne trient pas deux vidéos
    if (kind === 'col') {
      const name = await pickCollection();
      if (!name) return snapBack(card);
      return flyOut(card, kind, name);
    }
    if (kind === 'del' && !(await riskGate())) return snapBack(card);
    flyOut(card, kind);
  }

  function flyOut(card, kind, name) {
    if (card.dataset.gone) return;
    card.dataset.gone = '1';
    markChoice(card, kind, true); // bouton ou touche : la carte part avec la couleur de son choix
    const [dx, dy] = dirs()[kind];
    card.style.transition = 'transform .25s ease-in, opacity .25s';
    card.style.transform = `translate(${dx * 700}px, ${dy * 700}px) rotate(${dx * 25}deg)`;
    card.style.opacity = '0';
    setTimeout(() => act(kind, name), 230);
  }

  function snapBack(card) {
    card.style.transition = 'transform .2s';
    card.style.transform = '';
    card.querySelectorAll('.tag').forEach((t) => (t.style.opacity = 0));
    markChoice(card, '', false);
  }
  // Ne touche au style que si le choix change (pas à chaque mouvement du pointeur) : coût négligeable.
  function markChoice(card, choice, sure) {
    const key = choice ? `${choice}${sure ? '!' : ''}` : '';
    if (card.dataset.choice === key) return;
    card.dataset.choice = key;
    card.classList.remove('c-keep', 'c-del', 'c-col', 'c-sure');
    if (choice) card.classList.add(`c-${choice}`);
    if (choice && sure) card.classList.add('c-sure');
  }

  function attachDrag(card, el) {
    let sx, sy, dx, dy, t0, moved, hot;
    const tags = { keep: card.querySelector('.tag.keep'), del: card.querySelector('.tag.del'), col: card.querySelector('.tag.col') };
    // Un dépôt sur une collection n'est pris en compte que si le pointeur y reste un instant (DWELL) : sans cela, un
    // balayage rapide qui se termine par hasard au-dessus du panneau rangerait la vidéo au lieu de la garder.
    const DWELL = 220;
    let hotSince = 0;
    let hotTimer = null;
    const setHot = (chip) => {
      if (chip === hot) return;
      clearTimeout(hotTimer);
      hot?.classList.remove("hot", "ready");
      hot = chip;
      hotSince = Date.now();
      hot?.classList.add("hot");
      hotTimer = setTimeout(() => hot === chip && chip?.classList.add("ready"), DWELL);
    };
    el.addEventListener('pointerdown', (e) => {
      el.setPointerCapture(e.pointerId);
      [sx, sy, dx, dy, t0, moved] = [e.clientX, e.clientY, 0, 0, Date.now(), false];
      // la carte rétrécit autour du point saisi : le curseur reste sur le même endroit de la vidéo
      const st = card.parentElement.getBoundingClientRect();
      card.dataset.ox = e.clientX - st.left;
      card.dataset.oy = e.clientY - st.top;
      card.style.transformOrigin = `${card.dataset.ox}px ${card.dataset.oy}px`;
      card.style.transition = 'none';
    });
    el.addEventListener('pointermove', (e) => {
      if (sx === undefined) return;
      dx = e.clientX - sx;
      dy = e.clientY - sy; // la carte suit aussi vers le bas, pour atteindre les collections du panneau
      if (Math.abs(dx) + Math.abs(dy) > 6) moved = true;
      // plus le pointeur approche du panneau des collections, plus la carte rétrécit : on voit précisément où on dépose
      let k = 1;
      const panel = ov.querySelector('.cols')?.getBoundingClientRect();
      if (panel && moved) {
        const gapX = Math.max(panel.left - e.clientX, 0, e.clientX - panel.right);
        const gapY = Math.max(panel.top - e.clientY, 0, e.clientY - panel.bottom);
        k = 1 - 0.7 * (1 - Math.min(1, Math.hypot(gapX, gapY) / 320)); // 1 loin → 0,3 sur le panneau
      }
      card.style.transform = `translate(${dx}px, ${dy}px) rotate(${dx / 18}deg) scale(${k})`;
      setHot(moved ? chipAt(e.clientX, e.clientY) : null);
      const horiz = Math.abs(dx) > Math.abs(dy);
      const off = hot ? 0 : 1; // au-dessus d'une collection, on n'affiche plus les tags de balayage
      const sw = dx * keepSign();
      tags.keep.style.opacity = horiz && sw > 0 ? off * Math.min(1, sw / 100) : 0;
      tags.del.style.opacity = horiz && sw < 0 ? off * Math.min(1, -sw / 100) : 0;
      tags.col.style.opacity = hot || (!horiz && dy < 0) ? Math.min(1, hot ? 1 : -dy / 100) : 0;
      // bordure de couleur selon le choix en cours (vert garder, rouge retirer, bleu ranger), plus vive une fois le seuil franchi
      const choice = hot ? 'col' : horiz && Math.abs(sw) > 30 ? (sw > 0 ? 'keep' : 'del') : !horiz && dy < -30 ? 'col' : '';
      const sure = !!hot || (horiz ? Math.abs(sw) > 100 : dy < -100);
      markChoice(card, choice, sure);
    });
    el.addEventListener('pointerup', (e) => {
      if (sx === undefined) return;
      sx = undefined;
      const over = moved ? chipAt(e.clientX, e.clientY) : null;
      const chip = over && over === hot && Date.now() - hotSince >= DWELL ? over : null; // pointeur resté assez longtemps
      setHot(null);
      if (!moved) return snapBack(card); // simple appui : rien
      if (chip) return dropOn(card, chip); // déposée sur une collection : prioritaire sur le balayage
      const horiz = Math.abs(dx) > Math.abs(dy);
      const sw = dx * keepSign(); // > 0 : vers le côté « garder »
      if (horiz && sw < -100) fly(card, 'del');
      else if (horiz && sw > 100) fly(card, 'keep');
      else if (!horiz && dy < -100) fly(card, 'col');
      else snapBack(card);
    });
  }

  // ── Pagination : des milliers de vignettes d'un coup ralentissent l'écran ──
  const PAGE = 120;
  const limits = {};
  function paged(list, key) {
    const n = limits[key] || PAGE;
    const more = list.length > n ? `<button class="sec" data-more="${esc(key)}">Afficher plus (${list.length - n} restantes)</button>` : '';
    return { items: list.slice(0, n), more };
  }

  // ── Sélection multiple (onglet Gardés) ──
  let selectMode = false;
  const sel = new Set();

  function gridItem(v, extra = '', inCollection = false, selectable = false) {
    const on = selectable && selectMode;
    const picked = on && sel.has(v.id);
    return `<div class="item ${picked ? 'picked' : ''}" ${bgStyle(v)} ${on ? `data-sel="${v.id}"` : ''}>${descHtml(v)}
      ${on ? `<div class="chk">${picked ? '☑' : '☐'}</div>` : `<a href="${esc(v.url)}" target="_blank" rel="noopener"></a>`}
      ${on ? '' : `<div class="lbl"><span>${extra}</span><span class="acts">
        <button data-back="${v.id}" title="Remettre dans la pile">↩</button>
        ${inCollection ? `<button data-uncol="${v.id}" title="Sortir de la collection (reste dans les favoris)">⊖</button>` : ''}
        <button data-unfav="${v.id}" title="Retirer des favoris TikTok">🗑</button></span></div>`}</div>`;
  }

  // Retire des favoris TikTok une liste de vidéos (même file d'attente que le glissement).
  async function unfavorite(vids) {
    const before = vids.map((v) => ({ id: v.id, status: v.status, collection: v.collection, synced: v.synced, removeFrom: v.removeFrom }));
    for (const v of vids) {
      delete v.removeFrom;
      Object.assign(v, { status: 'deleted', collection: null, synced: false });
      logAct('unfav', v.id);
    }
    const r = await send({ type: 'enqueue', items: vids.map((v) => ({ id: v.id, url: v.url, account: ACCOUNT })) });
    if (r?.rejected?.length) {
      // quota gratuit : on remet exactement l'état d'avant pour les vidéos refusées
      for (const b of before) {
        if (!r.rejected.includes(b.id)) continue;
        const { id, ...prev } = b;
        Object.assign(S.videos[id], prev);
        S.log.shift();
      }
      upsell('limit');
    }
    refreshPlan();
    await save();
  }

  function bindBack(body) {
    body.querySelectorAll('[data-more]').forEach((b) => {
      b.onclick = () => {
        limits[b.dataset.more] = (limits[b.dataset.more] || PAGE) + PAGE;
        renderBody();
      };
    });
    body.querySelectorAll('[data-back]').forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        const v = S.videos[b.dataset.back];
        if (v.synced && v.collection) v.removeFrom = v.collection; // déjà rangée sur TikTok : on l'en retire aussi
        Object.assign(v, { status: 'new', collection: null, synced: false });
        delete v.miss;
        S.order = [v.id, ...S.order.filter((x) => x !== v.id)];
        logAct('back', v.id);
        await save();
        renderBody();
        scheduleSync();
      };
    });
    // sortir de la collection, sans quitter les favoris
    body.querySelectorAll('[data-uncol]').forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        const v = S.videos[b.dataset.uncol];
        if (v.synced && v.collection) v.removeFrom = v.collection;
        logAct('uncol', v.id, v.collection);
        Object.assign(v, { collection: null, synced: false });
        await save();
        renderBody();
        scheduleSync();
      };
    });
    // retirer des favoris TikTok
    body.querySelectorAll('[data-unfav]').forEach((b) => {
      b.onclick = async (e) => {
        e.stopPropagation();
        if (accountChanged()) return;
        if (!(await riskGate())) return;
        await unfavorite([S.videos[b.dataset.unfav]]);
        renderBody();
      };
    });
  }

  function renderKept(body) {
    const list = S.order.map((id) => S.videos[id]).filter((v) => v.status === 'kept' && !v.collection);
    const { items, more } = paged(list, 'kept');
    const bar = list.length
      ? `<div class="selbar">${
          selectMode
            ? `<b>${sel.size} sélectionnée(s)</b>
               <button class="sec" id="sel-all">Tout sélectionner (${list.length})</button>
               <button class="pri" id="sel-col" ${sel.size ? '' : 'disabled'}>📁 Ranger dans…</button>
               <button class="sec danger" id="sel-del" ${sel.size ? '' : 'disabled'}>🗑 Retirer des favoris</button>
               <button class="sec" id="sel-off">Terminer</button>`
            : '<button class="sec" id="sel-on">☑ Sélectionner plusieurs vidéos</button>'
        }</div>`
      : '';
    body.innerHTML = list.length
      ? `<div class="count">${list.length} gardées</div>${bar}<div class="grid">${items.map((v) => gridItem(v, '', false, true)).join('')}</div>${more}`
      : '<div class="empty"><p>Rien de gardé pour l’instant.</p></div>';
    bindBack(body);
    body.querySelector('#sel-on')?.addEventListener('click', () => {
      selectMode = true;
      sel.clear();
      renderBody();
    });
    body.querySelector('#sel-off')?.addEventListener('click', () => {
      selectMode = false;
      sel.clear();
      renderBody();
    });
    body.querySelector('#sel-all')?.addEventListener('click', () => {
      list.forEach((v) => sel.add(v.id));
      renderBody();
    });
    body.querySelectorAll('[data-sel]').forEach((el) => {
      el.onclick = () => {
        const id = el.dataset.sel;
        if (sel.has(id)) sel.delete(id);
        else sel.add(id);
        renderBody();
      };
    });
    body.querySelector('#sel-col')?.addEventListener('click', async () => {
      const name = await pickCollection();
      if (!name) return;
      for (const id of sel) {
        Object.assign(S.videos[id], { status: 'kept', collection: name, synced: false, auto: false });
        logAct('col', id, name);
      }
      touchRecent(name);
      toast(`${sel.size} vidéo(s) rangée(s) dans « ${name} »`);
      sel.clear();
      selectMode = false;
      await save();
      renderBody();
      scheduleSync();
    });
    body.querySelector('#sel-del')?.addEventListener('click', async () => {
      if (accountChanged()) return;
      if (!(await riskGate())) return;
      if (!confirm(`Retirer ${sel.size} vidéo(s) de tes favoris TikTok (automatiquement, en arrière-plan) ?`)) return;
      await unfavorite([...sel].map((id) => S.videos[id]));
      toast(`${sel.size} retrait(s) mis en file`);
      sel.clear();
      selectMode = false;
      renderBody();
    });
  }

  // Renomme une collection qui n'existe pas encore sur TikTok (par ex. quand TikTok refuse son nom).
  async function renameCollection(old) {
    const vids = Object.values(S.videos).filter((v) => v.collection === old);
    if (vids.some((v) => v.synced)) {
      alert('Cette collection existe déjà sur TikTok : renomme-la dans TikTok (⋯ → Changer de nom), puis clique sur « Relire mes collections TikTok ».');
      return;
    }
    const name = prompt(`Nouveau nom pour « ${old} » :`, old)?.trim();
    if (!name || name === old) return;
    if (S.collections.some((c) => c.toLowerCase() === name.toLowerCase())) {
      alert('Une collection porte déjà ce nom.');
      return;
    }
    S.collections = S.collections.map((c) => (c === old ? name : c));
    S.pinned = (S.pinned || []).map((c) => (c === old ? name : c));
    S.recent = (S.recent || []).map((c) => (c === old ? name : c));
    for (const v of vids) v.collection = name;
    delete S.errors?.[old];
    await save();
    renderBody();
    scheduleSync(3000);
  }

  function renderCols(body) {
    // un seul passage sur toutes les vidéos (et non un par collection : 100 collections × 5 000 vidéos, c'était lent)
    const byCol = new Map(S.collections.map((c) => [c, []]));
    for (const id of S.order) {
      const v = S.videos[id];
      if (v.status === 'kept' && v.collection) byCol.get(v.collection)?.push(v);
    }
    const groups = [...byCol].filter(([, l]) => l.length);
    const pending = pendingSync();
    body.innerHTML = groups.length
      ? `<div class="count">${pending ? `${pending} à ranger sur TikTok` : 'Tout est rangé sur TikTok'}</div>
         <button class="pri" id="sync" ${pending && !syncing ? '' : 'disabled'}>${syncing ? 'Synchronisation…' : 'Synchroniser maintenant'}</button>
         <div class="hint">Le rangement part tout seul quelques secondes après chaque glissement. ⊖ sort la vidéo de la collection, 🗑 la retire des favoris.</div>` +
        groups
          .map(([c, l]) => {
            const { items, more } = paged(l, `col:${c}`);
            return `<h3>📁 ${esc(c)} <small>(${l.length})</small> <button class="ren" data-ren="${esc(c)}" title="Renommer">✎</button></h3>${S.errors?.[c] ? `<div class="err">⚠ ${esc(S.errors[c])}</div>` : ''}<div class="grid">${items.map((v) => gridItem(v, v.synced ? '✓ TikTok' : v.miss >= 2 ? '⚠ pas dans tes favoris' : '⏳', true)).join('')}</div>${more}`;
          })
          .join('')
      : '<div class="empty"><p>Aucune collection. Glisse une vidéo vers le haut pour en créer une.</p></div>';
    body.insertAdjacentHTML('afterbegin', '<button class="sec" id="reread">↻ Relire mes collections TikTok</button>');
    body.querySelector('#reread').addEventListener('click', () => refreshCollections());
    body.querySelector('#sync')?.addEventListener('click', () => syncCollections());
    body.querySelectorAll('[data-ren]').forEach((b) => (b.onclick = () => renameCollection(b.dataset.ren)));
    bindBack(body);
  }

  function renderDel(body) {
    const list = S.order.map((id) => S.videos[id]).filter((v) => v.status === 'deleted');
    const label = (id) => {
      const j = J[id];
      if (!j) return '…';
      return ({ pending: '⏳ en attente', running: '⏳ en cours', done: '✓ retiré', unverified: '✓ à vérifier', error: '⚠ échec' })[j.status] || j.status;
    };
    const pend = list.filter((v) => ['pending', 'running'].includes(J[v.id]?.status)).length;
    const { items, more } = paged(list, 'del');
    body.innerHTML = list.length
      ? `<div class="count">${list.length} retirées · ${pend} en attente${pend ? ` (${etaText(pend)})` : ""}</div>${pauseBanner()}
         <div class="grid">${items.map((v) => `<div class="item" ${bgStyle(v)}>${descHtml(v)}<a href="${esc(v.url)}" target="_blank" rel="noopener"></a>
          <div class="lbl"><span title="${esc(J[v.id]?.note || '')}">${label(v.id)}</span>
          ${J[v.id]?.status === 'error' ? `<button data-retry="${v.id}">↻</button>` : ''}</div></div>`).join('')}</div>${more}`
      : '<div class="empty"><p>Aucune vidéo retirée.</p></div>';
    bindBack(body);
    body.querySelectorAll('[data-retry]').forEach((b) => (b.onclick = () => send({ type: 'retry', id: b.dataset.retry })));
  }

  // ── Avertissement : risque de limitation / suspension / bannissement du compte TikTok ──
  // À accepter une fois (case à cocher) avant la première action automatisée : import, synchronisation, retrait.
  const RISK_SHORT = 'Outil non officiel, non affilié à TikTok. TikTok interdit l’automatisation : ton compte peut être limité, suspendu ou banni définitivement.';
  function riskGate() {
    if (SET.riskAccepted) return Promise.resolve(true);
    return new Promise((resolve) => {
      const m = document.createElement('div');
      m.className = 'modal';
      m.innerHTML = `<div class="box"><b>⚠ Avant de continuer</b>
        <p class="warn">Cet outil pilote TikTok à ta place : clics, défilement, ouverture de vidéos en arrière-plan.
          <b>TikTok interdit l’automatisation dans ses conditions d’utilisation.</b> Ton compte peut être <b>limité, suspendu ou banni définitivement</b>,
          même avec des pauses entre les actions. Ce risque existe et personne ne peut le supprimer.</p>
        <p class="warn">Tu utilises l’extension <b>à tes propres risques</b>. Elle n’est pas affiliée à TikTok et son auteur n’est pas responsable des sanctions
          prises contre ton compte. Conseils : petits lots, rythme prudent, teste d’abord sur un compte secondaire.</p>
        <label class="fld chk"><input type="checkbox" id="risk-ok"> Je comprends que mon compte TikTok peut être suspendu ou banni, et j’accepte ce risque.</label>
        <button class="pri" data-a="ok" disabled style="margin:6px 0 0">J’accepte et je continue</button>
        <button class="sec" data-a="no" style="margin:6px 0 0">Annuler</button></div>`;
      const done = (v) => {
        m.remove();
        resolve(v);
      };
      m.addEventListener('change', () => {
        m.querySelector('[data-a="ok"]').disabled = !m.querySelector('#risk-ok').checked;
      });
      m.addEventListener('click', async (e) => {
        const a = e.target.dataset?.a;
        if (e.target === m || a === 'no') return done(false);
        if (a === 'ok' && m.querySelector('#risk-ok').checked) {
          SET.riskAccepted = true;
          await saveSettings();
          done(true);
        }
      });
      root.append(m);
    });
  }

  function riskSection() {
    return `<section><h3>⚠ Avertissement</h3><p style="margin:0">${RISK_SHORT} Utilisation à tes propres risques ; fais des pauses et de petits lots.</p></section>`;
  }

  function donateSection() {
    if (!PLAN.donateUrl) return '';
    return `<section><h3>☕ Soutenir le projet</h3>
      <p>L’extension est faite et entretenue par une seule personne. Si elle te fait gagner du temps, un don, même petit, aide à la garder à jour quand TikTok change.</p>
      <button class="sec" id="donate">☕ Faire un don</button></section>`;
  }

  // ── Version gratuite / Pro (voir config.js et license.js) ──
  let PLAN = { configured: false, pro: true, used: 0, limit: 200, buyUrl: '', price: '5 €', donateUrl: '', email: '', keyTail: '', error: '' };
  async function refreshPlan() {
    try {
      const p = await send({ type: 'license-status' });
      if (p && typeof p.pro === 'boolean') {
        const sig = () => `${!!PLAN.donateUrl}|${PLAN.pro}|${PLAN.configured}`;
        const before = sig();
        PLAN = p;
        if (ov && !ov.hidden && before !== sig()) return render(); // les boutons « Pro » et « don » de l'en-tête suivent l'état de la licence
      }
    } catch {
      /* arrière-plan indisponible : on garde le dernier état connu */
    }
    if (ov && !ov.hidden && tab === 'state') renderBody();
  }
  function upsell(reason) {
    toast(
      reason === 'limit'
        ? `Limite gratuite atteinte : ${PLAN.limit} retraits par jour. Clique sur « ⭐ Passer en Pro » en haut (${PLAN.price}).`
        : `Fonction réservée à la version Pro (${PLAN.price}). Clique sur « ⭐ Passer en Pro » en haut.`,
    );
  }

  function planSection() {
    if (!PLAN.configured) {
      return '<section><h3>⭐ Version</h3><p class="hint" style="text-align:left;max-width:none;margin:0">Mode développement : tout est débloqué (aucune boutique configurée dans config.js).</p></section>';
    }
    if (PLAN.pro) {
      return `<section><h3>⭐ Pro activée</h3><p>Merci ! ${PLAN.email ? `${esc(PLAN.email)} · ` : ''}clé ${esc(PLAN.keyTail)} · retraits illimités et onglets en parallèle.</p>
        <button class="sec" id="lic-off">Désactiver sur cet ordinateur</button> <span id="lic-msg"></span></section>`;
    }
    return `<section><h3>⭐ Version gratuite</h3>
      <p>Retraits aujourd’hui : <b>${PLAN.used} / ${PLAN.limit}</b> · 1 onglet de retrait</p>
      ${PLAN.error ? `<p class="bad">${esc(PLAN.error)}</p>` : ''}
      <button class="pri" id="lic-buy">Passer en Pro : ${esc(PLAN.price)} (achat unique)</button>
      <p class="hint" style="text-align:left;max-width:none">Pro : retraits illimités, jusqu’à 3 onglets en parallèle avec chargement allégé (plus rapide).</p>
      <input class="colsearch" id="lic-key" placeholder="Clé de licence reçue par e-mail" style="max-width:340px" autocomplete="off">
      <button class="sec" id="lic-on">Activer</button> <span id="lic-msg"></span></section>`;
  }

  // Fenêtre « Pro » ouverte d'un clic depuis l'en-tête : avantages, achat, et saisie de la clé de licence au même endroit.
  function proMenu() {
    const m = document.createElement('div');
    m.className = 'modal';
    const paint = () => {
      m.innerHTML = `<div class="box">${
        PLAN.pro || !PLAN.configured
          ? planSection()
          : `<b>⭐ Passer en Pro</b>
      <ul class="perks"><li>Retraits illimités (gratuit : ${PLAN.limit} par jour)</li><li>Jusqu’à 3 onglets en parallèle, plus rapide</li><li>Tu soutiens le développement de l’extension</li></ul>
      <button class="pri" id="lic-buy" style="width:100%;margin:4px 0">Acheter le Pro : ${esc(PLAN.price)} (paiement unique)</button>
      <p class="hint" style="text-align:left;max-width:none">Pas d’abonnement. Remboursement sous 14 jours sur demande.</p>
      <hr>
      <label class="fld">J’ai déjà une clé de licence<input class="colsearch" id="lic-key" placeholder="Colle ici la clé reçue par e-mail" autocomplete="off" style="max-width:none"></label>
      <button class="sec" id="lic-on">Activer</button> <span id="lic-msg"></span>${PLAN.error ? `<p class="bad">${esc(PLAN.error)}</p>` : ''}`
      }
      <button class="sec" data-a="close" style="margin:10px 0 0">Fermer</button></div>`;
      bindPlan(m, paint);
    };
    m.addEventListener('click', (e) => {
      if (e.target === m || e.target.dataset?.a === 'close') m.remove();
    });
    paint();
    root.append(m);
  }

  function bindPlan(body, onDone) {
    const msg = (t, bad) => {
      const el = body.querySelector('#lic-msg');
      if (el) el.innerHTML = `<span class="${bad ? 'bad' : ''}">${esc(t)}</span>`;
    };
    body.querySelector('#donate')?.addEventListener('click', () => window.open(PLAN.donateUrl, '_blank', 'noopener'));
    body.querySelector('#lic-buy')?.addEventListener('click', () => {
      if (PLAN.buyUrl) window.open(PLAN.buyUrl, '_blank', 'noopener');
      else msg('Page d’achat non configurée.', true);
    });
    body.querySelector('#lic-on')?.addEventListener('click', async () => {
      msg('Vérification…');
      const r = await send({ type: 'license-activate', key: body.querySelector('#lic-key').value });
      if (!r?.ok) return msg(r?.error || 'Échec de l’activation.', true);
      await refreshPlan();
      toast('Licence Pro activée. Merci !');
      onDone?.();
    });
    body.querySelector('#lic-off')?.addEventListener('click', async () => {
      if (!confirm('Désactiver la licence sur cet ordinateur ? Tu pourras l’utiliser sur un autre.')) return;
      await send({ type: 'license-deactivate' });
      await refreshPlan();
      onDone?.();
    });
  }

  // ── Onglet Suivi : tout ce qui est en attente, en erreur, et le journal des actions ──
  // Durée estimée des retraits restants : mesure réelle de background.js (moyenne mobile), sinon estimation d'après les réglages.
  const etaText = (n) => {
    const per = QS.perVideoMs || (((SET.pauseMin + SET.pauseMax) / 2 + 6) * 1000) / Math.max(1, SET.workers);
    const min = Math.ceil((n * per) / 60000);
    return min < 1 ? 'moins d’1 min' : `environ ${min} min`;
  };
  const pauseBanner = () =>
    QS.pausedUntil > Date.now()
      ? `<p class="bad">⏸ ${esc(QS.note || 'File en pause.')} Reprise dans ${QS.pausedUntil - Date.now() < 60000 ? `${Math.ceil((QS.pausedUntil - Date.now()) / 1000)} s` : `${Math.ceil((QS.pausedUntil - Date.now()) / 60000)} min`}. <button class="sec" id="st-resume">Reprendre maintenant</button></p>`
      : '';

  // ── Pastille en bas à droite : retraits restants, pause de sécurité (visible sur tous les onglets sauf Suivi) ──
  const pauseLeft = () => {
    const ms = QS.pausedUntil - Date.now();
    return ms < 60000 ? `${Math.max(1, Math.ceil(ms / 1000))} s` : `${Math.ceil(ms / 60000)} min`;
  };
  function queueChipHtml() {
    if (tab === 'state') return '';
    let pend = 0;
    let run = 0;
    let err = 0;
    for (const v of Object.values(S.videos)) {
      if (v.status !== 'deleted') continue;
      const s = J[v.id]?.status;
      if (s === 'pending') pend++;
      else if (s === 'running') run++;
      else if (s === 'error') err++;
    }
    const left = pend + run;
    const paused = QS.pausedUntil > Date.now();
    if (!left && !paused && !err) return '';
    return (
      (left ? `<div><b>🗑 Retraits : ${left} restants</b> · ${etaText(left)}${run ? ` · ${run} en cours` : ''}</div>` : '') +
      (paused ? `<div class="bad">⏸ ${esc(QS.note || 'File en pause.')} Reprise dans ${pauseLeft()}. <button id="q-resume">Reprendre maintenant</button></div>` : '') +
      (err ? `<div class="bad">⚠ ${err} en échec · <button id="q-state">Voir</button></div>` : '')
    );
  }
  function paintQueueChip() {
    if (!ov || ov.hidden) return;
    const html = queueChipHtml();
    let el = ov.querySelector('#qchip');
    if (!html) return el?.remove();
    if (!el) {
      el = document.createElement('div');
      el.id = 'qchip';
      el.className = 'qchip';
      ov.append(el);
    }
    if (el.dataset.h !== html) {
      el.dataset.h = html;
      el.innerHTML = html;
    }
  }
  setInterval(() => {
    if (ov && !ov.hidden && (QS.pausedUntil > Date.now() - 1500 || ov.querySelector('#qchip'))) paintQueueChip();
  }, 1000);

  const problemCount = () =>
    Object.keys(S.errors || {}).length + Object.values(S.videos).filter((v) => v.status === 'deleted' && J[v.id]?.status === 'error').length;

  const LOG_LABELS = {
    keep: '♥ Gardée',
    col: '📁 Rangée',
    del: '🗑 Retirée des favoris',
    unfav: '🗑 Retirée des favoris',
    undo: '↺ Annulée',
    back: '↩ Remise dans la pile',
    uncol: '⊖ Sortie de la collection',
  };

  function renderState(body) {
    const deleted = Object.values(S.videos).filter((v) => v.status === 'deleted');
    const by = { pending: 0, running: 0, done: 0, unverified: 0, error: 0, none: 0 };
    for (const v of deleted) by[J[v.id]?.status || 'none']++;
    const errCols = Object.entries(S.errors || {});
    const fmt = (t) => new Date(t).toLocaleString(typeof TTS_I18N !== 'undefined' ? TTS_I18N.locale() : 'fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    const log = (S.log || [])
      .slice(0, 80)
      .map((l) => {
        const v = S.videos[l.id];
        const link = v ? `<a href="${esc(v.url)}" target="_blank" rel="noopener">vidéo ${esc(l.id.slice(-6))}</a>` : '';
        return `<li><span class="t">${fmt(l.t)}</span> ${LOG_LABELS[l.a] || esc(l.a)} ${link}${l.name ? ` → <i>${esc(l.name)}</i>` : ''}</li>`;
      })
      .join('');
    const limitedBanner = S.limitedAt && Date.now() - S.limitedAt < 3600000 ? `<section><p class="bad">⚠ ${RATE_MSG} <small>(détecté à ${fmt(S.limitedAt)})</small></p></section>` : '';
    body.innerHTML = `<div class="state">${planSection()}${riskSection()}${donateSection()}${limitedBanner}
      <section><h3>🗑 Retraits des favoris TikTok</h3>
        <p>${by.pending} en attente · ${by.running} en cours · ${by.done + by.unverified} faits · <b class="${by.error ? 'bad' : ''}">${by.error} en échec</b></p>
        ${by.pending + by.running ? `<p>⏱ ${etaText(by.pending + by.running)} restantes · ${PLAN.configured && !PLAN.pro ? 1 : SET.workers} onglet(s) en parallèle</p>` : ""}${pauseBanner()}
        <button class="sec" id="st-cancel" ${by.pending ? '' : 'hidden'}>Annuler les ${by.pending} en attente</button>
        <button class="sec" id="st-retry" ${by.error ? '' : 'hidden'}>↻ Réessayer les ${by.error} échecs</button></section>
      <section><h3>📁 Collections</h3>
        <p>${pendingSync()} à envoyer à TikTok${errCols.length ? ` · <b class="bad">${errCols.length} collection(s) en erreur</b>` : ''}</p>
        ${errCols.map(([n, m]) => `<div class="err">⚠ <b>${esc(n)}</b> — ${esc(m)} <button class="ren" data-ren="${esc(n)}" title="Renommer">✎</button></div>`).join('')}
        <button class="sec" id="st-sync" ${syncing ? 'disabled' : ''}>⇄ Synchroniser maintenant</button></section>
      <section><h3>⬇ Import depuis TikTok</h3>
        <p>${S.order.length} vidéos importées${S.importTotal ? ` sur ${S.importTotal} favoris` : ''}${S.lastImport ? ` · dernier import : ${fmt(S.lastImport)}` : ''}</p>
        <button class="sec" id="st-import">↻ Importer les nouveaux favoris (rapide)</button>
        <button class="sec" id="st-import-full">Tout relire (lent)</button>
        <button class="sec" id="st-cols">↻ Relire les collections modifiées</button>
        <button class="sec" id="st-cols-full">Relire toutes les collections (lent)</button></section>
      <section><h3>💾 Sauvegarde</h3>
        <p class="hint" style="margin:0 0 8px;text-align:left;max-width:none">Un fichier avec ton tri, tes collections locales et tes réglages. Rien n'est envoyé nulle part.</p>
        <p class="warn" style="margin:0 0 8px">⚠ Supprimer l’extension, ou la recharger depuis un autre dossier, efface ton tri. Fais une sauvegarde avant, puis « Restaurer une sauvegarde » dans la nouvelle installation.</p>
        <p class="${SET.lastBackup ? 'hint' : 'bad'}" style="margin:0 0 8px;text-align:left;max-width:none">${SET.lastBackup ? `Dernière sauvegarde : ${fmt(SET.lastBackup)}` : 'Aucune sauvegarde pour l’instant.'}</p>
        <button class="sec" id="st-export">⬇ Exporter mes données</button>
        <label class="sec" style="display:inline-block;cursor:pointer">⬆ Restaurer une sauvegarde<input type="file" accept=".json" hidden id="st-restore"></label></section>
      <section><h3>📜 Journal (80 dernières actions)</h3>
        <p class="hint" style="margin:0 0 8px;text-align:left;max-width:none">Un retrait est irréversible : retrouve ici la vidéo et remets-la en favori à la main si besoin.</p>
        ${log ? `<ul class="log">${log}</ul>` : '<p class="hint" style="text-align:left">Rien pour l’instant.</p>'}</section>
      <section><h3>🔧 Diagnostic</h3>
        <p class="hint" style="margin:0 0 8px;text-align:left;max-width:none">Si une synchronisation ne fait rien, clique sur « Copier le rapport » et envoie-le à sortfold@gmail.com : il ne contient ni tes vidéos ni ton pseudo, seulement les étapes et les compteurs.</p>
        <button class="sec" id="st-copy">📋 Copier le rapport</button> <span id="st-copy-msg"></span>
        <details class="adv"><summary>Voir le rapport</summary><pre class="rep" data-nt>${esc(traceReport())}</pre></details></section></div>`;
    const $ = (s) => body.querySelector(s);
    $('#st-copy').onclick = async () => {
      try {
        await navigator.clipboard.writeText(traceReport());
        $('#st-copy-msg').textContent = 'Copié ✓';
      } catch {
        const r = document.createRange();
        r.selectNodeContents($('.rep'));
        getSelection().removeAllRanges();
        getSelection().addRange(r);
        $('#st-copy-msg').textContent = 'Sélectionné : fais Ctrl+C';
      }
    };
    $('#st-cancel').onclick = async () => {
      let n = 0;
      for (const v of deleted.filter((x) => J[x.id]?.status === 'pending')) {
        const r = await send({ type: 'cancel', id: v.id });
        if (!r?.ok) continue;
        v.status = 'new';
        S.order = [v.id, ...S.order.filter((x) => x !== v.id)];
        logAct('undo', v.id);
        n++;
      }
      await save();
      toast(`${n} retrait(s) annulé(s) : les vidéos sont revenues dans la pile`);
      renderBody();
    };
    bindPlan(body);
    body.querySelector('#st-resume')?.addEventListener('click', () => send({ type: 'resume-queue' }));
    $('#st-retry').onclick = () => deleted.filter((x) => J[x.id]?.status === 'error').forEach((v) => send({ type: 'retry', id: v.id }));
    $('#st-sync').onclick = () => syncCollections();
    $('#st-import').onclick = () => scanFavorites();
    $('#st-import-full').onclick = () => scanFavorites({ full: true });
    $('#st-cols').onclick = () => refreshCollections();
    $('#st-cols-full').onclick = () => refreshCollections({ full: true });
    $('#st-export').onclick = exportData;
    $('#st-restore').onchange = (e) => e.target.files[0] && restoreBackup(e.target.files[0]);
    body.querySelectorAll('[data-ren]').forEach((b) => (b.onclick = () => renameCollection(b.dataset.ren)));
  }

  // ── Sauvegarde / restauration ──
  async function exportData() {
    const all = await chrome.storage.local.get(null);
    const data = {};
    for (const [k, v] of Object.entries(all)) if (k.startsWith('state:') || k === 'settings') data[k] = v;
    const blob = new Blob([JSON.stringify({ app: 'tiktok-swipe-favoris', version: 1, exportedAt: new Date().toISOString(), data })], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `tiktok-swipe-sauvegarde-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    SET.lastBackup = Date.now();
    await saveSettings();
    toast(`Sauvegarde exportée (${Object.keys(data).length} élément(s))`);
    if (tab === 'state') renderBody();
  }

  function restoreBackup(file) {
    const reader = new FileReader();
    reader.onload = async () => {
      let obj;
      try {
        obj = JSON.parse(reader.result);
      } catch {
        return toast('Fichier illisible.');
      }
      if (obj?.app !== 'tiktok-swipe-favoris' || !obj.data) return toast('Ce fichier n’est pas une sauvegarde de l’extension.');
      const keys = Object.keys(obj.data).filter((k) => k.startsWith('state:') || k === 'settings');
      if (!keys.length) return toast('Sauvegarde vide.');
      const accounts = keys.filter((k) => k !== 'settings').map((k) => k.slice(6));
      if (!confirm(`Restaurer la sauvegarde ? Elle REMPLACE les données actuelles de : ${accounts.join(', ') || 'réglages'}.`)) return;
      await chrome.storage.local.set(Object.fromEntries(keys.map((k) => [k, obj.data[k]])));
      ACCOUNT = '';
      await loadAccount(); // relit l'état restauré
      SET.lastBackup = Date.now(); // les données viennent d'une sauvegarde : elles sont donc sauvegardées
      await saveSettings();
      render();
      toast('Sauvegarde restaurée.');
    };
    reader.readAsText(file);
  }

  // ── Réglages ──
  function settingsMenu() {
    const m = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = `<div class="box"><b>⚙ Réglages</b>
      <label class="fld">Langue de l’interface<select id="s-lang"><option value="auto" ${SET.lang === 'auto' ? 'selected' : ''}>Automatique (langue de TikTok)</option>${langOptions()}</select></label>
      <label class="fld chk"><input type="checkbox" id="s-swap" ${SET.swap ? 'checked' : ''}> Inverser les gestes (droite = garder, gauche = retirer)</label>
      <label class="fld">Délai pour annuler un retrait (secondes)<input type="number" id="s-grace" min="3" max="120" value="${SET.grace}"></label>
      <label class="fld chk beta"><input type="checkbox" id="s-auto" ${SET.autoSort ? 'checked' : ''}> <span>🧪 Rangement automatique <b class="tagbeta">bêta</b><small>Propose une collection pour chaque vidéo d’après sa description et ses hashtags, en s’inspirant de tes collections. Fonction en phase de test : vérifie les propositions avant de valider.</small></span></label>
      <details class="adv"><summary>Avancé (vitesse et pauses)</summary>
      <label class="fld">Onglets de retrait en parallèle (1 à 3)${PLAN.pro ? "" : " — Pro"}<input type="number" id="s-workers" min="1" max="3" value="${SET.workers}" ${PLAN.pro ? "" : "disabled"}></label>
      <label class="fld">Envoyer les rangements aux collections après (secondes d’inactivité)<input type="number" id="s-sync" min="3" max="600" value="${SET.syncDelay}"></label>
      <label class="fld chk"><input type="checkbox" id="s-block" ${SET.blockMedia ? "checked" : ""} ${PLAN.pro ? "" : "disabled"}> Retraits plus rapides : ne pas charger images et vidéos dans les onglets de retrait${PLAN.pro ? "" : " — Pro"}</label>
      <label class="fld">Pause entre deux retraits : min (s)<input type="number" id="s-pmin" min="2" max="120" value="${SET.pauseMin}"></label>
      <label class="fld">Pause entre deux retraits : max (s)<input type="number" id="s-pmax" min="2" max="180" value="${SET.pauseMax}"></label>
      <label class="fld">Pause de sécurité quand TikTok semble bloquer (secondes)${PLAN.pro ? "" : " — Pro"}<input type="number" id="s-safety" min="5" max="1800" value="${PLAN.pro ? SET.safetyPause : 300}" ${PLAN.pro ? "" : "disabled"}></label>
      <p class="hint" style="max-width:none;text-align:left">Plus d’onglets et des pauses courtes = retraits plus rapides, mais plus de risque que TikTok te ralentisse ou te bloque. L’extension se met en pause d’elle-même (5 minutes en version gratuite, réglable en Pro) si TikTok refuse plusieurs retraits de suite. Une pause trop courte augmente le risque de limitation du compte.</p>
      </details>
      <button class="pri" data-a="save" style="margin:6px 0 0">Enregistrer</button>
      <button class="sec" data-a="close" style="margin:6px 0 0">Annuler</button></div>`;
    m.addEventListener('click', async (e) => {
      const t = e.target;
      if (t === m || t.dataset.a === 'close') return m.remove();
      if (t.dataset.a !== 'save') return;
      const num = (id, min, max, def) => Math.min(max, Math.max(min, Number(m.querySelector(id).value) || def));
      const pmin = num('#s-pmin', 2, 120, 6);
      SET = {
        ...SET, // conserve aussi riskAccepted
        grace: num('#s-grace', 3, 120, 15),
        workers: num('#s-workers', 1, 3, 3),
        syncDelay: num('#s-sync', 3, 600, 20),
        blockMedia: m.querySelector('#s-block').checked,
        pauseMin: pmin,
        pauseMax: Math.max(pmin, num('#s-pmax', 2, 180, 12)),
        safetyPause: PLAN.pro ? num('#s-safety', 5, 1800, 20) : SET.safetyPause,
        swap: m.querySelector('#s-swap').checked,
        autoSort: m.querySelector('#s-auto').checked,
        lang: m.querySelector('#s-lang').value,
      };
      await saveSettings();
      if (typeof TTS_I18N !== 'undefined') TTS_I18N.set(SET.lang);
      send({ type: 'reset-block' });
      m.remove();
      render();
      toast('Réglages enregistrés.');
    });
    root.append(m);
  }
  // ── Init ──
  // Compte réellement connecté : le lien du profil (mis à jour par l'appli) prime sur les données de la page
  // (figées au chargement), qui ne servent que de secours.
  const ssrHandle = () => {
    try {
      const d = JSON.parse(document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__').textContent);
      const u = d.__DEFAULT_SCOPE__['webapp.app-context'].user?.uniqueId;
      return u ? `@${u}` : '';
    } catch {
      return '';
    }
  };
  const liveHandle = () => currentHandle() || ssrHandle();

  // Recharge les données si le compte a changé depuis la dernière lecture (changement de compte sans rechargement).
  // Un seul chargement à la fois : sans cela, ouvrir le panneau juste après l'arrivée sur la page (pendant le
  // chargement lancé au démarrage) l'affichait AVANT que les données soient lues → écran « Importe tes favoris » vide,
  // comme si rien n'avait jamais été fait (signalé par l'utilisateur ; fermer puis rouvrir le corrigeait).
  let loadingAccount = null;
  function loadAccount() {
    loadingAccount ||= doLoadAccount().finally(() => (loadingAccount = null));
    return loadingAccount;
  }
  async function doLoadAccount() {
    const { settings, activeAccount } = await chrome.storage.local.get(['settings', 'activeAccount']);
    SET = { ...DEFAULT_SET, ...(settings || {}) };
    if (typeof TTS_I18N !== 'undefined') TTS_I18N.set(SET.lang);
    // Le lien « Profil » de TikTok peut tarder à s'afficher : à défaut, le compte de la page, puis le dernier compte
    // connu, plutôt qu'un compte vide (« @guest ») qui faisait croire que tout était perdu.
    // compte déjà connu (chargement précédent) : pas d'attente à chaque ouverture du panneau
    const handle = currentHandle() || (ACCOUNT && ACCOUNT !== '@guest' ? ACCOUNT : (await waitFor(currentHandle, 4000)) || ssrHandle() || activeAccount || '@guest');
    if (handle === ACCOUNT) return;
    if (dirty || saving) await flushSave(); // une écriture en attente appartient à l'ancien compte : on la termine avant de changer
    const key = `state:${handle}`;
    const st = await chrome.storage.local.get([key, 'state', 'jobs', 'queueState']);
    // compte et données changent ENSEMBLE (aucun moment où le compte est nouveau mais les données encore anciennes)
    ACCOUNT = handle;
    S = st[key] || { videos: {}, order: [], collections: [], confirmed: false };
    normalizeState();
    QS = st.queueState || {};
    J = st.jobs || {};
    hist = [];
    const old = st.state;
    legacyState = !st[key] && old && Object.keys(old.videos || {}).length ? old : null;
    send({ type: 'account', account: ACCOUNT });
    armAutoResume(); // reprise d'import programmée avant un rechargement de la page
    await refreshPlan();
  }
  // Le compte affiché par TikTok apparaît ou change après l'ouverture du panneau : on recharge et on redessine.
  let accountWatch = null;
  function watchAccount() {
    clearInterval(accountWatch);
    accountWatch = setInterval(async () => {
      if (ov.hidden || scanning || syncing) return;
      const h = currentHandle();
      if (!h || h === ACCOUNT) return;
      await loadAccount();
      render();
    }, 1500);
  }

  // Champs ajoutés au fil des versions : un ancien état enregistré doit rester utilisable.
  function normalizeState() {
    if (!S.filedIds) {
      // état d'une version plus ancienne : les collections n'avaient pas mémorisé leurs vidéos, on les relit une fois en entier
      S.filedIds = {};
      S.colCounts = {};
    }
    S.errors ||= {};
    S.log ||= [];
    S.pinned ||= [];
    S.recent ||= [];
    S.colCounts ||= {};
    S.colInfo ||= {};
  }

  // Refuse d'agir si le compte a changé sous nos pieds : on ne touche jamais aux favoris d'un autre compte.
  function accountChanged() {
    const h = liveHandle();
    if (h && h !== ACCOUNT) {
      toast(`Le compte a changé (${h}). Ferme puis rouvre l’extension.`);
      return true;
    }
    return false;
  }

  async function open() {
    await (ready = loadAccount());
    if (legacyState && confirm(`Des favoris triés avant la séparation par compte ont été trouvés. Les reprendre pour ${ACCOUNT} ?`)) {
      S = legacyState;
      normalizeState();
      legacyState = null;
      await save();
      await chrome.storage.local.remove('state'); // un seul compte peut les reprendre
    }
    ov.hidden = false;
    // Les vidéos de TikTok continuent de tourner sous le panneau (lecture automatique du flux) : elles prennent du
    // processeur et du réseau pour rien. On les met en pause tant que le panneau est ouvert.
    hushPage();
    clearInterval(hushTimer);
    hushTimer = setInterval(hushPage, 2000);
    watchAccount();
    render();
    armAutoResume(); // une reprise d'import en attente a lieu panneau ouvert
    // juste après une mise à jour automatique : on le dit (une fois)
    chrome.storage.local.get('selfUpdate').then(({ selfUpdate }) => {
      if (!selfUpdate || Date.now() - selfUpdate.at > 10 * 60e3) return;
      chrome.storage.local.remove('selfUpdate');
      toast(`Extension mise à jour (version ${selfUpdate.to}).`);
    }).catch(() => {});
    if (!SET.onboarded) {
      // l'écran d'accueil sert aux nouveaux venus ; quelqu'un qui a déjà des vidéos (mise à jour) ne le voit pas
      if (!S.order.length) return onboarding();
      SET.onboarded = true;
      saveSettings();
    }
    // Rappel discret (au plus tous les 3 jours) : beaucoup de tri accumulé et aucune sauvegarde récente
    const sorted = Object.values(S.videos).filter((v) => v.status !== 'new').length;
    const old = !SET.lastBackup || Date.now() - SET.lastBackup > 14 * 864e5;
    if (sorted >= 100 && old && Date.now() - (SET.backupNudge || 0) > 3 * 864e5) {
      SET.backupNudge = Date.now();
      saveSettings();
      toast(`💾 Tu as trié ${sorted} vidéos et tu n’as pas de sauvegarde récente : onglet Suivi → « Exporter mes données ».`);
    }
  }
  // ── Langue de l'interface ──
  // Les noms de langue s'écrivent dans leur propre langue : ils ne sont pas traduits (data-nt).
  const LANGS = () => (typeof TTS_I18N !== 'undefined' ? TTS_I18N.langs : [{ code: 'fr', name: 'Français' }]);
  const langOptions = () => LANGS().map((l) => `<option value="${l.code}" data-nt ${SET.lang === l.code ? 'selected' : ''}>${l.name}</option>`).join('');
  function setLang(code) {
    SET.lang = code;
    saveSettings();
    TTS_I18N.set(code);
    render();
  }
  function langMenu() {
    const m = document.createElement('div');
    m.className = 'modal';
    const cur = TTS_I18N.lang;
    m.innerHTML = `<div class="box"><b>Langue</b><div style="height:10px"></div>
      ${LANGS().map((l) => `<button class="opt" data-setlang="${l.code}" data-nt>${l.code === cur ? '✓ ' : ''}${l.name}</button>`).join('')}
      <button class="opt" data-setlang="auto">${SET.lang === 'auto' ? '✓ ' : ''}Automatique (langue de TikTok)</button>
      <button class="sec" style="margin:6px 0 0">Fermer</button></div>`;
    m.addEventListener('click', (e) => {
      const t = e.target.closest('button') || e.target;
      if (t === m || t.classList.contains('sec')) return m.remove();
      if (t.dataset.setlang) {
        m.remove();
        setLang(t.dataset.setlang);
      }
    });
    root.append(m);
  }

  // ── Premier lancement : 3 écrans courts (une seule fois) ──
  function onboarding() {
    const keep = SET.swap ? '→' : '←';
    const del = SET.swap ? '←' : '→';
    const steps = [
      ['📥', 'Importe tes favoris', 'Un clic sur « Importer depuis mon profil TikTok » : l’extension lit tes favoris et tes collections. Tu peux commencer à trier dès les premières vidéos, pendant que la suite se charge.'],
      ['👆', 'Un geste par vidéo', `<div class="ob-keys"><div><kbd>${keep}</kbd> garder</div><div><kbd>${del}</kbd> retirer des favoris</div><div><kbd>↑</kbd> ranger dans une collection</div></div>Glisse la carte avec la souris ou utilise les flèches du clavier. Touches 1 à 9 : collection numérotée du panneau · Z : annuler.`],
      ['✨', 'Tout part tout seul', 'Les retraits partent en arrière-plan après un délai pendant lequel tu peux annuler, et les rangements sont envoyés à TikTok automatiquement. Tout reste dans ton navigateur : aucun compte, aucune donnée envoyée.'],
    ];
    let i = 0;
    const m = document.createElement('div');
    m.className = 'modal';
    const paint = () => {
      const [ico, title, text] = steps[i];
      m.innerHTML = `<div class="box ob"><div class="ob-ico">${ico}</div><b>${title}</b><p class="hint" style="max-width:none;text-align:left">${text}</p>
        <div class="ob-dots">${steps.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('')}</div>
        <div class="ob-nav"><button class="ren" data-ob="skip">Passer</button><button class="pri" data-ob="next">${i < steps.length - 1 ? 'Suivant' : 'C’est parti'}</button></div></div>`;
    };
    const done = () => {
      m.remove();
      SET.onboarded = true;
      saveSettings();
    };
    m.addEventListener('click', (e) => {
      const a = e.target.closest('[data-ob]')?.dataset.ob;
      if (a === 'skip') return done();
      if (a === 'next') {
        if (i >= steps.length - 1) return done();
        i++;
        paint();
      }
    });
    paint();
    root.append(m);
  }

  // ── Nouvelle version installée (installation manuelle qui se recharge seule, voir background.js) ──
  // Après le rechargement de l'extension, ce script n'est plus relié à elle (chrome.runtime.id disparaît) : on recharge
  // la page pour prendre la nouvelle version — tout de suite si le panneau est ouvert et inoccupé (il se rouvre seul),
  // sinon le bouton « Trier mes favoris » propose de le faire.
  function watchUpdate() {
    if (!chrome.runtime?.id) return; // (banc d'essai)
    const t = setInterval(() => {
      if (chrome.runtime?.id) return;
      const reloadNow = () => {
        clearInterval(t);
        history.replaceState(history.state, '', location.pathname + location.search + '#tts-open');
        location.reload();
      };
      if (!ov.hidden && !scanning && !syncing) return reloadNow();
      const fab = root.querySelector('.fab');
      if (fab && !fab.dataset.update) {
        fab.dataset.update = '1';
        fab.textContent = '↻ Mise à jour prête';
        fab.onclick = reloadNow;
      }
    }, 3000);
  }

  let hushTimer = null;
  const hushPage = () => {
    for (const v of document.querySelectorAll('video')) if (!v.paused) v.pause();
  };
  function close() {
    ov.hidden = true;
    clearInterval(hushTimer);
    clearInterval(accountWatch);
  }

  async function initUI() {
    ready = loadAccount();

    host = document.createElement('div');
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style><button class="fab">⇄ Trier mes favoris</button><div class="ov" hidden></div>`;
    document.documentElement.append(host);
    ov = root.querySelector('.ov');
    // Fenêtres (modales) : annoncées comme boîtes de dialogue aux lecteurs d'écran, et le focus clavier va au premier bouton.
    new MutationObserver((muts) => {
      for (const m of muts)
        for (const n of m.addedNodes) {
          if (!n.classList?.contains('modal')) continue;
          n.setAttribute('role', 'dialog');
          n.setAttribute('aria-modal', 'true');
          setTimeout(() => n.querySelector('input:not([type="file"]), button.pri, button.opt, button')?.focus({ preventScroll: true }), 0);
        }
    }).observe(root, { childList: true });
    if (typeof TTS_I18N !== 'undefined') {
      TTS_I18N.attach(root);
      // langue de TikTok mémorisée : la fenêtre de l'icône (hors de TikTok) s'affiche dans la même langue
      const remember = (code) => {
        const b = ov?.querySelector('#lang-btn');
        if (b) b.textContent = `🌐 ${code.toUpperCase()}`;
        if (!SET.lang || SET.lang === 'auto') chrome.storage.local.set({ tiktokLang: code }).catch?.(() => {});
      };
      TTS_I18N.onChange(remember);
      ready.then(() => remember(TTS_I18N.lang));
    }

    root.querySelector('.fab').onclick = open;
    watchUpdate();
    ov.addEventListener('click', (e) => {
      const t = e.target.closest?.('button, [data-tab]') || e.target; // clic sur l'icône ou le texte à l'intérieur d'un bouton
      if (t.classList.contains('x')) close();
      if (t.classList.contains("acct-btn")) accountMenu();
      if (t.id === 'pro-btn') proMenu();
      if (t.id === 'suggest') acceptSuggestion();
      if (t.id === 'settings-btn') settingsMenu();
      if (t.id === 'donate-btn' && PLAN.donateUrl) window.open(PLAN.donateUrl, '_blank', 'noopener');
      if (t.id === 'q-resume') send({ type: 'resume-queue' });
      if (t.id === 'q-state') {
        tab = 'state';
        render();
      }
      if (t.closest?.('#lang-btn')) langMenu();
      if (t.id === "stop") {
        cancelOp = true;
        clearTimeout(syncTimer);
        autoHeld = true;
        toast("Arrêt en cours…");
      }
      if (t.dataset.tab) {
        tab = t.dataset.tab;
        render();
      }
    });
    document.addEventListener(
      'keydown',
      (e) => {
        const modal = root.querySelector('.modal');
        if (modal && e.key === 'Escape') {
          // Échap ferme la fenêtre ouverte comme son bouton « Annuler / Fermer / Passer » (les actions en attente sont bien annulées)
          const cancel = [...modal.querySelectorAll('button')].reverse().find((b) => b.matches('.sec, [data-ob="skip"], [data-a="no"], [data-a="close"]'));
          if (cancel) cancel.click();
          else modal.remove();
          e.stopPropagation();
          return;
        }
        if (ov.hidden || modal) return;
        const target = e.composedPath()[0];
        const typing = ['INPUT', 'TEXTAREA'].includes(target?.tagName);
        if (e.key === 'Escape') {
          if (typing) target.blur();
          else close();
          return;
        }
        if (tab !== 'deck' || typing) return;
        const card = topCard();
        const keepLeft = keepSign() < 0;
        const map = { ArrowLeft: keepLeft ? 'keep' : 'del', ArrowRight: keepLeft ? 'del' : 'keep', ArrowUp: 'col' };
        if (map[e.key] && card) {
          e.preventDefault();
          e.stopPropagation();
          fly(card, map[e.key]);
        } else if (/^[1-9]$/.test(e.key) && card) {
          // touches 1 à 9 : ranger dans la collection numérotée du panneau
          const chip = ov.querySelectorAll('.chips .chip')[Number(e.key) - 1];
          if (chip) {
            e.preventDefault();
            e.stopPropagation();
            dropOn(card, chip);
          }
        } else if (e.key === 'Enter' && deckSuggestion && card) {
          // Entrée : accepter la collection proposée (rangement automatique)
          e.preventDefault();
          e.stopPropagation();
          acceptSuggestion();
        } else if (e.key === ' ' && card) {
          // Espace : lire la vidéo de la carte (comme ▶)
          e.preventDefault();
          e.stopPropagation();
          playCard(card);
        } else if (e.key.toLowerCase() === 'z') undo();
      },
      true,
    );
    let laterTimer = null;
    chrome.storage.onChanged.addListener((ch) => {
      if (ch.license || ch.usage) refreshPlan();
      // La file de retraits écrit son état à chaque vidéo : on redessine au plus une fois par seconde.
      const later = (tabs) => {
        if (ov.hidden || !tabs.includes(tab) || laterTimer) return;
        laterTimer = setTimeout(() => {
          laterTimer = null;
          if (!ov.hidden && tabs.includes(tab)) renderBody();
        }, 1000);
      };
      if (ch.queueState) {
        QS = ch.queueState.newValue || {};
        paintQueueChip();
        later(['state']);
      }
      if (ch.jobs) {
        J = ch.jobs.newValue || {};
        paintQueueChip();
        later(['del', 'state']);
      }
    });

    // fenêtre de l'icône de l'extension : « Trier mes favoris » ouvre le panneau dans cet onglet
    chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
      if (msg?.type !== 'open-panel') return;
      if (ov.hidden) open();
      respond({ ok: true });
    });
    if (location.hash === '#tts-open') {
      history.replaceState(history.state, '', location.pathname + location.search);
      open();
    }

    // reprise d'une action interrompue par un rechargement de la page (voir openMyFavorites)
    const resume = sessionStorage.getItem('tts-resume');
    if (resume) {
      sessionStorage.removeItem('tts-resume');
      await open();
      if (resume === 'scan') scanFavorites();
      else if (resume === 'collections') refreshCollections(); // ne relance PAS toute la lecture des favoris
      else if (resume === 'sync') {
        tab = 'cols';
        render();
        syncCollections();
      } else if (resume === 'sync-auto') syncCollections({ auto: true }); // on reste sur l'écran de tri
    }
  }

  (async () => {
    const who = await send({ type: 'whoami' });
    if (who?.job) runJob(who.job, who.account);
    else initUI();
  })();
})();
