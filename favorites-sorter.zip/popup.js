// Fenêtre de l'icône de l'extension : où en est le tri, et un bouton qui ouvre le panneau sur TikTok.
(async () => {
  const $ = (id) => document.getElementById(id);
  const { settings = {}, activeAccount = '', jobs = {}, tiktokLang = '' } = await chrome.storage.local.get(['settings', 'activeAccount', 'jobs', 'tiktokLang']);
  // « automatique » = langue de TikTok (mémorisée par le panneau), sinon celle du navigateur
  TTS_I18N.set(settings.lang && settings.lang !== 'auto' ? settings.lang : tiktokLang || 'auto');
  TTS_I18N.attach(document.body);
  const fmt = (n) => n.toLocaleString(TTS_I18N.locale());

  $('go').onclick = async () => {
    const win = await chrome.windows.getCurrent().catch(() => null);
    await chrome.runtime.sendMessage({ type: 'open-panel', windowId: win?.id });
    window.close();
  };

  if (activeAccount) {
    const key = `state:${activeAccount}`;
    const S = (await chrome.storage.local.get(key))[key];
    $('acct').textContent = activeAccount;
    const vids = Object.values(S?.videos || {});
    if (vids.length) {
      let left = 0;
      let del = 0;
      let col = 0;
      for (const v of vids) {
        if (v.status === 'new') left++;
        else if (v.status === 'deleted') del++;
        else if (v.collection) col++;
      }
      $('stats').hidden = false;
      $('n-left').textContent = fmt(left);
      $('n-del').textContent = fmt(del);
      $('n-col').textContent = fmt(col);
      $('bar').style.width = `${((vids.length - left) / vids.length) * 100}%`;
      const pending = Object.values(jobs).filter((j) => j.status === 'pending' || j.status === 'running').length;
      $('note').textContent = left
        ? pending
          ? `${fmt(pending)} retraits en cours en arrière-plan.`
          : 'Reprends là où tu t’étais arrêté.'
        : 'Tout est trié 🎉 Réimporte de temps en temps pour les nouveaux favoris.';
    } else $('note').textContent = 'Ouvre le panneau puis clique sur « Importer depuis mon profil TikTok ».';
  } else $('note').textContent = 'Ouvre TikTok et connecte-toi, puis importe tes favoris en un clic.';

  const plan = await chrome.runtime.sendMessage({ type: 'license-status' }).catch(() => null);
  if (plan?.configured) {
    $('plan').hidden = false;
    if (plan.pro) $('plan-text').innerHTML = '<span class="pro">⭐ Pro</span> · retraits illimités';
    else {
      $('plan-text').textContent = `Gratuit : ${plan.used} / ${plan.limit} retraits aujourd’hui`;
      if (plan.buyUrl) {
        $('buy').hidden = false;
        $('buy').onclick = () => chrome.tabs.create({ url: plan.buyUrl });
      }
    }
  }
  if (plan?.donateUrl) {
    $('donate').hidden = false;
    $('donate').onclick = (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: plan.donateUrl });
    };
  }
  if (plan?.reviewUrl) {
    $('review').hidden = false;
    $('review').onclick = (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: plan.reviewUrl });
    };
  }
})();
