// File d'attente des retraits de favoris.
// Chaque job ouvre la vidéo dans un onglet en arrière-plan ; le content script de cet onglet clique sur le bouton
// « favori » puis renvoie le résultat. Plusieurs onglets peuvent travailler en parallèle (réglage « workers »), avec
// un ralentissement automatique si TikTok se met à refuser (erreurs d'affilée) : on gagne du temps tant que ça passe,
// et on lève le pied dès que ça coince, pour ne pas risquer un blocage du compte.

// Configuration de la vente et licence Pro (voir config.js, license.js). En test, les scripts sont déjà chargés.
if (typeof importScripts === 'function' && typeof PRO_CONFIG === 'undefined') importScripts('config.js', 'license.js');

// Réglages (modifiables dans l'extension).
const DEFAULTS = { grace: 15, pauseMin: 2, pauseMax: 5, workers: 3, blockMedia: true };
async function settings() {
  const { settings: s } = await chrome.storage.local.get('settings');
  const st = { ...DEFAULTS, ...(s || {}) };
  st.workers = Math.min(3, Math.max(1, Number(st.workers) || DEFAULTS.workers));
  // version gratuite : 1 onglet, sans blocage des images (les modes rapides sont réservés à Pro)
  if (!(await isPro())) {
    st.workers = 1;
    st.blockMedia = false;
  }
  return st;
}
const JOB_TIMEOUT_MS = 40000;
const MAX_TRIES = 2;
const STREAK_LIMIT = 4; // erreurs d'affilée avant la pause de sécurité
const SAFETY_PAUSE_MS = 5 * 60 * 1000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rand = ([a, b]) => a + Math.random() * (b - a);
const waiters = {};

// Toutes les écritures de « jobs » passent par ici (une à la fois) pour ne jamais s'écraser.
let lock = Promise.resolve();
function mutate(fn) {
  lock = lock.then(async () => {
    const { jobs = {} } = await chrome.storage.local.get('jobs');
    const out = await fn(jobs);
    await chrome.storage.local.set({ jobs });
    return out;
  });
  return lock;
}

// Onglet de travail → job qu'il doit exécuter (survit à un redémarrage du service worker).
let tabLock = Promise.resolve();
function withTabJobs(fn) {
  tabLock = tabLock.then(async () => {
    const { tabJobs = {} } = await chrome.storage.session.get('tabJobs');
    const out = fn(tabJobs);
    await chrome.storage.session.set({ tabJobs });
    return out;
  });
  return tabLock;
}

// ── état de la file (lu par l'interface : durée estimée, pause de sécurité)
const queue = { failStreak: 0, pausedUntil: 0, note: "", perVideoMs: 0, lastDone: 0, blockFails: 0, blockOff: false };
async function saveQueue() {
  await chrome.storage.local.set({ queueState: { pausedUntil: queue.pausedUntil, note: queue.note, perVideoMs: queue.perVideoMs, blockOff: queue.blockOff } });
}
function recordDone(ok, benign) {
  const now = Date.now();
  if (queue.lastDone && now - queue.lastDone < 5 * 60 * 1000) {
    const gap = now - queue.lastDone;
    queue.perVideoMs = queue.perVideoMs ? Math.round(queue.perVideoMs * 0.8 + gap * 0.2) : gap;
  }
  queue.lastDone = now;
  if (ok) queue.failStreak = 0;
  else if (!benign) queue.failStreak++;
  if (queue.failStreak >= STREAK_LIMIT) {
    queue.pausedUntil = now + SAFETY_PAUSE_MS;
    queue.note = 'TikTok semble limiter les retraits : pause de 5 minutes.';
    queue.failStreak = 0;
  }
  return saveQueue();
}

// Un onglet de retrait n'a besoin que du bouton favori : on lui interdit de télécharger images et vidéos, ce qui accélère
// nettement le chargement de la page. Garde-fous : seule la 1re tentative est allégée (la 2e charge tout, comme avant),
// et après 3 échecs « bouton introuvable » d'affilée avec blocage, on le désactive pour de bon (sans doute incompatible).
const BLOCK_FAIL_LIMIT = 3;
const setBlock = (tabId, on) =>
  chrome.declarativeNetRequest
    .updateSessionRules(
      on
        ? { addRules: [{ id: tabId, priority: 1, action: { type: 'block' }, condition: { tabIds: [tabId], resourceTypes: ['media', 'image'] } }] }
        : { removeRuleIds: [tabId] },
    )
    .catch(() => {});

async function runJob(job) {
  const st = await settings();
  const block = !!st.blockMedia && !queue.blockOff && job.tries === 0;
  // l'onglet démarre vide pour que la règle de blocage soit en place AVANT le premier téléchargement
  const tab = await chrome.tabs.create({ url: 'about:blank', active: false });
  await withTabJobs((t) => {
    t[tab.id] = { id: job.id, kind: job.kind, collection: job.collection, account: job.account };
  });
  if (block) await setBlock(tab.id, true);
  await chrome.tabs.update(tab.id, { url: job.url });

  const result = await Promise.race([
    new Promise((resolve) => (waiters[job.id] = resolve)),
    sleep(JOB_TIMEOUT_MS).then(() => ({ status: 'error', note: 'Délai dépassé' })),
  ]);
  delete waiters[job.id];
  await withTabJobs((t) => {
    delete t[tab.id];
  });
  if (block) await setBlock(tab.id, false);
  chrome.tabs.remove(tab.id).catch(() => {});

  if (block) {
    const ok = result.status === 'done' || result.status === 'unverified';
    const blockCaused = result.status === 'error' && /Bouton favori introuvable|Délai dépassé|illisible/.test(result.note || '');
    if (ok) queue.blockFails = 0;
    else if (blockCaused && ++queue.blockFails >= BLOCK_FAIL_LIMIT) {
      queue.blockOff = true;
      queue.note = 'Chargement complet rétabli dans les onglets de retrait (le blocage des images/vidéos ne convenait pas).';
    }
  }

  await mutate((j) => {
    const cur = j[job.id];
    if (!cur) return;
    cur.note = result.note || '';
    if (result.status === 'error' && cur.tries + 1 < MAX_TRIES) {
      cur.status = 'pending';
      cur.tries += 1;
      cur.notBefore = Date.now() + 30000;
    } else {
      cur.status = result.status; // done | unverified | error
    }
  });
  return result;
}

// Prend (de façon atomique) le prochain job à faire pour le compte actuellement ouvert dans TikTok.
async function claim() {
  const { activeAccount = '' } = await chrome.storage.local.get('activeAccount');
  return mutate((j) => {
    const due = Object.values(j)
      .filter((x) => x.status === 'pending' && x.notBefore <= Date.now() && (!x.account || x.account === activeAccount))
      .sort((a, b) => a.notBefore - b.notBefore)[0];
    if (!due) return null;
    due.status = 'running';
    due.startedAt = Date.now();
    return { ...due };
  });
}

async function anyPending() {
  const { jobs = {}, activeAccount = '' } = await chrome.storage.local.get(['jobs', 'activeAccount']);
  return Object.values(jobs).some((x) => x.status === 'pending' && (!x.account || x.account === activeAccount));
}

async function workerLoop(index) {
  await sleep(index * 1500); // les onglets ne partent pas tous ensemble
  for (;;) {
    if (queue.pausedUntil > Date.now()) {
      await sleep(Math.min(5000, queue.pausedUntil - Date.now()));
      continue;
    }
    if (queue.pausedUntil) {
      queue.pausedUntil = 0;
      queue.note = '';
      await saveQueue();
    }
    const job = await claim();
    if (!job) {
      if (!(await anyPending())) return;
      await sleep(1500);
      continue;
    }
    const res = await runJob(job);
    const ok = res.status === 'done' || res.status === 'unverified';
    await recordDone(ok, /^Ce retrait appartient/.test(res.note || ''));
    // pause entre deux retraits : allongée automatiquement quand ça coince
    const st = await settings();
    const factor = 1 + Math.min(4, queue.failStreak);
    await sleep(rand([st.pauseMin * 1000, Math.max(st.pauseMin, st.pauseMax) * 1000]) * factor);
  }
}

let active = 0;
async function pump() {
  await mutate((j) => {
    for (const x of Object.values(j)) {
      if (x.status === 'running' && Date.now() - x.startedAt > 90000) x.status = 'pending'; // reste d'un arrêt brutal
    }
  });
  const { workers } = await settings();
  while (active < workers) {
    const index = active++;
    workerLoop(index).finally(() => active--);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  (async () => {
    switch (msg.type) {
      case 'enqueue': {
        const grace = (await settings()).grace * 1000;
        const { jobs: jobsNow = {} } = await chrome.storage.local.get('jobs');
        // seules les vidéos réellement NOUVELLES dans la file comptent dans le quota (redemander une vidéo déjà en file ne coûte rien)
        let fresh = msg.items.filter((it) => !(jobsNow[it.id] && jobsNow[it.id].status !== 'error'));
        let rejected = [];
        // Version gratuite : quota de retraits par jour. Les vidéos refusées sont renvoyées à l'interface, qui les remet dans la pile.
        if (!(await isPro())) {
          const room = Math.max(0, PRO_CONFIG.freeDailyRemovals - (await usageToday()).removals);
          rejected = fresh.slice(room).map((it) => it.id);
          fresh = fresh.slice(0, room);
        }
        await mutate((j) => {
          for (const it of fresh) {
            j[it.id] = { id: it.id, url: it.url, status: 'pending', tries: 0, notBefore: Date.now() + grace, note: '', kind: it.kind || 'unfav', collection: it.collection || '', account: it.account || '' };
          }
        });
        if (fresh.length) await bumpUsage(fresh.length);
        pump();
        respond({ ok: true, rejected });
        break;
      }
      case 'cancel': {
        const ok = await mutate((j) => {
          const cur = j[msg.id];
          if (cur && cur.status === 'pending') {
            delete j[msg.id];
            return true;
          }
          return false;
        });
        if (ok) await bumpUsage(-1); // un retrait annulé ne compte pas dans le quota du jour
        respond({ ok });
        break;
      }
      case 'license-status': {
        respond(await planStatus());
        break;
      }
      case 'license-activate': {
        respond(await activateLicense(msg.key));
        pump(); // les réglages Pro (onglets en parallèle) s'appliquent tout de suite
        break;
      }
      case 'license-deactivate': {
        respond(await deactivateLicense());
        break;
      }
      case 'retry': {
        await mutate((j) => {
          const cur = j[msg.id];
          if (cur) Object.assign(cur, { status: 'pending', tries: 0, notBefore: Date.now(), note: '' });
        });
        pump();
        respond({ ok: true });
        break;
      }
      case 'reset-block': {
        // l'utilisateur a enregistré ses réglages : on redonne sa chance au blocage des images/vidéos
        queue.blockOff = false;
        queue.blockFails = 0;
        await saveQueue();
        respond({ ok: true });
        break;
      }
      case 'resume-queue': {
        // « Reprendre maintenant » après une pause de sécurité
        queue.pausedUntil = 0;
        queue.note = '';
        queue.failStreak = 0;
        await saveQueue();
        pump();
        respond({ ok: true });
        break;
      }
      case 'account': {
        await chrome.storage.local.set({ activeAccount: msg.account });
        pump();
        respond({ ok: true });
        break;
      }
      case 'whoami': {
        const { tabJobs = {} } = await chrome.storage.session.get('tabJobs');
        const job = tabJobs[sender.tab?.id];
        respond(job ? { job: job.id, kind: job.kind, collection: job.collection, account: job.account } : { job: null });
        break;
      }
      case 'job-result': {
        waiters[msg.id]?.({ status: msg.status, note: msg.note });
        respond({ ok: true });
        break;
      }
      default:
        respond({ ok: false });
    }
  })();
  return true;
});

chrome.alarms.create('pump', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(() => pump());
chrome.runtime.onStartup.addListener(() => pump());
chrome.runtime.onInstalled.addListener(() => pump());
