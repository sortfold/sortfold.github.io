// Traduction de l'interface (français ↔ anglais). Chargé avant content.js (même monde isolé : `TTS_I18N` est visible de content.js).
//
// Le code de l'extension écrit ses textes en français ; ce module les traduit à l'affichage, sans toucher à la logique :
// un observateur relit les nœuds de texte et les attributs (title, placeholder…) du panneau et remplace les phrases connues.
// Le texte d'origine est mémorisé : on peut donc repasser de l'anglais au français à tout moment.
//
// Langue : réglage « auto » (par défaut) = langue de la page TikTok, sinon celle du navigateur ; ou « fr » / « en » choisi à la main.
const TTS_I18N = (() => {
  // # = un nombre, ¤ = un morceau de texte quelconque. Le reste est littéral. Les règles les plus longues passent d'abord.
  const PAIRS = [
    // ── en-tête, onglets
    ['⇄ Trier mes favoris', '⇄ Sort my favorites'],
    ['Arrêter l\'opération en cours', 'Stop the current operation'],
    ['Déplacer les données vers un autre compte', 'Move data to another account'],
    ['Fermer', 'Close'],
    ['Comptes', 'Accounts'],
    ['Trier', 'Sort'],
    ['Gardés', 'Kept'],
    ['Retirés', 'Removed'],
    ['État', 'Status'],
    ['Langue de l\'interface', 'Interface language'],
    ['Automatique (langue de TikTok)', 'Automatic (TikTok\'s language)'],
    ['Langue', 'Language'],
    ['Réglages (langue, gestes, vitesse)', 'Settings (language, gestures, speed)'],
    ['Soutenir le projet (don)', 'Support the project (donation)'],
    ['Avancé (vitesse et pauses)', 'Advanced (speed and pauses)'],
    // ── écran de tri
    ['Tout est trié 🎉', 'All sorted 🎉'],
    // ── bandeau de progression
    ['Lecture de tes collections', 'Reading your collections'],
    ['Import de tes favoris', 'Importing your favorites'],
    ['Envoi à TikTok', 'Sending to TikTok'],
    ['ouverture de ton profil…', 'opening your profile…'],
    ['ouverture de ta liste…', 'opening your list…'],
    ['recherche de nouvelles collections…', 'looking for new collections…'],
    ['retrait de « ¤ »', 'removing from "$1"'],
    ['rangement dans « ¤ »', 'filing into "$1"'],
    ['Les premières vidéos à trier apparaissent dans quelques secondes.', 'The first videos to sort will appear in a few seconds.'],
    ['Pendant l\'import, la page TikTok peut ralentir : c\'est normal. Tu peux déjà trier les premières vidéos dès qu\'elles apparaissent.', 'While importing, the TikTok page may slow down: this is normal. You can already sort the first videos as soon as they appear.'],
    ['Étape 1 sur 2 : je lis d\'abord tes collections pour ne pas te montrer des vidéos déjà rangées. Ça peut prendre une ou deux minutes.', 'Step 1 of 2: I read your collections first so I do not show you videos that are already filed. This can take a minute or two.'],
    ['Étape 2 sur 2 : import de tes favoris.', 'Step 2 of 2: importing your favorites.'],
    ['Les rangements sont envoyés à TikTok : compte quelques secondes par collection.', 'Filing is sent to TikTok: allow a few seconds per collection.'],
    ['Importe tes favoris', 'Import your favorites'],
    ['Tu peux réimporter pour récupérer les nouveaux favoris.', 'You can re-import to get your new favorites.'],
    ['Clique sur « Importer depuis mon profil TikTok » : l\'extension lit tes favoris.', 'Click "Import from my TikTok profile": the extension reads your favorites.'],
    ['Glisse chaque vidéo :', 'Swipe each video:'],
    ['· ↑ ranger dans une collection.', '· ↑ file into a collection.'],
    ['Les retraits et les rangements partent à TikTok tout seuls, en arrière-plan.', 'Removals and filing are sent to TikTok automatically, in the background.'],
    ['Autre méthode : importer l\'export JSON de TikTok (Paramètres → Compte → Télécharger tes données).', 'Other method: import the JSON export from TikTok (Settings → Account → Download your data).'],
    ['↻ Reprendre l\'importation (# / #)', '↻ Resume the import ($1 / $2)'],
    ['↻ Reprendre l\'import (# / #)', '↻ Resume the import ($1 / $2)'],
    ['Importer depuis mon profil TikTok', 'Import from my TikTok profile'],
    ['Importer l\'export JSON', 'Import the JSON export'],
    ['⇄ Synchroniser les collections (#)', '⇄ Sync collections ($1)'],
    ['⏳ Synchronisation…', '⏳ Syncing…'],
    ['« Depuis mon profil » lit ton onglet Favoris (défilement automatique). L\'export JSON s\'obtient dans TikTok : Paramètres → Compte → Télécharger tes données.',
      '"From my profile" reads your Favorites tab (automatic scrolling). The JSON export comes from TikTok: Settings → Account → Download your data.'],
    ['Outil non officiel, non affilié à TikTok. TikTok interdit l\'automatisation : ton compte peut être limité, suspendu ou banni définitivement.',
      'Unofficial tool, not affiliated with TikTok. TikTok prohibits automation: your account may be limited, suspended or permanently banned.'],
    ['Envoie tes rangements et retraits de collections à TikTok', 'Sends your filing and collection removals to TikTok'],
    ['🔍 Chercher une collection…', '🔍 Search a collection…'],
    ['＋ Nouvelle collection', '＋ New collection'],
    ['# à trier', '$1 to sort'],
    ['Lit ton onglet Favoris sur TikTok. Les vidéos déjà importées ne sont pas dupliquées : ça reprend un import interrompu ou récupère les nouveaux favoris.',
      'Reads your Favorites tab on TikTok. Videos already imported are not duplicated: this resumes an interrupted import or fetches new favorites.'],
    ['↻ Importer les nouveaux favoris (rapide)', '↻ Import new favorites (fast)'],
    ['↻ Importer les nouveaux favoris', '↻ Import new favorites'],
    ['GARDER', 'KEEP'],
    ['RETIRER', 'REMOVE'],
    ['📁 RANGER', '📁 FILE'],
    ['Garder (#)', 'Keep ($1)'],
    ['Garder (←)', 'Keep (←)'],
    ['Garder (→)', 'Keep (→)'],
    ['Collection (↑)', 'Collection (↑)'],
    ['Retirer des favoris (←)', 'Remove from favorites (←)'],
    ['Retirer des favoris (→)', 'Remove from favorites (→)'],
    ['Annuler (Z)', 'Undo (Z)'],
    ['← retirer des favoris · → garder', '← remove from favorites · → keep'],
    ['← garder · → retirer des favoris', '← keep · → remove from favorites'],
    ['· ↑ ranger · touches 1-9 : collection numérotée. Glisse la carte de n\'importe où ; ▶ au centre pour lire. Dépose-la sur une collection pour la ranger.',
      '· ↑ file · keys 1-9: numbered collection. Drag the card from anywhere; ▶ in the middle to play. Drop it on a collection to file it.'],
    ['Désépingler', 'Unpin'],
    ['Épingler en haut', 'Pin to top'],
    // ── Gardés
    ['# sélectionnée(s)', '$1 selected'],
    ['Tout sélectionner (#)', 'Select all ($1)'],
    ['📁 Ranger dans…', '📁 File into…'],
    ['🗑 Retirer des favoris', '🗑 Remove from favorites'],
    ['Terminer', 'Done'],
    ['☑ Sélectionner plusieurs vidéos', '☑ Select several videos'],
    ['# gardées', '$1 kept'],
    ['Rien de gardé pour l\'instant.', 'Nothing kept yet.'],
    ['Afficher plus (# restantes)', 'Show more ($1 left)'],
    ['Remettre dans la pile', 'Put back in the deck'],
    ['Sortir de la collection (reste dans les favoris)', 'Take out of the collection (stays in favorites)'],
    ['Retirer des favoris TikTok', 'Remove from TikTok favorites'],
    ['# vidéo(s) rangée(s) dans « ¤ »', '$1 video(s) filed in "$2"'],
    ['# retrait(s) mis en file', '$1 removal(s) queued'],
    ['Retirer # vidéo(s) de tes favoris TikTok (automatiquement, en arrière-plan) ?', 'Remove $1 video(s) from your TikTok favorites (automatically, in the background)?'],
    // ── Collections
    ['# à ranger sur TikTok', '$1 to file on TikTok'],
    ['Tout est rangé sur TikTok', 'Everything is filed on TikTok'],
    ['Synchronisation…', 'Syncing…'],
    ['Synchroniser maintenant', 'Sync now'],
    ['Le rangement part tout seul quelques secondes après chaque glissement. ⊖ sort la vidéo de la collection, 🗑 la retire des favoris.',
      'Filing is sent automatically a few seconds after each swipe. ⊖ takes the video out of the collection, 🗑 removes it from favorites.'],
    ['Renommer', 'Rename'],
    ['Aucune collection. Glisse une vidéo vers le haut pour en créer une.', 'No collection yet. Swipe a video up to create one.'],
    ['↻ Relire mes collections TikTok', '↻ Re-read my TikTok collections'],
    ['Cette collection existe déjà sur TikTok : renomme-la dans TikTok (⋯ → Changer de nom), puis clique sur « Relire mes collections TikTok ».',
      'This collection already exists on TikTok: rename it in TikTok (⋯ → Rename), then click "Re-read my TikTok collections".'],
    ['Nouveau nom pour « ¤ » :', 'New name for "$1":'],
    ['Une collection porte déjà ce nom.', 'A collection already has this name.'],
    // ── Retirés
    ['⏳ en attente', '⏳ pending'],
    ['⏳ en cours', '⏳ in progress'],
    ['✓ retiré', '✓ removed'],
    ['✓ à vérifier', '✓ to check'],
    ['⚠ échec', '⚠ failed'],
    ['# retirées · # en attente', '$1 removed · $2 pending'],
    ['Aucune vidéo retirée.', 'No video removed.'],
    // ── fenêtre « Ranger dans une collection »
    ['Ranger dans une collection', 'File into a collection'],
    ['Nouvelle collection…', 'New collection…'],
    ['Créer et ranger', 'Create and file'],
    ['Annuler', 'Cancel'],
    // ── barre d'annulation, undo
    ['🗑 Retirée de tes favoris', '🗑 Removed from your favorites'],
    ['↺ Annuler (# s)', '↺ Undo ($1 s)'],
    ['Déjà parti : impossible d\'annuler.', 'Already sent: cannot undo.'],
    ['Rien à annuler', 'Nothing to undo'],
    ['Déjà retiré de TikTok, impossible d\'annuler', 'Already removed from TikTok, cannot undo'],
    // ── menu des comptes
    ['Compte actuel : ¤', 'Current account: $1'],
    ['# vidéos ici · # mises de côté', '$1 videos here · $2 set aside'],
    ['📤 Mettre de côté les données de ce compte', '📤 Set this account\'s data aside'],
    ['📥 Reprendre les données mises de côté (#)', '📥 Take back the data set aside ($1)'],
    ['⚙ Réglages (délais, sens des gestes)', '⚙ Settings (delays, swipe direction)'],
    ['⬇ Exporter mes données (sauvegarde)', '⬇ Export my data (backup)'],
    ['⬆ Restaurer une sauvegarde', '⬆ Restore a backup'],
    ['🗑 Tout réinitialiser (comme une nouvelle installation)', '🗑 Reset everything (like a fresh install)'],
    ['Remplacer les # vidéos déjà mises de côté ?', 'Replace the $1 videos already set aside?'],
    ['Données mises de côté. Ouvre l\'autre compte pour les reprendre.', 'Data set aside. Open the other account to take it back.'],
    ['Tout réinitialiser ?', 'Reset everything?'],
    ['Cela efface, pour TOUS les comptes, ton tri, tes collections locales, les données mises de côté et la file des retraits en attente.',
      'This erases, for ALL accounts, your sorting, your local collections, the data set aside and the queue of pending removals.'],
    ['Rien n\'est modifié sur TikTok : tes favoris et tes collections TikTok restent intacts.', 'Nothing is changed on TikTok: your TikTok favorites and collections stay intact.'],
    ['Dernière confirmation : repartir de zéro ?', 'Last confirmation: start from scratch?'],
    ['Extension réinitialisée : tout repart de zéro.', 'Extension reset: everything starts from scratch.'],
    ['Remplacer les # vidéos de ¤ par celles mises de côté ?', 'Replace the $1 videos of $2 with the ones set aside?'],
    ['Données reprises pour ¤', 'Data taken back for $1'],
    ['Des favoris triés avant la séparation par compte ont été trouvés. Les reprendre pour ¤ ?', 'Favorites sorted before the per-account separation were found. Take them back for $1?'],
    // ── avertissement de risque
    ['⚠ Avant de continuer', '⚠ Before you continue'],
    ['Cet outil pilote TikTok à ta place : clics, défilement, ouverture de vidéos en arrière-plan.', 'This tool drives TikTok for you: clicks, scrolling, opening videos in the background.'],
    ['TikTok interdit l\'automatisation dans ses conditions d\'utilisation.', 'TikTok prohibits automation in its terms of use.'],
    ['Ton compte peut être', 'Your account may be'],
    ['limité, suspendu ou banni définitivement', 'limited, suspended or permanently banned'],
    ['même avec des pauses entre les actions. Ce risque existe et personne ne peut le supprimer.', 'even with pauses between actions. This risk exists and nobody can remove it.'],
    ['Tu utilises l\'extension', 'You use the extension'],
    ['à tes propres risques', 'at your own risk'],
    ['Elle n\'est pas affiliée à TikTok et son auteur n\'est pas responsable des sanctions prises contre ton compte. Conseils : petits lots, rythme prudent, teste d\'abord sur un compte secondaire.',
      'It is not affiliated with TikTok and its author is not responsible for penalties taken against your account. Tips: small batches, a cautious pace, and try a secondary account first.'],
    ['Je comprends que mon compte TikTok peut être suspendu ou banni, et j\'accepte ce risque.', 'I understand that my TikTok account may be suspended or banned, and I accept this risk.'],
    ['J\'accepte et je continue', 'I accept and continue'],
    ['⚠ Avertissement', '⚠ Warning'],
    ['Utilisation à tes propres risques ; fais des pauses et de petits lots.', 'Use at your own risk; take breaks and work in small batches.'],
    // ── dons
    ['☕ Soutenir le projet', '☕ Support the project'],
    ['L\'extension est faite et entretenue par une seule personne. Si elle te fait gagner du temps, un don, même petit, aide à la garder à jour quand TikTok change.',
      'The extension is made and maintained by one person. If it saves you time, even a small donation helps keep it up to date when TikTok changes.'],
    ['☕ Faire un don', '☕ Donate'],
    // ── version gratuite / Pro
    ['Limite gratuite atteinte : # retraits par jour. Passe en Pro (¤) dans l\'onglet État.', 'Free limit reached: $1 removals per day. Go Pro ($2) in the Status tab.'],
    ['Fonction réservée à la version Pro (¤). Voir l\'onglet État.', 'Feature reserved for the Pro version ($1). See the Status tab.'],
    ['⭐ Version', '⭐ Version'],
    ['Mode développement : tout est débloqué (aucune boutique configurée dans config.js).', 'Development mode: everything is unlocked (no store set up in config.js).'],
    ['⭐ Pro activée', '⭐ Pro activated'],
    ['Merci !', 'Thank you!'],
    ['clé ¤ · retraits illimités, onglets en parallèle, sauvegarde.', 'key $1 · unlimited removals, parallel tabs, backup.'],
    ['Désactiver sur cet ordinateur', 'Deactivate on this computer'],
    ['⭐ Version gratuite', '⭐ Free version'],
    ['Retraits aujourd\'hui :', 'Removals today:'],
    ['1 onglet de retrait · pas de sauvegarde de données', '1 removal tab · no data backup'],
    ['Passer en Pro : ¤ (achat unique)', 'Go Pro: $1 (one-time purchase)'],
    ['Pro : retraits illimités, jusqu\'à 3 onglets en parallèle avec chargement allégé (plus rapide), sauvegarde et restauration.', 'Pro: unlimited removals, up to 3 parallel tabs with lighter loading (faster), backup and restore.'],
    ['Clé de licence reçue par e-mail', 'License key received by e-mail'],
    ['Activer', 'Activate'],
    ['Page d\'achat non configurée.', 'Purchase page not set up.'],
    ['Vérification…', 'Checking…'],
    ['Échec de l\'activation.', 'Activation failed.'],
    ['Licence Pro activée. Merci !', 'Pro license activated. Thank you!'],
    ['Désactiver la licence sur cet ordinateur ? Tu pourras l\'utiliser sur un autre.', 'Deactivate the license on this computer? You will be able to use it on another one.'],
    ['Mode illimité activé.', 'Unlimited mode activated.'],
    ['code perso', 'personal code'],
    ['Saisis ta clé de licence.', 'Enter your license key.'],
    ['Clé refusée.', 'Key rejected.'],
    ['Cette clé ne correspond pas à ce produit.', 'This key does not match this product.'],
    ['Impossible de joindre le service de licences. Vérifie ta connexion.', 'Cannot reach the license service. Check your connection.'],
    ['Licence désactivée ou expirée.', 'License deactivated or expired.'],
    ['Vérification impossible depuis trop longtemps : reconnecte-toi à Internet.', 'Verification has been impossible for too long: connect to the Internet.'],
    ['Mode développement : tout est déjà débloqué.', 'Development mode: everything is already unlocked.'],
    // ── onglet État
    ['moins d\'1 min', 'less than 1 min'],
    ['environ # min', 'about $1 min'],
    ['File en pause.', 'Queue paused.'],
    ['Reprise dans # min.', 'Resuming in $1 min.'],
    ['Reprendre maintenant', 'Resume now'],
    ['TikTok semble limiter les retraits : pause de ¤.', 'TikTok seems to be limiting removals: pause of $1.'],
    ['# secondes', '$1 seconds'],
    ['# minutes', '$1 minutes'],
    ['# minute', '$1 minute'],
    ['Reprise dans # s.', 'Resuming in $1 s.'],
    ['Pause de sécurité quand TikTok semble bloquer (secondes)', 'Safety pause when TikTok seems to block (seconds)'],
    ['Chargement complet rétabli dans les onglets de retrait (le blocage des images/vidéos ne convenait pas).', 'Full loading restored in the removal tabs (blocking images/videos did not work).'],
    ['♥ Gardée', '♥ Kept'],
    ['📁 Rangée', '📁 Filed'],
    ['🗑 Retirée des favoris', '🗑 Removed from favorites'],
    ['↺ Annulée', '↺ Undone'],
    ['↩ Remise dans la pile', '↩ Put back in the deck'],
    ['⊖ Sortie de la collection', '⊖ Taken out of the collection'],
    ['vidéo #', 'video $1'],
    ['(détecté à ¤)', '(detected at $1)'],
    ['🗑 Retraits des favoris TikTok', '🗑 Removals from TikTok favorites'],
    ['# en attente · # en cours · # faits ·', '$1 pending · $2 in progress · $3 done ·'],
    ['# en échec', '$1 failed'],
    ['🗑 Retraits : # restants', '🗑 Removals: $1 left'],
    ['# en cours', '$1 in progress'],
    ['Voir', 'View'],
    ['restantes · # onglet(s) en parallèle', 'remaining · $1 tab(s) in parallel'],
    ['Annuler les # en attente', 'Cancel the $1 pending'],
    ['↻ Réessayer les # échecs', '↻ Retry the $1 failures'],
    ['📁 Collections', '📁 Collections'],
    ['# à envoyer à TikTok', '$1 to send to TikTok'],
    ['# collection(s) en erreur', '$1 collection(s) with errors'],
    ['⇄ Synchroniser maintenant', '⇄ Sync now'],
    ['⬇ Import depuis TikTok', '⬇ Import from TikTok'],
    ['# vidéos importées', '$1 videos imported'],
    ['sur # favoris', 'out of $1 favorites'],
    ['dernier import :', 'last import:'],
    ['Tout relire (lent)', 'Re-read everything (slow)'],
    ['↻ Relire les collections modifiées', '↻ Re-read modified collections'],
    ['Relire toutes les collections (lent)', 'Re-read all collections (slow)'],
    ['💾 Sauvegarde', '💾 Backup'],
    ['Un fichier avec ton tri, tes collections locales et tes réglages. Rien n\'est envoyé nulle part.', 'A file with your sorting, local collections and settings. Nothing is sent anywhere.'],
    ['⬇ Exporter mes données', '⬇ Export my data'],
    ['📜 Journal (80 dernières actions)', '📜 Log (last 80 actions)'],
    ['Un retrait est irréversible : retrouve ici la vidéo et remets-la en favori à la main si besoin.', 'A removal cannot be undone: find the video here and re-favorite it by hand if needed.'],
    ['Rien pour l\'instant.', 'Nothing yet.'],
    ['# retrait(s) annulé(s) : les vidéos sont revenues dans la pile', '$1 removal(s) cancelled: the videos are back in the deck'],
    ['Sauvegarde exportée (# élément(s))', 'Backup exported ($1 item(s))'],
    ['Fichier illisible.', 'Unreadable file.'],
    ['Ce fichier n\'est pas une sauvegarde de l\'extension.', 'This file is not a backup of the extension.'],
    ['Sauvegarde vide.', 'Empty backup.'],
    ['Restaurer la sauvegarde ? Elle REMPLACE les données actuelles de : ¤.', 'Restore the backup? It REPLACES the current data of: $1.'],
    ['Sauvegarde restaurée.', 'Backup restored.'],
    ['# vidéos importées', '$1 videos imported'],
    ['réglages', 'settings'],
    // ── réglages
    ['⚙ Réglages', '⚙ Settings'],
    ['Délai pour annuler un retrait (secondes)', 'Time to undo a removal (seconds)'],
    ['Onglets de retrait en parallèle (1 à 3)', 'Parallel removal tabs (1 to 3)'],
    ['Envoyer les rangements aux collections après (secondes d\'inactivité)', 'Send filing to collections after (seconds of inactivity)'],
    ['Retraits plus rapides : ne pas charger images et vidéos dans les onglets de retrait', 'Faster removals: do not load images and videos in removal tabs'],
    ['Pause entre deux retraits : min (s)', 'Pause between two removals: min (s)'],
    ['Pause entre deux retraits : max (s)', 'Pause between two removals: max (s)'],
    ['Inverser les gestes (droite = garder, gauche = retirer)', 'Reverse the gestures (right = keep, left = remove)'],
    ['Plus d\'onglets et des pauses courtes = retraits plus rapides, mais plus de risque que TikTok te ralentisse ou te bloque. L\'extension se met en pause d\'elle-même (5 minutes en version gratuite, réglable en Pro) si TikTok refuse plusieurs retraits de suite. Une pause trop courte augmente le risque de limitation du compte.',
      'More tabs and short pauses = faster removals, but a higher risk that TikTok slows or blocks you. The extension pauses by itself (5 minutes in the free version, adjustable in Pro) if TikTok refuses several removals in a row. A pause that is too short increases the risk of the account being limited.'],
    ['Enregistrer', 'Save'],
    ['Réglages enregistrés.', 'Settings saved.'],
    ['— Pro', '— Pro'],
    // ── import / synchronisation / erreurs
    ['Arrêté par toi.', 'Stopped by you.'],
    ['Une opération est déjà en cours (import ou synchronisation). Clique sur ✕ Stop pour l\'arrêter.', 'An operation is already running (import or sync). Click ✕ Stop to stop it.'],
    ['TikTok limite l\'accès à tes favoris en ce moment (« Une erreur est survenue »). Attends 10 à 30 minutes, recharge tiktok.com, puis relance.',
      'TikTok is limiting access to your favorites right now ("Something went wrong"). Wait 10 to 30 minutes, reload tiktok.com, then try again.'],
    ['Connecte-toi à TikTok.', 'Sign in to TikTok.'],
    ['Impossible d\'ouvrir ton profil (plusieurs rechargements sans succès).', 'Cannot open your profile (several reloads without success).'],
    ['Impossible d\'ouvrir ton profil.', 'Cannot open your profile.'],
    ['Onglet « Favoris » introuvable sur ton profil.', '"Favorites" tab not found on your profile.'],
    ['Sous-onglet « ¤ » introuvable.', 'Sub-tab "$1" not found.'],
    ['Le sous-onglet « ¤ » ne s\'est pas ouvert.', 'The sub-tab "$1" did not open.'],
    ['Import : ¤…', 'Import: $1…'],
    ['# favoris lus, # collections (# vidéos déjà rangées)', '$1 favorites read, $2 collections ($3 videos already filed)'],
    ['Collections non lues : ¤', 'Collections not read: $1'],
    ['# favoris lus sur # : relance l\'import pour continuer', '$1 favorites read out of $2: run the import again to continue'],
    ['# favoris lus (TikTok en annonce # : certaines vidéos ne sont plus disponibles)', '$1 favorites read (TikTok announces $2: some videos are no longer available)'],
    ['Collection #/# : « ¤ »', 'Collection $1/$2: "$3"'],
    ['Recherche de nouvelles collections…', 'Looking for new collections…'],
    ['# collections vues (# inchangée(s) ignorée(s)), # vidéos déjà rangées', '$1 collections seen ($2 unchanged skipped), $3 videos already filed'],
    ['Page de la collection « ¤ » introuvable.', 'Collection page "$1" not found.'],
    ['Bouton « Créer une nouvelle collection » introuvable.', '"Create a new collection" button not found.'],
    ['Champ du nom de collection introuvable.', 'Collection name field not found.'],
    ['TikTok refuse le nom « ¤ » : ¤ Renomme la collection (✎).', 'TikTok rejects the name "$1": $2 Rename the collection (✎).'],
    ['TikTok refuse le nom « ¤ » : ¤', 'TikTok rejects the name "$1": $2'],
    ['Ce nom est inapproprié. Réessaie.', 'This name is inappropriate. Try again.'],
    ['Bouton « Suivant » introuvable.', '"Next" button not found.'],
    ['Fenêtre de sélection introuvable pour « ¤ » (¤ ; à l\'écran : ¤).', 'Selection window not found for "$1" ($2; on screen: $3).'],
    ['collection existante', 'existing collection'],
    ['nouvelle collection', 'new collection'],
    ['aucune fenêtre', 'no window'],
    ['Sélection incohérente pour « ¤ » (¤).', 'Inconsistent selection for "$1" ($2).'],
    ['Mode « Gérer les vidéos » introuvable pour « ¤ ».', '"Manage videos" mode not found for "$1".'],
    ['Bouton « Supprimer » introuvable dans « Gérer les vidéos ».', '"Delete" button not found in "Manage videos".'],
    ['Confirmation de retrait introuvable.', 'Removal confirmation not found.'],
    ['Rien en attente. Vérification auprès de TikTok…', 'Nothing pending. Checking with TikTok…'],
    ['Retrait de « ¤ »…', 'Removing from "$1"…'],
    ['Rangement dans « ¤ »…', 'Filing into "$1"…'],
    ['Synchronisation arrêtée.', 'Sync stopped.'],
    ['Arrêt en cours…', 'Stopping…'],
    ['# synchronisées, # collection(s) en erreur (voir l\'onglet Collections)', '$1 synced, $2 collection(s) with errors (see the Collections tab)'],
    ['# synchronisées, # introuvables dans la liste TikTok', '$1 synced, $2 not found in the TikTok list'],
    ['# vidéos synchronisées avec TikTok', '$1 videos synced with TikTok'],
    ['Le compte a changé (¤). Ferme puis rouvre l\'extension.', 'The account changed ($1). Close and reopen the extension.'],
    // ── onglet de retrait
    ['Ce retrait appartient à ¤ (connecté : ¤)', 'This removal belongs to $1 (signed in: $2)'],
    ['personne', 'nobody'],
    ['Bouton favori introuvable (connexion ? captcha ?)', 'Favorite button not found (signed out? captcha?)'],
    ['La page affiche une autre vidéo', 'The page shows another video'],
    ['Déjà retiré', 'Already removed'],
    ['État du favori illisible', 'Favorite state unreadable'],
    ['Le clic n\'a pas retiré le favori', 'The click did not remove the favorite'],
    ['Clic effectué, état non vérifiable', 'Click done, state cannot be verified'],
    ['Délai dépassé', 'Timed out'],
    // ── divers
    ['vidéo(s)', 'video(s)'],
    ['vidéos', 'videos'],
    ['favoris', 'favorites'],
  ];

  const norm = (s) => s.replace(/[’‘]/g, "'");
  const escRe = (s) => s.replace(/[.+?^${}()|[\]\\*]/g, '\\$&');
  const RULES = PAIRS.map(([fr, en]) => {
    let src = escRe(norm(fr)).replace(/¤$/, '(.+)').replace(/¤/g, '(.+?)').replace(/#/g, '(\\d+)');
    if (/^\p{L}/u.test(fr)) src = `(?<![\\p{L}\\d])${src}`;
    if (/\p{L}$/u.test(fr)) src = `${src}(?![\\p{L}])`;
    return { len: fr.length, re: new RegExp(src, 'gu'), en };
  }).sort((a, b) => b.len - a.len);

  let lang = 'fr';
  const cache = new Map();

  function tr(text) {
    if (lang !== 'en' || !text) return text;
    const src = String(text);
    if (!/[A-Za-zÀ-ÿ]/.test(src)) return src;
    if (cache.has(src)) return cache.get(src);
    let out = norm(src).replace(/\s+/g, ' '); // retours à la ligne et indentations des gabarits : un seul espace
    // phrases déjà remplacées : on ne les repasse pas dans les règles suivantes (pas de double traduction)
    const marks = [];
    for (const r of RULES) {
      out = out.replace(r.re, (...m) => {
        const groups = m.slice(1, -2).filter((g) => typeof g === 'string' || g === undefined);
        const en = r.en.replace(/\$(\d)/g, (_, i) => tr(groups[i - 1] ?? ''));
        marks.push(en);
        return `${marks.length - 1}`;
      });
    }
    out = out.replace(/(\d+)/g, (_, i) => marks[i]);
    if (cache.size > 3000) cache.clear();
    cache.set(src, out);
    return out;
  }

  const ATTRS = ['title', 'placeholder', 'aria-label', 'alt'];
  const SKIP = 'style, script, textarea, input, [data-nt]';
  const mem = new WeakMap(); // nœud ou élément → { fr, en } (texte d'origine et texte affiché)

  function doText(node) {
    const p = node.parentElement;
    if (!p || p.closest(SKIP) || p.closest('.chip:not(.new)')) return; // les noms de collection sont des données de l'utilisateur
    const m = mem.get(node);
    if (m && node.data === m.en) {
      // pas modifié par le code : on ne fait que réappliquer la langue courante
      const en = tr(m.fr);
      if (en !== node.data) { node.data = en; m.en = en; }
      return;
    }
    const fr = node.data;
    const en = tr(fr);
    mem.set(node, { fr, en });
    if (en !== fr) node.data = en;
  }
  function doAttrs(el) {
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const key = `${a}:`;
      let m = mem.get(el) || {};
      const cur = el.getAttribute(a);
      if (m[key] && cur === m[key].en) {
        const en = tr(m[key].fr);
        if (en !== cur) { el.setAttribute(a, en); m[key].en = en; }
      } else {
        const en = tr(cur);
        m[key] = { fr: cur, en };
        if (en !== cur) el.setAttribute(a, en);
      }
      mem.set(el, m);
    }
  }
  function walk(rootNode) {
    if (rootNode.nodeType === 3) return doText(rootNode);
    if (rootNode.nodeType !== 1 && rootNode.nodeType !== 11) return;
    if (rootNode.nodeType === 1) doAttrs(rootNode);
    const w = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) (n.nodeType === 3 ? doText(n) : doAttrs(n));
  }

  let observer = null;
  let target = null;
  function attach(root) {
    target = root;
    observer?.disconnect();
    observer = new MutationObserver((muts) => {
      observer.disconnect();
      try {
        for (const m of muts) {
          if (m.type === 'childList') m.addedNodes.forEach(walk);
          else if (m.type === 'characterData') doText(m.target);
          else if (m.type === 'attributes') doAttrs(m.target);
        }
      } finally {
        observer.observe(target, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
      }
    });
    observer.observe(target, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    walk(root);
  }

  // « auto » : langue de la page TikTok, sinon celle du navigateur.
  const detect = () => {
    const l = (document.documentElement.lang || navigator.language || 'en').toLowerCase();
    return l.startsWith('fr') ? 'fr' : 'en';
  };
  const resolve = (pref) => (pref === 'fr' || pref === 'en' ? pref : detect());

  function set(pref) {
    const next = resolve(pref);
    const changed = next !== lang;
    lang = next;
    if (changed && target) walk(target);
    return lang;
  }

  return { attach, set, tr, get lang() { return lang; }, locale: () => (lang === 'en' ? 'en-GB' : 'fr-FR') };
})();
