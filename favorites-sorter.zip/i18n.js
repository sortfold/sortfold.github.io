// Traduction de l'interface. Chargé avant content.js (même monde isolé : `TTS_I18N` est visible de content.js) et par la
// fenêtre de l'icône (popup.html).
//
// Le code de l'extension écrit ses textes en français ; ce module les traduit à l'affichage, sans toucher à la logique :
// un observateur relit les nœuds de texte et les attributs (title, placeholder…) du panneau et remplace les phrases connues.
// Le texte d'origine est mémorisé : on peut donc changer de langue à tout moment.
//
// Langue : réglage « auto » (par défaut) = langue de la page TikTok, sinon celle du navigateur ; ou une langue choisie à la main.
const TTS_I18N = (() => {
  // Langues proposées : code, nom (dans sa propre langue), format des nombres et des dates.
  const LANGS = [
    ['fr', 'Français', 'fr-FR'],
    ['en', 'English', 'en-GB'],
    ['es', 'Español', 'es-ES'],
    ['de', 'Deutsch', 'de-DE'],
    ['pt', 'Português', 'pt-BR'],
    ['it', 'Italiano', 'it-IT'],
  ];
  const COL = { en: 1, es: 2, de: 3, pt: 4, it: 5 };
  // Une ligne par texte : [français, anglais, espagnol, allemand, portugais, italien].
  // Dans le français : # = un nombre, ¤ = un morceau de texte quelconque ; dans les traductions, $1, $2… les reprennent
  // dans l'ordre. Le reste est littéral. Les règles les plus longues passent d'abord. Case vide = anglais.
  const ROWS = [
    // ── en-tête, onglets
    [`⇄ Trier mes favoris`, `⇄ Sort my favorites`, `⇄ Ordenar mis favoritos`, `⇄ Favoriten sortieren`, `⇄ Organizar meus favoritos`, `⇄ Ordina i miei preferiti`],
    [`Arrêter l'opération en cours`, `Stop the current operation`, `Detener la operación en curso`, `Laufenden Vorgang stoppen`, `Parar a operação em andamento`, `Interrompi l'operazione in corso`],
    [`Déplacer les données vers un autre compte`, `Move data to another account`, `Mover los datos a otra cuenta`, `Daten in ein anderes Konto verschieben`, `Mover os dados para outra conta`, `Sposta i dati su un altro account`],
    [`Fermer`, `Close`, `Cerrar`, `Schließen`, `Fechar`, `Chiudi`],
    [`Comptes`, `Accounts`, `Cuentas`, `Konten`, `Contas`, `Account`],
    [`Trier`, `Sort`, `Ordenar`, `Sortieren`, `Organizar`, `Ordina`],
    [`Gardés`, `Kept`, `Conservados`, `Behalten`, `Mantidos`, `Tenuti`],
    [`Retirés`, `Removed`, `Quitados`, `Entfernt`, `Removidos`, `Rimossi`],
    [`Suivi`, `Activity`, `Actividad`, `Aktivität`, `Atividade`, `Attività`],
    [`⭐ Passer en Pro`, `⭐ Go Pro`, `⭐ Pasar a Pro`, `⭐ Pro holen`, `⭐ Obter o Pro`, `⭐ Passa a Pro`],
    [`Ta licence Pro`, `Your Pro license`, `Tu licencia Pro`, `Deine Pro-Lizenz`, `Sua licença Pro`, `La tua licenza Pro`],
    [`Retraits illimités, plus rapide : passe en Pro ou saisis ta clé`, `Unlimited removals, faster: go Pro or enter your key`, `Eliminaciones ilimitadas, más rápido: pasa a Pro o introduce tu clave`, `Unbegrenztes Entfernen, schneller: hol dir Pro oder gib deinen Schlüssel ein`, `Remoções ilimitadas, mais rápido: obtenha o Pro ou digite sua chave`, `Rimozioni illimitate, più veloce: passa a Pro o inserisci la tua chiave`],
    [`Retraits illimités (gratuit : # par jour)`, `Unlimited removals (free: $1 per day)`, `Eliminaciones ilimitadas (gratis: $1 al día)`, `Unbegrenztes Entfernen (kostenlos: $1 pro Tag)`, `Remoções ilimitadas (grátis: $1 por dia)`, `Rimozioni illimitate (gratis: $1 al giorno)`],
    [`Jusqu'à 3 onglets en parallèle, plus rapide`, `Up to 3 parallel tabs, faster`, `Hasta 3 pestañas en paralelo, más rápido`, `Bis zu 3 Tabs parallel, schneller`, `Até 3 abas em paralelo, mais rápido`, `Fino a 3 schede in parallelo, più veloce`],
    [`Tu soutiens le développement de l'extension`, `You support the development of the extension`, `Apoyas el desarrollo de la extensión`, `Du unterstützt die Entwicklung der Erweiterung`, `Você apoia o desenvolvimento da extensão`, `Sostieni lo sviluppo dell'estensione`],
    [`Acheter le Pro : ¤ (paiement unique)`, `Buy Pro: $1 (one-time payment)`, `Comprar Pro: $1 (pago único)`, `Pro kaufen: $1 (einmalige Zahlung)`, `Comprar o Pro: $1 (pagamento único)`, `Acquista Pro: $1 (pagamento unico)`],
    [`Pas d'abonnement. Remboursement sous 14 jours sur demande.`, `No subscription. 14-day refund on request.`, `Sin suscripción. Reembolso en 14 días si lo pides.`, `Kein Abo. Erstattung innerhalb von 14 Tagen auf Anfrage.`, `Sem assinatura. Reembolso em até 14 dias, se pedir.`, `Nessun abbonamento. Rimborso entro 14 giorni su richiesta.`],
    [`J'ai déjà une clé de licence`, `I already have a license key`, `Ya tengo una clave de licencia`, `Ich habe schon einen Lizenzschlüssel`, `Já tenho uma chave de licença`, `Ho già una chiave di licenza`],
    [`Colle ici la clé reçue par e-mail`, `Paste the key you received by e-mail here`, `Pega aquí la clave recibida por correo`, `Füge hier den per E-Mail erhaltenen Schlüssel ein`, `Cole aqui a chave recebida por e-mail`, `Incolla qui la chiave ricevuta via e-mail`],
    [`Langue de l'interface`, `Interface language`, `Idioma de la interfaz`, `Sprache der Oberfläche`, `Idioma da interface`, `Lingua dell'interfaccia`],
    [`Automatique (langue de TikTok)`, `Automatic (TikTok's language)`, `Automático (idioma de TikTok)`, `Automatisch (Sprache von TikTok)`, `Automático (idioma do TikTok)`, `Automatica (lingua di TikTok)`],
    [`Langue`, `Language`, `Idioma`, `Sprache`, `Idioma`, `Lingua`],
    [`Réglages (langue, gestes, vitesse)`, `Settings (language, gestures, speed)`, `Ajustes (idioma, gestos, velocidad)`, `Einstellungen (Sprache, Gesten, Tempo)`, `Configurações (idioma, gestos, velocidade)`, `Impostazioni (lingua, gesti, velocità)`],
    [`🔧 Diagnostic`, `🔧 Diagnostics`, `🔧 Diagnóstico`, `🔧 Diagnose`, `🔧 Diagnóstico`, `🔧 Diagnostica`],
    [`Si une synchronisation ne fait rien, clique sur « Copier le rapport » et envoie-le à sortfold@gmail.com : il ne contient ni tes vidéos ni ton pseudo, seulement les étapes et les compteurs.`, `If a sync does nothing, click "Copy the report" and send it to sortfold@gmail.com: it contains neither your videos nor your username, only the steps and counters.`, `Si una sincronización no hace nada, haz clic en «Copiar el informe» y envíalo a sortfold@gmail.com: no contiene ni tus vídeos ni tu usuario, solo los pasos y los contadores.`, `Wenn eine Synchronisierung nichts tut, klick auf „Bericht kopieren“ und schick ihn an sortfold@gmail.com: Er enthält weder deine Videos noch deinen Namen, nur die Schritte und Zähler.`, `Se uma sincronização não fizer nada, clique em "Copiar o relatório" e envie para sortfold@gmail.com: ele não contém seus vídeos nem seu usuário, só as etapas e os contadores.`, `Se una sincronizzazione non fa nulla, clicca su «Copia il rapporto» e invialo a sortfold@gmail.com: non contiene né i tuoi video né il tuo nome utente, solo i passaggi e i contatori.`],
    [`📋 Copier le rapport`, `📋 Copy the report`, `📋 Copiar el informe`, `📋 Bericht kopieren`, `📋 Copiar o relatório`, `📋 Copia il rapporto`],
    [`Copié ✓`, `Copied ✓`, `Copiado ✓`, `Kopiert ✓`, `Copiado ✓`, `Copiato ✓`],
    [`Sélectionné : fais Ctrl+C`, `Selected: press Ctrl+C`, `Seleccionado: pulsa Ctrl+C`, `Markiert: drück Strg+C`, `Selecionado: aperte Ctrl+C`, `Selezionato: premi Ctrl+C`],
    [`Voir le rapport`, `View the report`, `Ver el informe`, `Bericht ansehen`, `Ver o relatório`, `Vedi il rapporto`],
    [`Soutenir le projet (don)`, `Support the project (donation)`, `Apoyar el proyecto (donación)`, `Projekt unterstützen (Spende)`, `Apoiar o projeto (doação)`, `Sostieni il progetto (donazione)`],
    [`Avancé (vitesse et pauses)`, `Advanced (speed and pauses)`, `Avanzado (velocidad y pausas)`, `Erweitert (Tempo und Pausen)`, `Avançado (velocidade e pausas)`, `Avanzate (velocità e pause)`],
    // ── écran de tri
    [`Tout est trié 🎉`, `All sorted 🎉`, `Todo ordenado 🎉`, `Alles sortiert 🎉`, `Tudo organizado 🎉`, `Tutto ordinato 🎉`],
    // ── bandeau de progression
    [`Lecture de tes collections`, `Reading your collections`, `Leyendo tus colecciones`, `Deine Sammlungen werden gelesen`, `Lendo suas coleções`, `Lettura delle tue raccolte`],
    [`Import de tes favoris`, `Importing your favorites`, `Importando tus favoritos`, `Deine Favoriten werden importiert`, `Importando seus favoritos`, `Importazione dei tuoi preferiti`],
    [`Envoi à TikTok`, `Sending to TikTok`, `Enviando a TikTok`, `Senden an TikTok`, `Enviando ao TikTok`, `Invio a TikTok`],
    [`ouverture de ton profil…`, `opening your profile…`, `abriendo tu perfil…`, `dein Profil wird geöffnet…`, `abrindo seu perfil…`, `apertura del tuo profilo…`],
    [`ouverture de ta liste…`, `opening your list…`, `abriendo tu lista…`, `deine Liste wird geöffnet…`, `abrindo sua lista…`, `apertura del tuo elenco…`],
    [`recherche de nouvelles collections…`, `looking for new collections…`, `buscando colecciones nuevas…`, `suche nach neuen Sammlungen…`, `procurando coleções novas…`, `ricerca di nuove raccolte…`],
    [`retrait de « ¤ »`, `removing from "$1"`, `quitando de «$1»`, `Entfernen aus „$1“`, `removendo de "$1"`, `rimozione da «$1»`],
    [`rangement dans « ¤ »`, `filing into "$1"`, `moviendo a «$1»`, `Ablegen in „$1“`, `colocando em "$1"`, `inserimento in «$1»`],
    [`Les premières vidéos à trier apparaissent dans quelques secondes.`, `The first videos to sort will appear in a few seconds.`, `Los primeros vídeos para ordenar aparecerán en unos segundos.`, `Die ersten Videos zum Sortieren erscheinen in wenigen Sekunden.`, `Os primeiros vídeos para organizar aparecem em alguns segundos.`, `I primi video da ordinare appariranno tra pochi secondi.`],
    [`Pendant l'import, la page TikTok peut ralentir : c'est normal. Tu peux déjà trier les premières vidéos dès qu'elles apparaissent.`, `While importing, the TikTok page may slow down: this is normal. You can already sort the first videos as soon as they appear.`, `Durante la importación, la página de TikTok puede ir más lenta: es normal. Ya puedes ordenar los primeros vídeos en cuanto aparezcan.`, `Während des Imports kann die TikTok-Seite langsamer werden: Das ist normal. Du kannst die ersten Videos schon sortieren, sobald sie erscheinen.`, `Durante a importação, a página do TikTok pode ficar lenta: é normal. Você já pode organizar os primeiros vídeos assim que aparecerem.`, `Durante l'importazione, la pagina di TikTok può rallentare: è normale. Puoi già ordinare i primi video appena compaiono.`],
    [`Étape 1 sur 2 : je lis d'abord tes collections pour ne pas te montrer des vidéos déjà rangées. Ça peut prendre une ou deux minutes.`, `Step 1 of 2: I read your collections first so I do not show you videos that are already filed. This can take a minute or two.`, `Paso 1 de 2: primero leo tus colecciones para no mostrarte vídeos que ya están en una. Puede tardar uno o dos minutos.`, `Schritt 1 von 2: Ich lese zuerst deine Sammlungen, damit du keine Videos siehst, die schon abgelegt sind. Das kann ein bis zwei Minuten dauern.`, `Etapa 1 de 2: primeiro leio suas coleções para não mostrar vídeos que já estão em uma. Pode levar um ou dois minutos.`, `Passo 1 di 2: prima leggo le tue raccolte per non mostrarti video già sistemati. Può richiedere uno o due minuti.`],
    [`Étape 2 sur 2 : import de tes favoris.`, `Step 2 of 2: importing your favorites.`, `Paso 2 de 2: importando tus favoritos.`, `Schritt 2 von 2: Import deiner Favoriten.`, `Etapa 2 de 2: importando seus favoritos.`, `Passo 2 di 2: importazione dei tuoi preferiti.`],
    [`Les rangements sont envoyés à TikTok : compte quelques secondes par collection.`, `Filing is sent to TikTok: allow a few seconds per collection.`, `Los cambios de colección se envían a TikTok: cuenta unos segundos por colección.`, `Die Zuordnungen werden an TikTok gesendet: Rechne mit ein paar Sekunden pro Sammlung.`, `As coleções são enviadas ao TikTok: conte alguns segundos por coleção.`, `Gli inserimenti vengono inviati a TikTok: calcola qualche secondo per raccolta.`],
    [`Importe tes favoris`, `Import your favorites`, `Importa tus favoritos`, `Importiere deine Favoriten`, `Importe seus favoritos`, `Importa i tuoi preferiti`],
    [`Tu peux réimporter pour récupérer les nouveaux favoris.`, `You can re-import to get your new favorites.`, `Puedes volver a importar para recuperar los favoritos nuevos.`, `Du kannst erneut importieren, um neue Favoriten zu holen.`, `Você pode importar de novo para pegar os favoritos novos.`, `Puoi reimportare per recuperare i nuovi preferiti.`],
    [`Clique sur « Importer depuis mon profil TikTok » : l'extension lit tes favoris.`, `Click "Import from my TikTok profile": the extension reads your favorites.`, `Haz clic en «Importar desde mi perfil de TikTok»: la extensión lee tus favoritos.`, `Klick auf „Aus meinem TikTok-Profil importieren“: Die Erweiterung liest deine Favoriten.`, `Clique em "Importar do meu perfil do TikTok": a extensão lê seus favoritos.`, `Clicca su «Importa dal mio profilo TikTok»: l'estensione legge i tuoi preferiti.`],
    [`Glisse chaque vidéo :`, `Swipe each video:`, `Desliza cada vídeo:`, `Wisch jedes Video:`, `Deslize cada vídeo:`, `Scorri ogni video:`],
    [`· ↑ ranger dans une collection.`, `· ↑ file into a collection.`, `· ↑ mover a una colección.`, `· ↑ in eine Sammlung ablegen.`, `· ↑ colocar em uma coleção.`, `· ↑ metti in una raccolta.`],
    [`Les retraits et les rangements partent à TikTok tout seuls, en arrière-plan.`, `Removals and filing are sent to TikTok automatically, in the background.`, `Las eliminaciones y los cambios de colección se envían a TikTok solos, en segundo plano.`, `Entfernen und Ablegen werden automatisch im Hintergrund an TikTok gesendet.`, `As remoções e as coleções são enviadas ao TikTok sozinhas, em segundo plano.`, `Rimozioni e inserimenti partono verso TikTok da soli, in background.`],
    [`Autre méthode : importer l'export JSON de TikTok (Paramètres → Compte → Télécharger tes données).`, `Other method: import the JSON export from TikTok (Settings → Account → Download your data).`, `Otro método: importar la exportación JSON de TikTok (Ajustes → Cuenta → Descargar tus datos).`, `Andere Methode: den JSON-Export von TikTok importieren (Einstellungen → Konto → Deine Daten herunterladen).`, `Outro método: importar a exportação JSON do TikTok (Configurações → Conta → Baixar seus dados).`, `Altro metodo: importa l'esportazione JSON di TikTok (Impostazioni → Account → Scarica i tuoi dati).`],
    [`↻ Reprendre l'importation (# / #)`, `↻ Resume the import ($1 / $2)`, `↻ Reanudar la importación ($1 / $2)`, `↻ Import fortsetzen ($1 / $2)`, `↻ Retomar a importação ($1 / $2)`, `↻ Riprendi l'importazione ($1 / $2)`],
    [`↻ Reprendre l'import (# / #)`, `↻ Resume the import ($1 / $2)`, `↻ Reanudar la importación ($1 / $2)`, `↻ Import fortsetzen ($1 / $2)`, `↻ Retomar a importação ($1 / $2)`, `↻ Riprendi l'importazione ($1 / $2)`],
    [`Importer depuis mon profil TikTok`, `Import from my TikTok profile`, `Importar desde mi perfil de TikTok`, `Aus meinem TikTok-Profil importieren`, `Importar do meu perfil do TikTok`, `Importa dal mio profilo TikTok`],
    [`Importer l'export JSON`, `Import the JSON export`, `Importar la exportación JSON`, `JSON-Export importieren`, `Importar a exportação JSON`, `Importa l'esportazione JSON`],
    [`⇄ Synchroniser les collections (#)`, `⇄ Sync collections ($1)`, `⇄ Sincronizar colecciones ($1)`, `⇄ Sammlungen synchronisieren ($1)`, `⇄ Sincronizar coleções ($1)`, `⇄ Sincronizza raccolte ($1)`],
    [`⏳ Synchronisation…`, `⏳ Syncing…`, `⏳ Sincronizando…`, `⏳ Synchronisierung…`, `⏳ Sincronizando…`, `⏳ Sincronizzazione…`],
    [`« Depuis mon profil » lit ton onglet Favoris (défilement automatique). L'export JSON s'obtient dans TikTok : Paramètres → Compte → Télécharger tes données.`, `"From my profile" reads your Favorites tab (automatic scrolling). The JSON export comes from TikTok: Settings → Account → Download your data.`, `«Desde mi perfil» lee tu pestaña Favoritos (desplazamiento automático). La exportación JSON se obtiene en TikTok: Ajustes → Cuenta → Descargar tus datos.`, `„Aus meinem Profil“ liest deinen Favoriten-Tab (automatisches Scrollen). Den JSON-Export bekommst du in TikTok: Einstellungen → Konto → Deine Daten herunterladen.`, `"Do meu perfil" lê sua aba Favoritos (rolagem automática). A exportação JSON fica no TikTok: Configurações → Conta → Baixar seus dados.`, `«Dal mio profilo» legge la tua scheda Preferiti (scorrimento automatico). L'esportazione JSON si ottiene in TikTok: Impostazioni → Account → Scarica i tuoi dati.`],
    [`Outil non officiel, non affilié à TikTok. TikTok interdit l'automatisation : ton compte peut être limité, suspendu ou banni définitivement.`, `Unofficial tool, not affiliated with TikTok. TikTok prohibits automation: your account may be limited, suspended or permanently banned.`, `Herramienta no oficial, no afiliada a TikTok. TikTok prohíbe la automatización: tu cuenta puede ser limitada, suspendida o bloqueada para siempre.`, `Inoffizielles Tool, nicht mit TikTok verbunden. TikTok verbietet Automatisierung: Dein Konto kann eingeschränkt, gesperrt oder dauerhaft gebannt werden.`, `Ferramenta não oficial, sem vínculo com o TikTok. O TikTok proíbe automação: sua conta pode ser limitada, suspensa ou banida para sempre.`, `Strumento non ufficiale, non affiliato a TikTok. TikTok vieta l'automazione: il tuo account può essere limitato, sospeso o bannato per sempre.`],
    [`Envoie tes rangements et retraits de collections à TikTok`, `Sends your filing and collection removals to TikTok`, `Envía a TikTok tus cambios de colección`, `Sendet deine Sammlungsänderungen an TikTok`, `Envia ao TikTok suas mudanças de coleção`, `Invia a TikTok le modifiche alle raccolte`],
    [`🔍 Chercher une collection…`, `🔍 Search a collection…`, `🔍 Buscar una colección…`, `🔍 Sammlung suchen…`, `🔍 Procurar uma coleção…`, `🔍 Cerca una raccolta…`],
    [`＋ Nouvelle collection`, `＋ New collection`, `＋ Nueva colección`, `＋ Neue Sammlung`, `＋ Nova coleção`, `＋ Nuova raccolta`],
    [`# à trier`, `$1 to sort`, `$1 por ordenar`, `$1 zu sortieren`, `$1 para organizar`, `$1 da ordinare`],
    [`Lit ton onglet Favoris sur TikTok. Les vidéos déjà importées ne sont pas dupliquées : ça reprend un import interrompu ou récupère les nouveaux favoris.`, `Reads your Favorites tab on TikTok. Videos already imported are not duplicated: this resumes an interrupted import or fetches new favorites.`, `Lee tu pestaña Favoritos en TikTok. Los vídeos ya importados no se duplican: reanuda una importación interrumpida o recupera los favoritos nuevos.`, `Liest deinen Favoriten-Tab auf TikTok. Bereits importierte Videos werden nicht doppelt angelegt: So wird ein unterbrochener Import fortgesetzt oder neue Favoriten werden geholt.`, `Lê sua aba Favoritos no TikTok. Vídeos já importados não são duplicados: retoma uma importação interrompida ou pega os favoritos novos.`, `Legge la tua scheda Preferiti su TikTok. I video già importati non vengono duplicati: riprende un'importazione interrotta o recupera i nuovi preferiti.`],
    [`↻ Importer les nouveaux favoris (rapide)`, `↻ Import new favorites (fast)`, `↻ Importar favoritos nuevos (rápido)`, `↻ Neue Favoriten importieren (schnell)`, `↻ Importar favoritos novos (rápido)`, `↻ Importa i nuovi preferiti (veloce)`],
    [`↻ Importer les nouveaux favoris`, `↻ Import new favorites`, `↻ Importar favoritos nuevos`, `↻ Neue Favoriten importieren`, `↻ Importar favoritos novos`, `↻ Importa i nuovi preferiti`],
    [`GARDER`, `KEEP`, `CONSERVAR`, `BEHALTEN`, `MANTER`, `TIENI`],
    [`RETIRER`, `REMOVE`, `QUITAR`, `ENTFERNEN`, `REMOVER`, `RIMUOVI`],
    [`📁 RANGER`, `📁 FILE`, `📁 A COLECCIÓN`, `📁 ABLEGEN`, `📁 COLEÇÃO`, `📁 RACCOLTA`],
    [`Garder (#)`, `Keep ($1)`, `Conservar ($1)`, `Behalten ($1)`, `Manter ($1)`, `Tieni ($1)`],
    [`Garder (←)`, `Keep (←)`, `Conservar (←)`, `Behalten (←)`, `Manter (←)`, `Tieni (←)`],
    [`Garder (→)`, `Keep (→)`, `Conservar (→)`, `Behalten (→)`, `Manter (→)`, `Tieni (→)`],
    [`Collection (↑)`, `Collection (↑)`, `Colección (↑)`, `Sammlung (↑)`, `Coleção (↑)`, `Raccolta (↑)`],
    [`Retirer des favoris (←)`, `Remove from favorites (←)`, `Quitar de favoritos (←)`, `Aus Favoriten entfernen (←)`, `Remover dos favoritos (←)`, `Rimuovi dai preferiti (←)`],
    [`Retirer des favoris (→)`, `Remove from favorites (→)`, `Quitar de favoritos (→)`, `Aus Favoriten entfernen (→)`, `Remover dos favoritos (→)`, `Rimuovi dai preferiti (→)`],
    [`Annuler (Z)`, `Undo (Z)`, `Deshacer (Z)`, `Rückgängig (Z)`, `Desfazer (Z)`, `Annulla (Z)`],
    [`← retirer des favoris · → garder`, `← remove from favorites · → keep`, `← quitar de favoritos · → conservar`, `← aus Favoriten entfernen · → behalten`, `← remover dos favoritos · → manter`, `← rimuovi dai preferiti · → tieni`],
    [`← garder · → retirer des favoris`, `← keep · → remove from favorites`, `← conservar · → quitar de favoritos`, `← behalten · → aus Favoriten entfernen`, `← manter · → remover dos favoritos`, `← tieni · → rimuovi dai preferiti`],
    [`· ↑ ranger · touches 1-9 : collection numérotée. Glisse la carte de n'importe où ; ▶ au centre pour lire. Dépose-la sur une collection pour la ranger.`, `· ↑ file · keys 1-9: numbered collection. Drag the card from anywhere; ▶ in the middle to play. Drop it on a collection to file it.`, `· ↑ a colección · teclas 1-9: colección numerada. Arrastra la tarjeta desde cualquier punto; ▶ en el centro para reproducir. Suéltala sobre una colección para moverla allí.`, `· ↑ ablegen · Tasten 1-9: nummerierte Sammlung. Zieh die Karte von überall; ▶ in der Mitte zum Abspielen. Leg sie auf einer Sammlung ab, um sie dort abzulegen.`, `· ↑ coleção · teclas 1-9: coleção numerada. Arraste o cartão de qualquer ponto; ▶ no centro para tocar. Solte-o sobre uma coleção para colocá-lo nela.`, `· ↑ raccolta · tasti 1-9: raccolta numerata. Trascina la scheda da qualsiasi punto; ▶ al centro per riprodurre. Rilasciala su una raccolta per inserirla.`],
    [`Désépingler`, `Unpin`, `Desfijar`, `Lösen`, `Desafixar`, `Sblocca`],
    [`Épingler en haut`, `Pin to top`, `Fijar arriba`, `Oben anheften`, `Fixar no topo`, `Fissa in alto`],
    // ── Gardés
    [`# sélectionnée(s)`, `$1 selected`, `$1 seleccionado(s)`, `$1 ausgewählt`, `$1 selecionado(s)`, `$1 selezionato/i`],
    [`Tout sélectionner (#)`, `Select all ($1)`, `Seleccionar todo ($1)`, `Alle auswählen ($1)`, `Selecionar tudo ($1)`, `Seleziona tutto ($1)`],
    [`📁 Ranger dans…`, `📁 File into…`, `📁 Mover a…`, `📁 Ablegen in…`, `📁 Colocar em…`, `📁 Metti in…`],
    [`🗑 Retirer des favoris`, `🗑 Remove from favorites`, `🗑 Quitar de favoritos`, `🗑 Aus Favoriten entfernen`, `🗑 Remover dos favoritos`, `🗑 Rimuovi dai preferiti`],
    [`Terminer`, `Done`, `Terminar`, `Fertig`, `Concluir`, `Fine`],
    [`☑ Sélectionner plusieurs vidéos`, `☑ Select several videos`, `☑ Seleccionar varios vídeos`, `☑ Mehrere Videos auswählen`, `☑ Selecionar vários vídeos`, `☑ Seleziona più video`],
    [`# gardées`, `$1 kept`, `$1 conservados`, `$1 behalten`, `$1 mantidos`, `$1 tenuti`],
    [`Rien de gardé pour l'instant.`, `Nothing kept yet.`, `Nada conservado todavía.`, `Noch nichts behalten.`, `Nada mantido ainda.`, `Ancora niente di tenuto.`],
    [`Afficher plus (# restantes)`, `Show more ($1 left)`, `Mostrar más (quedan $1)`, `Mehr anzeigen ($1 übrig)`, `Mostrar mais (faltam $1)`, `Mostra altro ($1 rimanenti)`],
    [`Remettre dans la pile`, `Put back in the deck`, `Devolver a la pila`, `Zurück in den Stapel`, `Devolver à pilha`, `Rimetti nel mazzo`],
    [`Sortir de la collection (reste dans les favoris)`, `Take out of the collection (stays in favorites)`, `Sacar de la colección (sigue en favoritos)`, `Aus der Sammlung nehmen (bleibt in den Favoriten)`, `Tirar da coleção (continua nos favoritos)`, `Togli dalla raccolta (resta nei preferiti)`],
    [`Retirer des favoris TikTok`, `Remove from TikTok favorites`, `Quitar de favoritos de TikTok`, `Aus TikTok-Favoriten entfernen`, `Remover dos favoritos do TikTok`, `Rimuovi dai preferiti di TikTok`],
    [`# vidéo(s) rangée(s) dans « ¤ »`, `$1 video(s) filed in "$2"`, `$1 vídeo(s) movido(s) a «$2»`, `$1 Video(s) in „$2“ abgelegt`, `$1 vídeo(s) colocado(s) em "$2"`, `$1 video inserito/i in «$2»`],
    [`# retrait(s) mis en file`, `$1 removal(s) queued`, `$1 eliminación(es) en cola`, `$1 Entfernung(en) eingereiht`, `$1 remoção(ões) na fila`, `$1 rimozione/i in coda`],
    [`Retirer # vidéo(s) de tes favoris TikTok (automatiquement, en arrière-plan) ?`, `Remove $1 video(s) from your TikTok favorites (automatically, in the background)?`, `¿Quitar $1 vídeo(s) de tus favoritos de TikTok (automáticamente, en segundo plano)?`, `$1 Video(s) aus deinen TikTok-Favoriten entfernen (automatisch, im Hintergrund)?`, `Remover $1 vídeo(s) dos seus favoritos do TikTok (automaticamente, em segundo plano)?`, `Rimuovere $1 video dai tuoi preferiti di TikTok (automaticamente, in background)?`],
    // ── Collections
    [`# à ranger sur TikTok`, `$1 to file on TikTok`, `$1 por enviar a TikTok`, `$1 auf TikTok abzulegen`, `$1 para enviar ao TikTok`, `$1 da inserire su TikTok`],
    [`Tout est rangé sur TikTok`, `Everything is filed on TikTok`, `Todo está en su colección en TikTok`, `Alles ist auf TikTok abgelegt`, `Tudo está na coleção no TikTok`, `Tutto è nelle raccolte su TikTok`],
    [`Synchronisation…`, `Syncing…`, `Sincronizando…`, `Synchronisierung…`, `Sincronizando…`, `Sincronizzazione…`],
    [`Synchroniser maintenant`, `Sync now`, `Sincronizar ahora`, `Jetzt synchronisieren`, `Sincronizar agora`, `Sincronizza ora`],
    [`Le rangement part tout seul quelques secondes après chaque glissement. ⊖ sort la vidéo de la collection, 🗑 la retire des favoris.`, `Filing is sent automatically a few seconds after each swipe. ⊖ takes the video out of the collection, 🗑 removes it from favorites.`, `El cambio se envía solo unos segundos después de cada deslizamiento. ⊖ saca el vídeo de la colección, 🗑 lo quita de favoritos.`, `Das Ablegen wird ein paar Sekunden nach jedem Wischen automatisch gesendet. ⊖ nimmt das Video aus der Sammlung, 🗑 entfernt es aus den Favoriten.`, `A coleção é enviada sozinha alguns segundos após cada deslize. ⊖ tira o vídeo da coleção, 🗑 remove dos favoritos.`, `L'inserimento parte da solo qualche secondo dopo ogni scorrimento. ⊖ toglie il video dalla raccolta, 🗑 lo rimuove dai preferiti.`],
    [`Renommer`, `Rename`, `Renombrar`, `Umbenennen`, `Renomear`, `Rinomina`],
    [`Aucune collection. Glisse une vidéo vers le haut pour en créer une.`, `No collection yet. Swipe a video up to create one.`, `Aún no hay colecciones. Desliza un vídeo hacia arriba para crear una.`, `Noch keine Sammlung. Wisch ein Video nach oben, um eine zu erstellen.`, `Nenhuma coleção ainda. Deslize um vídeo para cima para criar uma.`, `Nessuna raccolta. Scorri un video verso l'alto per crearne una.`],
    [`↻ Relire mes collections TikTok`, `↻ Re-read my TikTok collections`, `↻ Releer mis colecciones de TikTok`, `↻ Meine TikTok-Sammlungen neu lesen`, `↻ Reler minhas coleções do TikTok`, `↻ Rileggi le mie raccolte TikTok`],
    [`Cette collection existe déjà sur TikTok : renomme-la dans TikTok (⋯ → Changer de nom), puis clique sur « Relire mes collections TikTok ».`, `This collection already exists on TikTok: rename it in TikTok (⋯ → Rename), then click "Re-read my TikTok collections".`, `Esta colección ya existe en TikTok: cámbiale el nombre en TikTok (⋯ → Cambiar nombre) y luego haz clic en «Releer mis colecciones de TikTok».`, `Diese Sammlung gibt es schon auf TikTok: Benenne sie in TikTok um (⋯ → Umbenennen) und klick dann auf „Meine TikTok-Sammlungen neu lesen“.`, `Essa coleção já existe no TikTok: renomeie no TikTok (⋯ → Renomear) e depois clique em "Reler minhas coleções do TikTok".`, `Questa raccolta esiste già su TikTok: rinominala in TikTok (⋯ → Rinomina), poi clicca su «Rileggi le mie raccolte TikTok».`],
    [`Nouveau nom pour « ¤ » :`, `New name for "$1":`, `Nuevo nombre para «$1»:`, `Neuer Name für „$1“:`, `Novo nome para "$1":`, `Nuovo nome per «$1»:`],
    [`Une collection porte déjà ce nom.`, `A collection already has this name.`, `Ya hay una colección con ese nombre.`, `Es gibt schon eine Sammlung mit diesem Namen.`, `Já existe uma coleção com esse nome.`, `Esiste già una raccolta con questo nome.`],
    // ── Retirés
    [`⏳ en attente`, `⏳ pending`, `⏳ pendiente`, `⏳ wartend`, `⏳ pendente`, `⏳ in attesa`],
    [`⏳ en cours`, `⏳ in progress`, `⏳ en curso`, `⏳ läuft`, `⏳ em andamento`, `⏳ in corso`],
    [`✓ retiré`, `✓ removed`, `✓ quitado`, `✓ entfernt`, `✓ removido`, `✓ rimosso`],
    [`✓ à vérifier`, `✓ to check`, `✓ por comprobar`, `✓ zu prüfen`, `✓ a verificar`, `✓ da verificare`],
    [`⚠ échec`, `⚠ failed`, `⚠ error`, `⚠ fehlgeschlagen`, `⚠ falhou`, `⚠ non riuscito`],
    [`# retirées · # en attente`, `$1 removed · $2 pending`, `$1 quitados · $2 pendientes`, `$1 entfernt · $2 wartend`, `$1 removidos · $2 pendentes`, `$1 rimossi · $2 in attesa`],
    [`Aucune vidéo retirée.`, `No video removed.`, `Ningún vídeo quitado.`, `Kein Video entfernt.`, `Nenhum vídeo removido.`, `Nessun video rimosso.`],
    // ── fenêtre « Ranger dans une collection »
    [`Ranger dans une collection`, `File into a collection`, `Mover a una colección`, `In eine Sammlung ablegen`, `Colocar em uma coleção`, `Metti in una raccolta`],
    [`Nouvelle collection…`, `New collection…`, `Nueva colección…`, `Neue Sammlung…`, `Nova coleção…`, `Nuova raccolta…`],
    [`Créer et ranger`, `Create and file`, `Crear y mover`, `Erstellen und ablegen`, `Criar e colocar`, `Crea e inserisci`],
    [`Annuler`, `Cancel`, `Cancelar`, `Abbrechen`, `Cancelar`, `Annulla`],
    // ── barre d'annulation, undo
    [`🗑 Retirée de tes favoris`, `🗑 Removed from your favorites`, `🗑 Quitado de tus favoritos`, `🗑 Aus deinen Favoriten entfernt`, `🗑 Removido dos seus favoritos`, `🗑 Rimosso dai tuoi preferiti`],
    [`↺ Annuler (# s)`, `↺ Undo ($1 s)`, `↺ Deshacer ($1 s)`, `↺ Rückgängig ($1 s)`, `↺ Desfazer ($1 s)`, `↺ Annulla ($1 s)`],
    [`Déjà parti : impossible d'annuler.`, `Already sent: cannot undo.`, `Ya enviado: no se puede deshacer.`, `Schon gesendet: nicht rückgängig zu machen.`, `Já enviado: não dá para desfazer.`, `Già inviato: impossibile annullare.`],
    [`Rien à annuler`, `Nothing to undo`, `Nada que deshacer`, `Nichts rückgängig zu machen`, `Nada para desfazer`, `Niente da annullare`],
    [`Déjà retiré de TikTok, impossible d'annuler`, `Already removed from TikTok, cannot undo`, `Ya quitado de TikTok, no se puede deshacer`, `Schon von TikTok entfernt, nicht rückgängig zu machen`, `Já removido do TikTok, não dá para desfazer`, `Già rimosso da TikTok, impossibile annullare`],
    // ── menu des comptes
    [`Compte actuel : ¤`, `Current account: $1`, `Cuenta actual: $1`, `Aktuelles Konto: $1`, `Conta atual: $1`, `Account attuale: $1`],
    [`# vidéos ici · # mises de côté`, `$1 videos here · $2 set aside`, `$1 vídeos aquí · $2 apartados`, `$1 Videos hier · $2 beiseitegelegt`, `$1 vídeos aqui · $2 guardados à parte`, `$1 video qui · $2 messi da parte`],
    [`📤 Mettre de côté les données de ce compte`, `📤 Set this account's data aside`, `📤 Apartar los datos de esta cuenta`, `📤 Daten dieses Kontos beiseitelegen`, `📤 Guardar à parte os dados desta conta`, `📤 Metti da parte i dati di questo account`],
    [`📥 Reprendre les données mises de côté (#)`, `📥 Take back the data set aside ($1)`, `📥 Recuperar los datos apartados ($1)`, `📥 Beiseitegelegte Daten übernehmen ($1)`, `📥 Recuperar os dados guardados à parte ($1)`, `📥 Riprendi i dati messi da parte ($1)`],
    [`⚙ Réglages (délais, sens des gestes)`, `⚙ Settings (delays, swipe direction)`, `⚙ Ajustes (tiempos, sentido de los gestos)`, `⚙ Einstellungen (Wartezeiten, Wischrichtung)`, `⚙ Configurações (tempos, direção dos gestos)`, `⚙ Impostazioni (tempi, direzione dei gesti)`],
    [`⬇ Exporter mes données (sauvegarde)`, `⬇ Export my data (backup)`, `⬇ Exportar mis datos (copia de seguridad)`, `⬇ Meine Daten exportieren (Sicherung)`, `⬇ Exportar meus dados (backup)`, `⬇ Esporta i miei dati (backup)`],
    [`⬆ Restaurer une sauvegarde`, `⬆ Restore a backup`, `⬆ Restaurar una copia de seguridad`, `⬆ Sicherung wiederherstellen`, `⬆ Restaurar um backup`, `⬆ Ripristina un backup`],
    [`🗑 Tout réinitialiser (comme une nouvelle installation)`, `🗑 Reset everything (like a fresh install)`, `🗑 Restablecer todo (como una instalación nueva)`, `🗑 Alles zurücksetzen (wie eine Neuinstallation)`, `🗑 Redefinir tudo (como uma instalação nova)`, `🗑 Reimposta tutto (come una nuova installazione)`],
    [`Remplacer les # vidéos déjà mises de côté ?`, `Replace the $1 videos already set aside?`, `¿Reemplazar los $1 vídeos ya apartados?`, `Die $1 schon beiseitegelegten Videos ersetzen?`, `Substituir os $1 vídeos já guardados à parte?`, `Sostituire i $1 video già messi da parte?`],
    [`Données mises de côté. Ouvre l'autre compte pour les reprendre.`, `Data set aside. Open the other account to take it back.`, `Datos apartados. Abre la otra cuenta para recuperarlos.`, `Daten beiseitegelegt. Öffne das andere Konto, um sie zu übernehmen.`, `Dados guardados à parte. Abra a outra conta para recuperá-los.`, `Dati messi da parte. Apri l'altro account per riprenderli.`],
    [`Tout réinitialiser ?`, `Reset everything?`, `¿Restablecer todo?`, `Alles zurücksetzen?`, `Redefinir tudo?`, `Reimpostare tutto?`],
    [`Cela efface, pour TOUS les comptes, ton tri, tes collections locales, les données mises de côté et la file des retraits en attente.`, `This erases, for ALL accounts, your sorting, your local collections, the data set aside and the queue of pending removals.`, `Esto borra, para TODAS las cuentas, tu orden, tus colecciones locales, los datos apartados y la cola de eliminaciones pendientes.`, `Das löscht für ALLE Konten deine Sortierung, deine lokalen Sammlungen, die beiseitegelegten Daten und die Warteschlange der ausstehenden Entfernungen.`, `Isso apaga, para TODAS as contas, sua organização, suas coleções locais, os dados guardados à parte e a fila de remoções pendentes.`, `Questo cancella, per TUTTI gli account, il tuo ordinamento, le raccolte locali, i dati messi da parte e la coda delle rimozioni in attesa.`],
    [`Rien n'est modifié sur TikTok : tes favoris et tes collections TikTok restent intacts.`, `Nothing is changed on TikTok: your TikTok favorites and collections stay intact.`, `No se cambia nada en TikTok: tus favoritos y colecciones de TikTok quedan intactos.`, `Auf TikTok wird nichts geändert: Deine TikTok-Favoriten und -Sammlungen bleiben unverändert.`, `Nada muda no TikTok: seus favoritos e coleções do TikTok continuam intactos.`, `Su TikTok non cambia nulla: i tuoi preferiti e le tue raccolte TikTok restano intatti.`],
    [`Dernière confirmation : repartir de zéro ?`, `Last confirmation: start from scratch?`, `Última confirmación: ¿empezar de cero?`, `Letzte Bestätigung: von vorn anfangen?`, `Última confirmação: começar do zero?`, `Ultima conferma: ripartire da zero?`],
    [`Extension réinitialisée : tout repart de zéro.`, `Extension reset: everything starts from scratch.`, `Extensión restablecida: todo empieza de cero.`, `Erweiterung zurückgesetzt: Alles beginnt von vorn.`, `Extensão redefinida: tudo começa do zero.`, `Estensione reimpostata: si riparte da zero.`],
    [`Remplacer les # vidéos de ¤ par celles mises de côté ?`, `Replace the $1 videos of $2 with the ones set aside?`, `¿Reemplazar los $1 vídeos de $2 por los apartados?`, `Die $1 Videos von $2 durch die beiseitegelegten ersetzen?`, `Substituir os $1 vídeos de $2 pelos guardados à parte?`, `Sostituire i $1 video di $2 con quelli messi da parte?`],
    [`Données reprises pour ¤`, `Data taken back for $1`, `Datos recuperados para $1`, `Daten übernommen für $1`, `Dados recuperados para $1`, `Dati ripresi per $1`],
    [`Des favoris triés avant la séparation par compte ont été trouvés. Les reprendre pour ¤ ?`, `Favorites sorted before the per-account separation were found. Take them back for $1?`, `Se encontraron favoritos ordenados antes de separar por cuenta. ¿Recuperarlos para $1?`, `Es wurden Favoriten gefunden, die vor der Trennung nach Konten sortiert wurden. Für $1 übernehmen?`, `Foram encontrados favoritos organizados antes da separação por conta. Recuperá-los para $1?`, `Sono stati trovati preferiti ordinati prima della separazione per account. Riprenderli per $1?`],
    // ── avertissement de risque
    [`⚠ Avant de continuer`, `⚠ Before you continue`, `⚠ Antes de continuar`, `⚠ Bevor du weitermachst`, `⚠ Antes de continuar`, `⚠ Prima di continuare`],
    [`Cet outil pilote TikTok à ta place : clics, défilement, ouverture de vidéos en arrière-plan.`, `This tool drives TikTok for you: clicks, scrolling, opening videos in the background.`, `Esta herramienta maneja TikTok por ti: clics, desplazamiento, apertura de vídeos en segundo plano.`, `Dieses Tool bedient TikTok für dich: Klicks, Scrollen, Öffnen von Videos im Hintergrund.`, `Esta ferramenta controla o TikTok por você: cliques, rolagem, abertura de vídeos em segundo plano.`, `Questo strumento usa TikTok al posto tuo: clic, scorrimento, apertura di video in background.`],
    [`TikTok interdit l'automatisation dans ses conditions d'utilisation.`, `TikTok prohibits automation in its terms of use.`, `TikTok prohíbe la automatización en sus condiciones de uso.`, `TikTok verbietet Automatisierung in seinen Nutzungsbedingungen.`, `O TikTok proíbe automação nos termos de uso.`, `TikTok vieta l'automazione nei suoi termini d'uso.`],
    [`Ton compte peut être`, `Your account may be`, `Tu cuenta puede ser`, `Dein Konto kann`, `Sua conta pode ser`, `Il tuo account può essere`],
    [`limité, suspendu ou banni définitivement`, `limited, suspended or permanently banned`, `limitada, suspendida o bloqueada para siempre`, `eingeschränkt, gesperrt oder dauerhaft gebannt werden`, `limitada, suspensa ou banida para sempre`, `limitato, sospeso o bannato per sempre`],
    [`même avec des pauses entre les actions. Ce risque existe et personne ne peut le supprimer.`, `even with pauses between actions. This risk exists and nobody can remove it.`, `incluso con pausas entre acciones. Este riesgo existe y nadie puede eliminarlo.`, `– auch mit Pausen zwischen den Aktionen. Dieses Risiko besteht und niemand kann es beseitigen.`, `mesmo com pausas entre as ações. Esse risco existe e ninguém pode eliminá-lo.`, `anche con pause tra le azioni. Questo rischio esiste e nessuno può eliminarlo.`],
    [`Tu utilises l'extension`, `You use the extension`, `Usas la extensión`, `Du nutzt die Erweiterung`, `Você usa a extensão`, `Usi l'estensione`],
    [`à tes propres risques`, `at your own risk`, `bajo tu propia responsabilidad`, `auf eigenes Risiko`, `por sua conta e risco`, `a tuo rischio`],
    [`Elle n'est pas affiliée à TikTok et son auteur n'est pas responsable des sanctions prises contre ton compte. Conseils : petits lots, rythme prudent, teste d'abord sur un compte secondaire.`, `It is not affiliated with TikTok and its author is not responsible for penalties taken against your account. Tips: small batches, a cautious pace, and try a secondary account first.`, `No está afiliada a TikTok y su autor no es responsable de las sanciones contra tu cuenta. Consejos: lotes pequeños, ritmo prudente y prueba primero con una cuenta secundaria.`, `Sie ist nicht mit TikTok verbunden, und ihr Autor haftet nicht für Sanktionen gegen dein Konto. Tipps: kleine Mengen, vorsichtiges Tempo, zuerst mit einem Zweitkonto testen.`, `Ela não tem vínculo com o TikTok e o autor não é responsável por punições contra sua conta. Dicas: lotes pequenos, ritmo cauteloso e teste primeiro numa conta secundária.`, `Non è affiliata a TikTok e il suo autore non è responsabile delle sanzioni contro il tuo account. Consigli: piccoli lotti, ritmo prudente, prova prima con un account secondario.`],
    [`Je comprends que mon compte TikTok peut être suspendu ou banni, et j'accepte ce risque.`, `I understand that my TikTok account may be suspended or banned, and I accept this risk.`, `Entiendo que mi cuenta de TikTok puede ser suspendida o bloqueada, y acepto este riesgo.`, `Ich verstehe, dass mein TikTok-Konto gesperrt oder gebannt werden kann, und akzeptiere dieses Risiko.`, `Entendo que minha conta do TikTok pode ser suspensa ou banida e aceito esse risco.`, `Capisco che il mio account TikTok può essere sospeso o bannato e accetto questo rischio.`],
    [`J'accepte et je continue`, `I accept and continue`, `Acepto y continúo`, `Ich akzeptiere und mache weiter`, `Aceito e continuo`, `Accetto e continuo`],
    [`⚠ Avertissement`, `⚠ Warning`, `⚠ Advertencia`, `⚠ Warnung`, `⚠ Aviso`, `⚠ Avvertenza`],
    [`Utilisation à tes propres risques ; fais des pauses et de petits lots.`, `Use at your own risk; take breaks and work in small batches.`, `Uso bajo tu propia responsabilidad; haz pausas y lotes pequeños.`, `Nutzung auf eigenes Risiko; mach Pausen und arbeite in kleinen Mengen.`, `Uso por sua conta e risco; faça pausas e lotes pequenos.`, `Uso a tuo rischio; fai pause e piccoli lotti.`],
    // ── dons
    [`☕ Soutenir le projet`, `☕ Support the project`, `☕ Apoyar el proyecto`, `☕ Projekt unterstützen`, `☕ Apoiar o projeto`, `☕ Sostieni il progetto`],
    [`L'extension est faite et entretenue par une seule personne. Si elle te fait gagner du temps, un don, même petit, aide à la garder à jour quand TikTok change.`, `The extension is made and maintained by one person. If it saves you time, even a small donation helps keep it up to date when TikTok changes.`, `La extensión la hace y mantiene una sola persona. Si te ahorra tiempo, una donación, aunque sea pequeña, ayuda a mantenerla al día cuando TikTok cambia.`, `Die Erweiterung wird von einer einzigen Person gemacht und gepflegt. Wenn sie dir Zeit spart, hilft schon eine kleine Spende, sie aktuell zu halten, wenn sich TikTok ändert.`, `A extensão é feita e mantida por uma só pessoa. Se ela economiza seu tempo, uma doação, mesmo pequena, ajuda a mantê-la atualizada quando o TikTok muda.`, `L'estensione è fatta e mantenuta da una sola persona. Se ti fa risparmiare tempo, una donazione, anche piccola, aiuta a tenerla aggiornata quando TikTok cambia.`],
    [`☕ Faire un don`, `☕ Donate`, `☕ Donar`, `☕ Spenden`, `☕ Doar`, `☕ Fai una donazione`],
    // ── version gratuite / Pro
    [`Limite gratuite atteinte : # retraits par jour. Clique sur « ⭐ Passer en Pro » en haut (¤).`, `Free limit reached: $1 removals per day. Click "⭐ Go Pro" at the top ($2).`, `Límite gratuito alcanzado: $1 eliminaciones al día. Haz clic en «⭐ Pasar a Pro» arriba ($2).`, `Gratis-Limit erreicht: $1 Entfernungen pro Tag. Klick oben auf „⭐ Pro holen“ ($2).`, `Limite grátis atingido: $1 remoções por dia. Clique em "⭐ Obter o Pro" no topo ($2).`, `Limite gratuito raggiunto: $1 rimozioni al giorno. Clicca su «⭐ Passa a Pro» in alto ($2).`],
    [`Fonction réservée à la version Pro (¤). Clique sur « ⭐ Passer en Pro » en haut.`, `Feature reserved for the Pro version ($1). Click "⭐ Go Pro" at the top.`, `Función reservada a la versión Pro ($1). Haz clic en «⭐ Pasar a Pro» arriba.`, `Funktion nur in der Pro-Version ($1). Klick oben auf „⭐ Pro holen“.`, `Recurso exclusivo da versão Pro ($1). Clique em "⭐ Obter o Pro" no topo.`, `Funzione riservata alla versione Pro ($1). Clicca su «⭐ Passa a Pro» in alto.`],
    [`⭐ Version`, `⭐ Version`, `⭐ Versión`, `⭐ Version`, `⭐ Versão`, `⭐ Versione`],
    [`Mode développement : tout est débloqué (aucune boutique configurée dans config.js).`, `Development mode: everything is unlocked (no store set up in config.js).`, `Modo desarrollo: todo está desbloqueado (ninguna tienda configurada en config.js).`, `Entwicklungsmodus: Alles ist freigeschaltet (kein Shop in config.js eingerichtet).`, `Modo de desenvolvimento: tudo está liberado (nenhuma loja configurada em config.js).`, `Modalità sviluppo: tutto è sbloccato (nessun negozio configurato in config.js).`],
    [`⭐ Pro activée`, `⭐ Pro activated`, `⭐ Pro activado`, `⭐ Pro aktiviert`, `⭐ Pro ativado`, `⭐ Pro attivato`],
    [`Merci !`, `Thank you!`, `¡Gracias!`, `Danke!`, `Obrigado!`, `Grazie!`],
    [`clé ¤ · retraits illimités et onglets en parallèle.`, `key $1 · unlimited removals and parallel tabs.`, `clave $1 · eliminaciones ilimitadas y pestañas en paralelo.`, `Schlüssel $1 · unbegrenztes Entfernen und parallele Tabs.`, `chave $1 · remoções ilimitadas e abas em paralelo.`, `chiave $1 · rimozioni illimitate e schede in parallelo.`],
    [`Désactiver sur cet ordinateur`, `Deactivate on this computer`, `Desactivar en este ordenador`, `Auf diesem Computer deaktivieren`, `Desativar neste computador`, `Disattiva su questo computer`],
    [`⭐ Version gratuite`, `⭐ Free version`, `⭐ Versión gratuita`, `⭐ Kostenlose Version`, `⭐ Versão grátis`, `⭐ Versione gratuita`],
    [`Retraits aujourd'hui :`, `Removals today:`, `Eliminaciones hoy:`, `Entfernungen heute:`, `Remoções hoje:`, `Rimozioni oggi:`],
    [`1 onglet de retrait`, `1 removal tab`, `1 pestaña de eliminación`, `1 Tab zum Entfernen`, `1 aba de remoção`, `1 scheda di rimozione`],
    [`Passer en Pro : ¤ (achat unique)`, `Go Pro: $1 (one-time purchase)`, `Pasar a Pro: $1 (compra única)`, `Pro holen: $1 (einmaliger Kauf)`, `Obter o Pro: $1 (compra única)`, `Passa a Pro: $1 (acquisto unico)`],
    [`Pro : retraits illimités, jusqu'à 3 onglets en parallèle avec chargement allégé (plus rapide).`, `Pro: unlimited removals, up to 3 parallel tabs with lighter loading (faster).`, `Pro: eliminaciones ilimitadas, hasta 3 pestañas en paralelo con carga ligera (más rápido).`, `Pro: unbegrenztes Entfernen, bis zu 3 parallele Tabs mit leichterem Laden (schneller).`, `Pro: remoções ilimitadas, até 3 abas em paralelo com carregamento leve (mais rápido).`, `Pro: rimozioni illimitate, fino a 3 schede in parallelo con caricamento alleggerito (più veloce).`],
    [`Clé de licence reçue par e-mail`, `License key received by e-mail`, `Clave de licencia recibida por correo`, `Per E-Mail erhaltener Lizenzschlüssel`, `Chave de licença recebida por e-mail`, `Chiave di licenza ricevuta via e-mail`],
    [`Activer`, `Activate`, `Activar`, `Aktivieren`, `Ativar`, `Attiva`],
    [`Page d'achat non configurée.`, `Purchase page not set up.`, `Página de compra no configurada.`, `Kaufseite nicht eingerichtet.`, `Página de compra não configurada.`, `Pagina di acquisto non configurata.`],
    [`Vérification…`, `Checking…`, `Comprobando…`, `Wird geprüft…`, `Verificando…`, `Verifica…`],
    [`Échec de l'activation.`, `Activation failed.`, `Error al activar.`, `Aktivierung fehlgeschlagen.`, `Falha na ativação.`, `Attivazione non riuscita.`],
    [`Licence Pro activée. Merci !`, `Pro license activated. Thank you!`, `Licencia Pro activada. ¡Gracias!`, `Pro-Lizenz aktiviert. Danke!`, `Licença Pro ativada. Obrigado!`, `Licenza Pro attivata. Grazie!`],
    [`Désactiver la licence sur cet ordinateur ? Tu pourras l'utiliser sur un autre.`, `Deactivate the license on this computer? You will be able to use it on another one.`, `¿Desactivar la licencia en este ordenador? Podrás usarla en otro.`, `Lizenz auf diesem Computer deaktivieren? Du kannst sie dann auf einem anderen nutzen.`, `Desativar a licença neste computador? Você poderá usá-la em outro.`, `Disattivare la licenza su questo computer? Potrai usarla su un altro.`],
    [`Mode illimité activé.`, `Unlimited mode activated.`, `Modo ilimitado activado.`, `Unbegrenzter Modus aktiviert.`, `Modo ilimitado ativado.`, `Modalità illimitata attivata.`],
    [`code perso`, `personal code`, `código personal`, `persönlicher Code`, `código pessoal`, `codice personale`],
    [`Saisis ta clé de licence.`, `Enter your license key.`, `Introduce tu clave de licencia.`, `Gib deinen Lizenzschlüssel ein.`, `Digite sua chave de licença.`, `Inserisci la tua chiave di licenza.`],
    [`Clé refusée.`, `Key rejected.`, `Clave rechazada.`, `Schlüssel abgelehnt.`, `Chave recusada.`, `Chiave rifiutata.`],
    [`Cette clé ne correspond pas à ce produit.`, `This key does not match this product.`, `Esta clave no corresponde a este producto.`, `Dieser Schlüssel passt nicht zu diesem Produkt.`, `Esta chave não corresponde a este produto.`, `Questa chiave non corrisponde a questo prodotto.`],
    [`Impossible de joindre le service de licences. Vérifie ta connexion.`, `Cannot reach the license service. Check your connection.`, `No se puede contactar con el servicio de licencias. Comprueba tu conexión.`, `Der Lizenzdienst ist nicht erreichbar. Prüf deine Verbindung.`, `Não foi possível falar com o serviço de licenças. Verifique sua conexão.`, `Impossibile raggiungere il servizio licenze. Controlla la connessione.`],
    [`Licence désactivée ou expirée.`, `License deactivated or expired.`, `Licencia desactivada o caducada.`, `Lizenz deaktiviert oder abgelaufen.`, `Licença desativada ou expirada.`, `Licenza disattivata o scaduta.`],
    [`Vérification impossible depuis trop longtemps : reconnecte-toi à Internet.`, `Verification has been impossible for too long: connect to the Internet.`, `Hace demasiado tiempo que no se puede verificar: conéctate a Internet.`, `Prüfung schon zu lange nicht möglich: Verbinde dich mit dem Internet.`, `Verificação impossível há muito tempo: conecte-se à internet.`, `Verifica impossibile da troppo tempo: collegati a Internet.`],
    [`Mode développement : tout est déjà débloqué.`, `Development mode: everything is already unlocked.`, `Modo desarrollo: todo ya está desbloqueado.`, `Entwicklungsmodus: Alles ist schon freigeschaltet.`, `Modo de desenvolvimento: tudo já está liberado.`, `Modalità sviluppo: tutto è già sbloccato.`],
    // ── onglet État
    [`moins d'1 min`, `less than 1 min`, `menos de 1 min`, `weniger als 1 Min.`, `menos de 1 min`, `meno di 1 min`],
    [`environ # min`, `about $1 min`, `unos $1 min`, `etwa $1 Min.`, `cerca de $1 min`, `circa $1 min`],
    [`File en pause.`, `Queue paused.`, `Cola en pausa.`, `Warteschlange pausiert.`, `Fila pausada.`, `Coda in pausa.`],
    [`Reprise dans # min.`, `Resuming in $1 min.`, `Se reanuda en $1 min.`, `Geht in $1 Min. weiter.`, `Retoma em $1 min.`, `Riprende tra $1 min.`],
    [`Reprendre maintenant`, `Resume now`, `Reanudar ahora`, `Jetzt fortsetzen`, `Retomar agora`, `Riprendi ora`],
    [`TikTok semble limiter les retraits : pause de ¤.`, `TikTok seems to be limiting removals: pause of $1.`, `TikTok parece limitar las eliminaciones: pausa de $1.`, `TikTok scheint das Entfernen zu begrenzen: Pause von $1.`, `O TikTok parece limitar as remoções: pausa de $1.`, `TikTok sembra limitare le rimozioni: pausa di $1.`],
    [`# secondes`, `$1 seconds`, `$1 segundos`, `$1 Sekunden`, `$1 segundos`, `$1 secondi`],
    [`# minutes`, `$1 minutes`, `$1 minutos`, `$1 Minuten`, `$1 minutos`, `$1 minuti`],
    [`# minute`, `$1 minute`, `$1 minuto`, `$1 Minute`, `$1 minuto`, `$1 minuto`],
    [`Reprise dans # s.`, `Resuming in $1 s.`, `Se reanuda en $1 s.`, `Geht in $1 s weiter.`, `Retoma em $1 s.`, `Riprende tra $1 s.`],
    [`Pause de sécurité quand TikTok semble bloquer (secondes)`, `Safety pause when TikTok seems to block (seconds)`, `Pausa de seguridad cuando TikTok parece bloquear (segundos)`, `Sicherheitspause, wenn TikTok zu blockieren scheint (Sekunden)`, `Pausa de segurança quando o TikTok parece bloquear (segundos)`, `Pausa di sicurezza quando TikTok sembra bloccare (secondi)`],
    [`Chargement complet rétabli dans les onglets de retrait (le blocage des images/vidéos ne convenait pas).`, `Full loading restored in the removal tabs (blocking images/videos did not work).`, `Carga completa restablecida en las pestañas de eliminación (bloquear imágenes/vídeos no funcionaba).`, `Vollständiges Laden in den Entfern-Tabs wiederhergestellt (das Blockieren von Bildern/Videos klappte nicht).`, `Carregamento completo restaurado nas abas de remoção (bloquear imagens/vídeos não funcionou).`, `Caricamento completo ripristinato nelle schede di rimozione (il blocco di immagini/video non funzionava).`],
    [`♥ Gardée`, `♥ Kept`, `♥ Conservado`, `♥ Behalten`, `♥ Mantido`, `♥ Tenuto`],
    [`📁 Rangée`, `📁 Filed`, `📁 En colección`, `📁 Abgelegt`, `📁 Na coleção`, `📁 In raccolta`],
    [`🗑 Retirée des favoris`, `🗑 Removed from favorites`, `🗑 Quitado de favoritos`, `🗑 Aus Favoriten entfernt`, `🗑 Removido dos favoritos`, `🗑 Rimosso dai preferiti`],
    [`↺ Annulée`, `↺ Undone`, `↺ Deshecho`, `↺ Rückgängig gemacht`, `↺ Desfeito`, `↺ Annullato`],
    [`↩ Remise dans la pile`, `↩ Put back in the deck`, `↩ Devuelto a la pila`, `↩ Zurück im Stapel`, `↩ Devolvido à pilha`, `↩ Rimesso nel mazzo`],
    [`⊖ Sortie de la collection`, `⊖ Taken out of the collection`, `⊖ Sacado de la colección`, `⊖ Aus der Sammlung genommen`, `⊖ Tirado da coleção`, `⊖ Tolto dalla raccolta`],
    [`vidéo #`, `video $1`, `vídeo $1`, `Video $1`, `vídeo $1`, `video $1`],
    [`(détecté à ¤)`, `(detected at $1)`, `(detectado a las $1)`, `(erkannt um $1)`, `(detectado às $1)`, `(rilevato alle $1)`],
    [`🗑 Retraits des favoris TikTok`, `🗑 Removals from TikTok favorites`, `🗑 Eliminaciones de favoritos de TikTok`, `🗑 Entfernungen aus TikTok-Favoriten`, `🗑 Remoções dos favoritos do TikTok`, `🗑 Rimozioni dai preferiti di TikTok`],
    [`# en attente · # en cours · # faits ·`, `$1 pending · $2 in progress · $3 done ·`, `$1 pendientes · $2 en curso · $3 hechos ·`, `$1 wartend · $2 laufend · $3 erledigt ·`, `$1 pendentes · $2 em andamento · $3 feitos ·`, `$1 in attesa · $2 in corso · $3 fatti ·`],
    [`# en échec`, `$1 failed`, `$1 con error`, `$1 fehlgeschlagen`, `$1 com falha`, `$1 non riusciti`],
    [`🗑 Retraits : # restants`, `🗑 Removals: $1 left`, `🗑 Eliminaciones: quedan $1`, `🗑 Entfernungen: $1 übrig`, `🗑 Remoções: faltam $1`, `🗑 Rimozioni: $1 rimanenti`],
    [`# en cours`, `$1 in progress`, `$1 en curso`, `$1 laufend`, `$1 em andamento`, `$1 in corso`],
    [`Voir`, `View`, `Ver`, `Ansehen`, `Ver`, `Vedi`],
    [`restantes · # onglet(s) en parallèle`, `remaining · $1 tab(s) in parallel`, `restantes · $1 pestaña(s) en paralelo`, `verbleibend · $1 Tab(s) parallel`, `restantes · $1 aba(s) em paralelo`, `rimanenti · $1 scheda/e in parallelo`],
    [`Annuler les # en attente`, `Cancel the $1 pending`, `Cancelar los $1 pendientes`, `Die $1 wartenden abbrechen`, `Cancelar os $1 pendentes`, `Annulla i $1 in attesa`],
    [`↻ Réessayer les # échecs`, `↻ Retry the $1 failures`, `↻ Reintentar los $1 errores`, `↻ Die $1 Fehlschläge wiederholen`, `↻ Tentar de novo as $1 falhas`, `↻ Riprova i $1 errori`],
    [`📁 Collections`, `📁 Collections`, `📁 Colecciones`, `📁 Sammlungen`, `📁 Coleções`, `📁 Raccolte`],
    [`# à envoyer à TikTok`, `$1 to send to TikTok`, `$1 por enviar a TikTok`, `$1 an TikTok zu senden`, `$1 para enviar ao TikTok`, `$1 da inviare a TikTok`],
    [`# collection(s) en erreur`, `$1 collection(s) with errors`, `$1 colección(es) con errores`, `$1 Sammlung(en) mit Fehlern`, `$1 coleção(ões) com erro`, `$1 raccolta/e con errori`],
    [`⇄ Synchroniser maintenant`, `⇄ Sync now`, `⇄ Sincronizar ahora`, `⇄ Jetzt synchronisieren`, `⇄ Sincronizar agora`, `⇄ Sincronizza ora`],
    [`⬇ Import depuis TikTok`, `⬇ Import from TikTok`, `⬇ Importación desde TikTok`, `⬇ Import aus TikTok`, `⬇ Importação do TikTok`, `⬇ Importazione da TikTok`],
    [`# vidéos importées`, `$1 videos imported`, `$1 vídeos importados`, `$1 Videos importiert`, `$1 vídeos importados`, `$1 video importati`],
    [`sur # favoris`, `out of $1 favorites`, `de $1 favoritos`, `von $1 Favoriten`, `de $1 favoritos`, `su $1 preferiti`],
    [`dernier import :`, `last import:`, `última importación:`, `letzter Import:`, `última importação:`, `ultima importazione:`],
    [`Tout relire (lent)`, `Re-read everything (slow)`, `Releer todo (lento)`, `Alles neu lesen (langsam)`, `Reler tudo (lento)`, `Rileggi tutto (lento)`],
    [`↻ Relire les collections modifiées`, `↻ Re-read modified collections`, `↻ Releer las colecciones modificadas`, `↻ Geänderte Sammlungen neu lesen`, `↻ Reler as coleções modificadas`, `↻ Rileggi le raccolte modificate`],
    [`Relire toutes les collections (lent)`, `Re-read all collections (slow)`, `Releer todas las colecciones (lento)`, `Alle Sammlungen neu lesen (langsam)`, `Reler todas as coleções (lento)`, `Rileggi tutte le raccolte (lento)`],
    [`💾 Sauvegarde`, `💾 Backup`, `💾 Copia de seguridad`, `💾 Sicherung`, `💾 Backup`, `💾 Backup`],
    [`⚠ Supprimer l'extension, ou la recharger depuis un autre dossier, efface ton tri. Fais une sauvegarde avant, puis « Restaurer une sauvegarde » dans la nouvelle installation.`, `⚠ Removing the extension, or reloading it from another folder, erases your sorting. Make a backup first, then use "Restore a backup" in the new installation.`, `⚠ Quitar la extensión, o recargarla desde otra carpeta, borra tu orden. Haz antes una copia de seguridad y luego usa «Restaurar una copia de seguridad» en la nueva instalación.`, `⚠ Wenn du die Erweiterung entfernst oder aus einem anderen Ordner neu lädst, wird deine Sortierung gelöscht. Mach vorher eine Sicherung und nutze dann „Sicherung wiederherstellen“ in der neuen Installation.`, `⚠ Remover a extensão, ou recarregá-la de outra pasta, apaga sua organização. Faça um backup antes e depois use "Restaurar um backup" na nova instalação.`, `⚠ Rimuovere l'estensione, o ricaricarla da un'altra cartella, cancella il tuo ordinamento. Fai prima un backup, poi usa «Ripristina un backup» nella nuova installazione.`],
    [`Dernière sauvegarde : ¤`, `Last backup: $1`, `Última copia: $1`, `Letzte Sicherung: $1`, `Último backup: $1`, `Ultimo backup: $1`],
    [`Aucune sauvegarde pour l'instant.`, `No backup yet.`, `Aún no hay copias de seguridad.`, `Noch keine Sicherung.`, `Nenhum backup ainda.`, `Ancora nessun backup.`],
    [`💾 Tu as trié # vidéos et tu n'as pas de sauvegarde récente : onglet Suivi → « Exporter mes données ».`, `💾 You have sorted $1 videos and have no recent backup: Activity tab → "Export my data".`, `💾 Has ordenado $1 vídeos y no tienes una copia reciente: pestaña Actividad → «Exportar mis datos».`, `💾 Du hast $1 Videos sortiert und keine aktuelle Sicherung: Tab Aktivität → „Meine Daten exportieren“.`, `💾 Você organizou $1 vídeos e não tem backup recente: aba Atividade → "Exportar meus dados".`, `💾 Hai ordinato $1 video e non hai un backup recente: scheda Attività → «Esporta i miei dati».`],
    [`Un fichier avec ton tri, tes collections locales et tes réglages. Rien n'est envoyé nulle part.`, `A file with your sorting, local collections and settings. Nothing is sent anywhere.`, `Un archivo con tu orden, tus colecciones locales y tus ajustes. No se envía nada a ningún sitio.`, `Eine Datei mit deiner Sortierung, deinen lokalen Sammlungen und Einstellungen. Nichts wird irgendwohin gesendet.`, `Um arquivo com sua organização, coleções locais e configurações. Nada é enviado para lugar nenhum.`, `Un file con il tuo ordinamento, le raccolte locali e le impostazioni. Non viene inviato nulla da nessuna parte.`],
    [`⬇ Exporter mes données`, `⬇ Export my data`, `⬇ Exportar mis datos`, `⬇ Meine Daten exportieren`, `⬇ Exportar meus dados`, `⬇ Esporta i miei dati`],
    [`📜 Journal (80 dernières actions)`, `📜 Log (last 80 actions)`, `📜 Registro (últimas 80 acciones)`, `📜 Protokoll (letzte 80 Aktionen)`, `📜 Registro (últimas 80 ações)`, `📜 Registro (ultime 80 azioni)`],
    [`Un retrait est irréversible : retrouve ici la vidéo et remets-la en favori à la main si besoin.`, `A removal cannot be undone: find the video here and re-favorite it by hand if needed.`, `Una eliminación es irreversible: encuentra aquí el vídeo y vuelve a marcarlo como favorito a mano si hace falta.`, `Entfernen ist endgültig: Finde das Video hier und markier es bei Bedarf von Hand wieder als Favorit.`, `Uma remoção é irreversível: encontre o vídeo aqui e marque como favorito de novo à mão, se precisar.`, `Una rimozione è irreversibile: ritrova qui il video e rimettilo nei preferiti a mano se serve.`],
    [`Rien pour l'instant.`, `Nothing yet.`, `Nada por ahora.`, `Noch nichts.`, `Nada por enquanto.`, `Niente per ora.`],
    [`# retrait(s) annulé(s) : les vidéos sont revenues dans la pile`, `$1 removal(s) cancelled: the videos are back in the deck`, `$1 eliminación(es) cancelada(s): los vídeos han vuelto a la pila`, `$1 Entfernung(en) abgebrochen: Die Videos sind zurück im Stapel`, `$1 remoção(ões) cancelada(s): os vídeos voltaram para a pilha`, `$1 rimozione/i annullata/e: i video sono tornati nel mazzo`],
    [`Sauvegarde exportée (# élément(s))`, `Backup exported ($1 item(s))`, `Copia exportada ($1 elemento(s))`, `Sicherung exportiert ($1 Element(e))`, `Backup exportado ($1 item(ns))`, `Backup esportato ($1 elemento/i)`],
    [`Fichier illisible.`, `Unreadable file.`, `Archivo ilegible.`, `Datei nicht lesbar.`, `Arquivo ilegível.`, `File illeggibile.`],
    [`Ce fichier n'est pas une sauvegarde de l'extension.`, `This file is not a backup of the extension.`, `Este archivo no es una copia de seguridad de la extensión.`, `Diese Datei ist keine Sicherung der Erweiterung.`, `Este arquivo não é um backup da extensão.`, `Questo file non è un backup dell'estensione.`],
    [`Sauvegarde vide.`, `Empty backup.`, `Copia vacía.`, `Leere Sicherung.`, `Backup vazio.`, `Backup vuoto.`],
    [`Restaurer la sauvegarde ? Elle REMPLACE les données actuelles de : ¤.`, `Restore the backup? It REPLACES the current data of: $1.`, `¿Restaurar la copia? REEMPLAZA los datos actuales de: $1.`, `Sicherung wiederherstellen? Sie ERSETZT die aktuellen Daten von: $1.`, `Restaurar o backup? Ele SUBSTITUI os dados atuais de: $1.`, `Ripristinare il backup? SOSTITUISCE i dati attuali di: $1.`],
    [`Sauvegarde restaurée.`, `Backup restored.`, `Copia restaurada.`, `Sicherung wiederhergestellt.`, `Backup restaurado.`, `Backup ripristinato.`],
    [`réglages`, `settings`, `ajustes`, `Einstellungen`, `configurações`, `impostazioni`],
    // ── réglages
    [`⚙ Réglages`, `⚙ Settings`, `⚙ Ajustes`, `⚙ Einstellungen`, `⚙ Configurações`, `⚙ Impostazioni`],
    [`Délai pour annuler un retrait (secondes)`, `Time to undo a removal (seconds)`, `Tiempo para deshacer una eliminación (segundos)`, `Zeit zum Rückgängigmachen einer Entfernung (Sekunden)`, `Tempo para desfazer uma remoção (segundos)`, `Tempo per annullare una rimozione (secondi)`],
    [`Onglets de retrait en parallèle (1 à 3)`, `Parallel removal tabs (1 to 3)`, `Pestañas de eliminación en paralelo (1 a 3)`, `Parallele Entfern-Tabs (1 bis 3)`, `Abas de remoção em paralelo (1 a 3)`, `Schede di rimozione in parallelo (da 1 a 3)`],
    [`Envoyer les rangements aux collections après (secondes d'inactivité)`, `Send filing to collections after (seconds of inactivity)`, `Enviar los cambios de colección tras (segundos de inactividad)`, `Ablagen an Sammlungen senden nach (Sekunden Inaktivität)`, `Enviar as coleções após (segundos de inatividade)`, `Invia gli inserimenti nelle raccolte dopo (secondi di inattività)`],
    [`Retraits plus rapides : ne pas charger images et vidéos dans les onglets de retrait`, `Faster removals: do not load images and videos in removal tabs`, `Eliminaciones más rápidas: no cargar imágenes ni vídeos en las pestañas de eliminación`, `Schnelleres Entfernen: keine Bilder und Videos in den Entfern-Tabs laden`, `Remoções mais rápidas: não carregar imagens e vídeos nas abas de remoção`, `Rimozioni più veloci: non caricare immagini e video nelle schede di rimozione`],
    [`Pause entre deux retraits : min (s)`, `Pause between two removals: min (s)`, `Pausa entre dos eliminaciones: mín. (s)`, `Pause zwischen zwei Entfernungen: min. (s)`, `Pausa entre duas remoções: mín. (s)`, `Pausa tra due rimozioni: min (s)`],
    [`Pause entre deux retraits : max (s)`, `Pause between two removals: max (s)`, `Pausa entre dos eliminaciones: máx. (s)`, `Pause zwischen zwei Entfernungen: max. (s)`, `Pausa entre duas remoções: máx. (s)`, `Pausa tra due rimozioni: max (s)`],
    [`Inverser les gestes (droite = garder, gauche = retirer)`, `Reverse the gestures (right = keep, left = remove)`, `Invertir los gestos (derecha = conservar, izquierda = quitar)`, `Gesten umkehren (rechts = behalten, links = entfernen)`, `Inverter os gestos (direita = manter, esquerda = remover)`, `Inverti i gesti (destra = tieni, sinistra = rimuovi)`],
    [`Plus d'onglets et des pauses courtes = retraits plus rapides, mais plus de risque que TikTok te ralentisse ou te bloque. L'extension se met en pause d'elle-même (5 minutes en version gratuite, réglable en Pro) si TikTok refuse plusieurs retraits de suite. Une pause trop courte augmente le risque de limitation du compte.`, `More tabs and short pauses = faster removals, but a higher risk that TikTok slows or blocks you. The extension pauses by itself (5 minutes in the free version, adjustable in Pro) if TikTok refuses several removals in a row. A pause that is too short increases the risk of the account being limited.`, `Más pestañas y pausas cortas = eliminaciones más rápidas, pero más riesgo de que TikTok te frene o te bloquee. La extensión se pausa sola (5 minutos en la versión gratuita, ajustable en Pro) si TikTok rechaza varias eliminaciones seguidas. Una pausa demasiado corta aumenta el riesgo de que limiten la cuenta.`, `Mehr Tabs und kurze Pausen = schnelleres Entfernen, aber ein höheres Risiko, dass TikTok dich bremst oder blockiert. Die Erweiterung pausiert von selbst (5 Minuten in der kostenlosen Version, in Pro einstellbar), wenn TikTok mehrere Entfernungen hintereinander ablehnt. Eine zu kurze Pause erhöht das Risiko, dass das Konto eingeschränkt wird.`, `Mais abas e pausas curtas = remoções mais rápidas, mas mais risco de o TikTok te desacelerar ou bloquear. A extensão pausa sozinha (5 minutos na versão grátis, ajustável no Pro) se o TikTok recusar várias remoções seguidas. Uma pausa curta demais aumenta o risco de a conta ser limitada.`, `Più schede e pause brevi = rimozioni più veloci, ma più rischio che TikTok ti rallenti o ti blocchi. L'estensione si mette in pausa da sola (5 minuti nella versione gratuita, regolabile in Pro) se TikTok rifiuta più rimozioni di fila. Una pausa troppo breve aumenta il rischio che l'account venga limitato.`],
    [`Enregistrer`, `Save`, `Guardar`, `Speichern`, `Salvar`, `Salva`],
    [`Réglages enregistrés.`, `Settings saved.`, `Ajustes guardados.`, `Einstellungen gespeichert.`, `Configurações salvas.`, `Impostazioni salvate.`],
    [`— Pro`, `— Pro`, `— Pro`, `— Pro`, `— Pro`, `— Pro`],
    // ── import / synchronisation / erreurs
    [`Arrêté par toi.`, `Stopped by you.`, `Detenido por ti.`, `Von dir gestoppt.`, `Parado por você.`, `Interrotto da te.`],
    [`Une opération est déjà en cours (import ou synchronisation). Clique sur ✕ Stop pour l'arrêter.`, `An operation is already running (import or sync). Click ✕ Stop to stop it.`, `Ya hay una operación en curso (importación o sincronización). Haz clic en ✕ Stop para detenerla.`, `Es läuft schon ein Vorgang (Import oder Synchronisierung). Klick auf ✕ Stop, um ihn zu beenden.`, `Já há uma operação em andamento (importação ou sincronização). Clique em ✕ Stop para pará-la.`, `C'è già un'operazione in corso (importazione o sincronizzazione). Clicca su ✕ Stop per fermarla.`],
    [`TikTok limite l'accès à tes favoris en ce moment (« Une erreur est survenue »). Attends 10 à 30 minutes, recharge tiktok.com, puis relance.`, `TikTok is limiting access to your favorites right now ("Something went wrong"). Wait 10 to 30 minutes, reload tiktok.com, then try again.`, `TikTok está limitando el acceso a tus favoritos ahora mismo («Algo salió mal»). Espera de 10 a 30 minutos, recarga tiktok.com y vuelve a intentarlo.`, `TikTok schränkt gerade den Zugriff auf deine Favoriten ein („Etwas ist schiefgelaufen“). Warte 10 bis 30 Minuten, lade tiktok.com neu und versuch es noch einmal.`, `O TikTok está limitando o acesso aos seus favoritos agora ("Algo deu errado"). Espere de 10 a 30 minutos, recarregue tiktok.com e tente de novo.`, `TikTok sta limitando l'accesso ai tuoi preferiti in questo momento («Si è verificato un errore»). Aspetta da 10 a 30 minuti, ricarica tiktok.com e riprova.`],
    [`Connecte-toi à TikTok.`, `Sign in to TikTok.`, `Inicia sesión en TikTok.`, `Melde dich bei TikTok an.`, `Entre no TikTok.`, `Accedi a TikTok.`],
    [`Impossible d'ouvrir ton profil (plusieurs rechargements sans succès).`, `Cannot open your profile (several reloads without success).`, `No se puede abrir tu perfil (varias recargas sin éxito).`, `Dein Profil lässt sich nicht öffnen (mehrere Neuladeversuche ohne Erfolg).`, `Não foi possível abrir seu perfil (várias recargas sem sucesso).`, `Impossibile aprire il tuo profilo (diversi ricaricamenti senza successo).`],
    [`Impossible d'ouvrir ton profil.`, `Cannot open your profile.`, `No se puede abrir tu perfil.`, `Dein Profil lässt sich nicht öffnen.`, `Não foi possível abrir seu perfil.`, `Impossibile aprire il tuo profilo.`],
    [`Onglet « Favoris » introuvable sur ton profil.`, `"Favorites" tab not found on your profile.`, `No se encuentra la pestaña «Favoritos» en tu perfil.`, `Tab „Favoriten“ in deinem Profil nicht gefunden.`, `Aba "Favoritos" não encontrada no seu perfil.`, `Scheda «Preferiti» non trovata sul tuo profilo.`],
    [`Sous-onglet « ¤ » introuvable.`, `Sub-tab "$1" not found.`, `No se encuentra la subpestaña «$1».`, `Unter-Tab „$1“ nicht gefunden.`, `Subaba "$1" não encontrada.`, `Sottoscheda «$1» non trovata.`],
    [`Le sous-onglet « ¤ » ne s'est pas ouvert.`, `The sub-tab "$1" did not open.`, `La subpestaña «$1» no se abrió.`, `Der Unter-Tab „$1“ hat sich nicht geöffnet.`, `A subaba "$1" não abriu.`, `La sottoscheda «$1» non si è aperta.`],
    [`Import : ¤…`, `Import: $1…`, `Importación: $1…`, `Import: $1…`, `Importação: $1…`, `Importazione: $1…`],
    [`# favoris lus, # collections (# vidéos déjà rangées)`, `$1 favorites read, $2 collections ($3 videos already filed)`, `$1 favoritos leídos, $2 colecciones ($3 vídeos ya en una colección)`, `$1 Favoriten gelesen, $2 Sammlungen ($3 Videos schon abgelegt)`, `$1 favoritos lidos, $2 coleções ($3 vídeos já em coleções)`, `$1 preferiti letti, $2 raccolte ($3 video già inseriti)`],
    [`Collections non lues : ¤`, `Collections not read: $1`, `Colecciones no leídas: $1`, `Sammlungen nicht gelesen: $1`, `Coleções não lidas: $1`, `Raccolte non lette: $1`],
    [`# favoris lus sur # : relance l'import pour continuer`, `$1 favorites read out of $2: run the import again to continue`, `$1 favoritos leídos de $2: vuelve a importar para continuar`, `$1 von $2 Favoriten gelesen: Starte den Import erneut, um weiterzumachen`, `$1 favoritos lidos de $2: importe de novo para continuar`, `$1 preferiti letti su $2: rilancia l'importazione per continuare`],
    [`# favoris lus (TikTok en annonce # : certaines vidéos ne sont plus disponibles)`, `$1 favorites read (TikTok announces $2: some videos are no longer available)`, `$1 favoritos leídos (TikTok indica $2: algunos vídeos ya no están disponibles)`, `$1 Favoriten gelesen (TikTok meldet $2: einige Videos sind nicht mehr verfügbar)`, `$1 favoritos lidos (o TikTok indica $2: alguns vídeos não estão mais disponíveis)`, `$1 preferiti letti (TikTok ne indica $2: alcuni video non sono più disponibili)`],
    [`Collection #/# : « ¤ »`, `Collection $1/$2: "$3"`, `Colección $1/$2: «$3»`, `Sammlung $1/$2: „$3“`, `Coleção $1/$2: "$3"`, `Raccolta $1/$2: «$3»`],
    [`Recherche de nouvelles collections…`, `Looking for new collections…`, `Buscando colecciones nuevas…`, `Suche nach neuen Sammlungen…`, `Procurando coleções novas…`, `Ricerca di nuove raccolte…`],
    [`# collections vues (# inchangée(s) ignorée(s)), # vidéos déjà rangées`, `$1 collections seen ($2 unchanged skipped), $3 videos already filed`, `$1 colecciones vistas ($2 sin cambios omitidas), $3 vídeos ya en una colección`, `$1 Sammlungen gesehen ($2 unveränderte übersprungen), $3 Videos schon abgelegt`, `$1 coleções vistas ($2 sem mudanças ignoradas), $3 vídeos já em coleções`, `$1 raccolte viste ($2 invariate saltate), $3 video già inseriti`],
    [`Page de la collection « ¤ » introuvable.`, `Collection page "$1" not found.`, `No se encuentra la página de la colección «$1».`, `Seite der Sammlung „$1“ nicht gefunden.`, `Página da coleção "$1" não encontrada.`, `Pagina della raccolta «$1» non trovata.`],
    [`Bouton « Créer une nouvelle collection » introuvable.`, `"Create a new collection" button not found.`, `No se encuentra el botón «Crear una colección nueva».`, `Schaltfläche „Neue Sammlung erstellen“ nicht gefunden.`, `Botão "Criar uma nova coleção" não encontrado.`, `Pulsante «Crea una nuova raccolta» non trovato.`],
    [`Champ du nom de collection introuvable.`, `Collection name field not found.`, `No se encuentra el campo del nombre de la colección.`, `Feld für den Sammlungsnamen nicht gefunden.`, `Campo do nome da coleção não encontrado.`, `Campo del nome della raccolta non trovato.`],
    [`TikTok refuse le nom « ¤ » : ¤ Renomme la collection (✎).`, `TikTok rejects the name "$1": $2 Rename the collection (✎).`, `TikTok rechaza el nombre «$1»: $2 Cambia el nombre de la colección (✎).`, `TikTok lehnt den Namen „$1“ ab: $2 Benenne die Sammlung um (✎).`, `O TikTok recusa o nome "$1": $2 Renomeie a coleção (✎).`, `TikTok rifiuta il nome «$1»: $2 Rinomina la raccolta (✎).`],
    [`TikTok refuse le nom « ¤ » : ¤`, `TikTok rejects the name "$1": $2`, `TikTok rechaza el nombre «$1»: $2`, `TikTok lehnt den Namen „$1“ ab: $2`, `O TikTok recusa o nome "$1": $2`, `TikTok rifiuta il nome «$1»: $2`],
    [`Ce nom est inapproprié. Réessaie.`, `This name is inappropriate. Try again.`, `Este nombre no es apropiado. Inténtalo de nuevo.`, `Dieser Name ist unangemessen. Versuch es noch einmal.`, `Este nome é inadequado. Tente de novo.`, `Questo nome non è appropriato. Riprova.`],
    [`Bouton « Suivant » introuvable.`, `"Next" button not found.`, `No se encuentra el botón «Siguiente».`, `Schaltfläche „Weiter“ nicht gefunden.`, `Botão "Avançar" não encontrado.`, `Pulsante «Avanti» non trovato.`],
    [`Fenêtre de sélection introuvable pour « ¤ » (¤ ; à l'écran : ¤).`, `Selection window not found for "$1" ($2; on screen: $3).`, `No se encuentra la ventana de selección para «$1» ($2; en pantalla: $3).`, `Auswahlfenster für „$1“ nicht gefunden ($2; auf dem Bildschirm: $3).`, `Janela de seleção não encontrada para "$1" ($2; na tela: $3).`, `Finestra di selezione non trovata per «$1» ($2; sullo schermo: $3).`],
    [`collection existante`, `existing collection`, `colección existente`, `vorhandene Sammlung`, `coleção existente`, `raccolta esistente`],
    [`nouvelle collection`, `new collection`, `colección nueva`, `neue Sammlung`, `coleção nova`, `nuova raccolta`],
    [`aucune fenêtre`, `no window`, `ninguna ventana`, `kein Fenster`, `nenhuma janela`, `nessuna finestra`],
    [`Sélection incohérente pour « ¤ » (¤).`, `Inconsistent selection for "$1" ($2).`, `Selección incoherente para «$1» ($2).`, `Unstimmige Auswahl für „$1“ ($2).`, `Seleção inconsistente para "$1" ($2).`, `Selezione incoerente per «$1» ($2).`],
    [`Mode « Gérer les vidéos » introuvable pour « ¤ ».`, `"Manage videos" mode not found for "$1".`, `No se encuentra el modo «Gestionar vídeos» para «$1».`, `Modus „Videos verwalten“ für „$1“ nicht gefunden.`, `Modo "Gerenciar vídeos" não encontrado para "$1".`, `Modalità «Gestisci video» non trovata per «$1».`],
    [`Bouton « Supprimer » introuvable dans « Gérer les vidéos ».`, `"Delete" button not found in "Manage videos".`, `No se encuentra el botón «Eliminar» en «Gestionar vídeos».`, `Schaltfläche „Löschen“ in „Videos verwalten“ nicht gefunden.`, `Botão "Excluir" não encontrado em "Gerenciar vídeos".`, `Pulsante «Elimina» non trovato in «Gestisci video».`],
    [`Confirmation de retrait introuvable.`, `Removal confirmation not found.`, `No se encuentra la confirmación de eliminación.`, `Bestätigung zum Entfernen nicht gefunden.`, `Confirmação de remoção não encontrada.`, `Conferma di rimozione non trovata.`],
    [`Rien en attente. Vérification auprès de TikTok…`, `Nothing pending. Checking with TikTok…`, `Nada pendiente. Comprobando con TikTok…`, `Nichts ausstehend. Abgleich mit TikTok…`, `Nada pendente. Verificando com o TikTok…`, `Niente in attesa. Verifica con TikTok…`],
    [`Retrait de « ¤ »…`, `Removing from "$1"…`, `Quitando de «$1»…`, `Entfernen aus „$1“…`, `Removendo de "$1"…`, `Rimozione da «$1»…`],
    [`Rangement dans « ¤ »…`, `Filing into "$1"…`, `Moviendo a «$1»…`, `Ablegen in „$1“…`, `Colocando em "$1"…`, `Inserimento in «$1»…`],
    [`Synchronisation arrêtée.`, `Sync stopped.`, `Sincronización detenida.`, `Synchronisierung gestoppt.`, `Sincronização parada.`, `Sincronizzazione interrotta.`],
    [`Arrêt en cours…`, `Stopping…`, `Deteniendo…`, `Wird gestoppt…`, `Parando…`, `Arresto in corso…`],
    [`# synchronisées, # collection(s) en erreur (voir l'onglet Collections)`, `$1 synced, $2 collection(s) with errors (see the Collections tab)`, `$1 sincronizados, $2 colección(es) con errores (ver la pestaña Colecciones)`, `$1 synchronisiert, $2 Sammlung(en) mit Fehlern (siehe Tab Sammlungen)`, `$1 sincronizados, $2 coleção(ões) com erro (veja a aba Coleções)`, `$1 sincronizzati, $2 raccolta/e con errori (vedi la scheda Raccolte)`],
    [`# synchronisées, # introuvables dans la liste TikTok`, `$1 synced, $2 not found in the TikTok list`, `$1 sincronizados, $2 no encontrados en la lista de TikTok`, `$1 synchronisiert, $2 nicht in der TikTok-Liste gefunden`, `$1 sincronizados, $2 não encontrados na lista do TikTok`, `$1 sincronizzati, $2 non trovati nell'elenco di TikTok`],
    [`# vidéos synchronisées avec TikTok`, `$1 videos synced with TikTok`, `$1 vídeos sincronizados con TikTok`, `$1 Videos mit TikTok synchronisiert`, `$1 vídeos sincronizados com o TikTok`, `$1 video sincronizzati con TikTok`],
    [`Le compte a changé (¤). Ferme puis rouvre l'extension.`, `The account changed ($1). Close and reopen the extension.`, `La cuenta ha cambiado ($1). Cierra y vuelve a abrir la extensión.`, `Das Konto hat sich geändert ($1). Schließ die Erweiterung und öffne sie erneut.`, `A conta mudou ($1). Feche e abra a extensão de novo.`, `L'account è cambiato ($1). Chiudi e riapri l'estensione.`],
    // ── onglet de retrait
    [`Ce retrait appartient à ¤ (connecté : ¤)`, `This removal belongs to $1 (signed in: $2)`, `Esta eliminación pertenece a $1 (conectado: $2)`, `Diese Entfernung gehört zu $1 (angemeldet: $2)`, `Esta remoção pertence a $1 (conectado: $2)`, `Questa rimozione appartiene a $1 (connesso: $2)`],
    [`personne`, `nobody`, `nadie`, `niemand`, `ninguém`, `nessuno`],
    [`Bouton favori introuvable (connexion ? captcha ?)`, `Favorite button not found (signed out? captcha?)`, `No se encuentra el botón de favorito (¿sesión cerrada? ¿captcha?)`, `Favoriten-Schaltfläche nicht gefunden (abgemeldet? Captcha?)`, `Botão de favorito não encontrado (desconectado? captcha?)`, `Pulsante preferito non trovato (disconnesso? captcha?)`],
    [`La page affiche une autre vidéo`, `The page shows another video`, `La página muestra otro vídeo`, `Die Seite zeigt ein anderes Video`, `A página mostra outro vídeo`, `La pagina mostra un altro video`],
    [`Déjà retiré`, `Already removed`, `Ya quitado`, `Schon entfernt`, `Já removido`, `Già rimosso`],
    [`État du favori illisible`, `Favorite state unreadable`, `Estado del favorito ilegible`, `Favoritenstatus nicht lesbar`, `Estado do favorito ilegível`, `Stato del preferito illeggibile`],
    [`Le clic n'a pas retiré le favori`, `The click did not remove the favorite`, `El clic no quitó el favorito`, `Der Klick hat den Favoriten nicht entfernt`, `O clique não removeu o favorito`, `Il clic non ha rimosso il preferito`],
    [`Clic effectué, état non vérifiable`, `Click done, state cannot be verified`, `Clic hecho, estado no verificable`, `Klick ausgeführt, Status nicht prüfbar`, `Clique feito, estado não verificável`, `Clic eseguito, stato non verificabile`],
    [`Délai dépassé`, `Timed out`, `Tiempo agotado`, `Zeitüberschreitung`, `Tempo esgotado`, `Tempo scaduto`],
    // ── bilan, invitation à laisser un avis
    [`vidéos triées`, `videos sorted`, `vídeos ordenados`, `Videos sortiert`, `vídeos organizados`, `video ordinati`],
    [`retirées des favoris`, `removed from favorites`, `quitados de favoritos`, `aus Favoriten entfernt`, `removidos dos favoritos`, `rimossi dai preferiti`],
    [`rangées en collection`, `filed in collections`, `en colecciones`, `in Sammlungen abgelegt`, `em coleções`, `inseriti in raccolte`],
    [`gardées`, `kept`, `conservados`, `behalten`, `mantidos`, `tenuti`],
    [`Ça te fait gagner du temps ? Un avis sur le Chrome Web Store aide beaucoup l'extension à être trouvée.`, `Saving you time? A review on the Chrome Web Store really helps people find the extension.`, `¿Te ahorra tiempo? Una reseña en la Chrome Web Store ayuda mucho a que otros encuentren la extensión.`, `Spart dir das Zeit? Eine Bewertung im Chrome Web Store hilft sehr, damit andere die Erweiterung finden.`, `Está economizando seu tempo? Uma avaliação na Chrome Web Store ajuda muito a extensão a ser encontrada.`, `Ti fa risparmiare tempo? Una recensione sul Chrome Web Store aiuta molto a far trovare l'estensione.`],
    [`Laisser un avis`, `Leave a review`, `Dejar una reseña`, `Bewertung schreiben`, `Deixar uma avaliação`, `Lascia una recensione`],
    [`Plus tard`, `Later`, `Más tarde`, `Später`, `Mais tarde`, `Più tardi`],
    [`Ne plus demander`, `Don't ask again`, `No volver a preguntar`, `Nicht mehr fragen`, `Não perguntar de novo`, `Non chiedere più`],
    // ── premier lancement
    [`Un clic sur « Importer depuis mon profil TikTok » : l'extension lit tes favoris et tes collections. Tu peux commencer à trier dès les premières vidéos, pendant que la suite se charge.`, `One click on "Import from my TikTok profile": the extension reads your favorites and collections. You can start sorting from the first videos while the rest loads.`, `Un clic en «Importar desde mi perfil de TikTok»: la extensión lee tus favoritos y tus colecciones. Puedes empezar a ordenar desde los primeros vídeos mientras se carga el resto.`, `Ein Klick auf „Aus meinem TikTok-Profil importieren“: Die Erweiterung liest deine Favoriten und Sammlungen. Du kannst schon ab den ersten Videos sortieren, während der Rest lädt.`, `Um clique em "Importar do meu perfil do TikTok": a extensão lê seus favoritos e coleções. Você já pode organizar os primeiros vídeos enquanto o resto carrega.`, `Un clic su «Importa dal mio profilo TikTok»: l'estensione legge i tuoi preferiti e le tue raccolte. Puoi iniziare a ordinare dai primi video mentre il resto si carica.`],
    [`Un geste par vidéo`, `One gesture per video`, `Un gesto por vídeo`, `Eine Geste pro Video`, `Um gesto por vídeo`, `Un gesto per video`],
    [`retirer des favoris`, `remove from favorites`, `quitar de favoritos`, `aus Favoriten entfernen`, `remover dos favoritos`, `rimuovi dai preferiti`],
    [`ranger dans une collection`, `file into a collection`, `mover a una colección`, `in eine Sammlung ablegen`, `colocar em uma coleção`, `metti in una raccolta`],
    [`garder`, `keep`, `conservar`, `behalten`, `manter`, `tieni`],
    [`Glisse la carte avec la souris ou utilise les flèches du clavier. Touches 1 à 9 : collection numérotée du panneau · Z : annuler.`, `Drag the card with the mouse or use the arrow keys. Keys 1 to 9: numbered collection in the panel · Z: undo.`, `Arrastra la tarjeta con el ratón o usa las flechas del teclado. Teclas 1 a 9: colección numerada del panel · Z: deshacer.`, `Zieh die Karte mit der Maus oder nutze die Pfeiltasten. Tasten 1 bis 9: nummerierte Sammlung im Panel · Z: rückgängig.`, `Arraste o cartão com o mouse ou use as setas do teclado. Teclas 1 a 9: coleção numerada do painel · Z: desfazer.`, `Trascina la scheda con il mouse o usa le frecce della tastiera. Tasti da 1 a 9: raccolta numerata del pannello · Z: annulla.`],
    [`Tout part tout seul`, `Everything runs by itself`, `Todo se envía solo`, `Alles läuft von selbst`, `Tudo é enviado sozinho`, `Tutto parte da solo`],
    [`Les retraits partent en arrière-plan après un délai pendant lequel tu peux annuler, et les rangements sont envoyés à TikTok automatiquement. Tout reste dans ton navigateur : aucun compte, aucune donnée envoyée.`, `Removals run in the background after a delay during which you can undo, and filing is sent to TikTok automatically. Everything stays in your browser: no account, no data sent.`, `Las eliminaciones se hacen en segundo plano tras un plazo en el que puedes deshacer, y los cambios de colección se envían a TikTok automáticamente. Todo se queda en tu navegador: sin cuenta, sin enviar datos.`, `Entfernungen laufen im Hintergrund nach einer Frist, in der du sie rückgängig machen kannst, und das Ablegen wird automatisch an TikTok gesendet. Alles bleibt in deinem Browser: kein Konto, keine Daten werden gesendet.`, `As remoções rodam em segundo plano depois de um prazo em que você pode desfazer, e as coleções são enviadas ao TikTok automaticamente. Tudo fica no seu navegador: sem conta, nenhum dado enviado.`, `Le rimozioni partono in background dopo un intervallo in cui puoi annullare, e gli inserimenti vengono inviati a TikTok automaticamente. Tutto resta nel tuo browser: nessun account, nessun dato inviato.`],
    [`Passer`, `Skip`, `Omitir`, `Überspringen`, `Pular`, `Salta`],
    [`Suivant`, `Next`, `Siguiente`, `Weiter`, `Avançar`, `Avanti`],
    [`C'est parti`, `Let's go`, `¡Vamos!`, `Los geht's`, `Vamos lá`, `Si parte`],
    // ── fenêtre de l'icône
    [`# retraits en cours en arrière-plan.`, `$1 removals running in the background.`, `$1 eliminaciones en curso en segundo plano.`, `$1 Entfernungen laufen im Hintergrund.`, `$1 remoções em andamento em segundo plano.`, `$1 rimozioni in corso in background.`],
    [`Reprends là où tu t'étais arrêté.`, `Pick up where you left off.`, `Sigue donde lo dejaste.`, `Mach da weiter, wo du aufgehört hast.`, `Continue de onde parou.`, `Riprendi da dove ti eri fermato.`],
    [`Tout est trié 🎉 Réimporte de temps en temps pour les nouveaux favoris.`, `All sorted 🎉 Re-import now and then for new favorites.`, `Todo ordenado 🎉 Vuelve a importar de vez en cuando para los favoritos nuevos.`, `Alles sortiert 🎉 Importiere ab und zu neu, um neue Favoriten zu holen.`, `Tudo organizado 🎉 Importe de novo de vez em quando para os favoritos novos.`, `Tutto ordinato 🎉 Reimporta ogni tanto per i nuovi preferiti.`],
    [`Ouvre le panneau puis clique sur « Importer depuis mon profil TikTok ».`, `Open the panel, then click "Import from my TikTok profile".`, `Abre el panel y haz clic en «Importar desde mi perfil de TikTok».`, `Öffne das Panel und klick auf „Aus meinem TikTok-Profil importieren“.`, `Abra o painel e clique em "Importar do meu perfil do TikTok".`, `Apri il pannello, poi clicca su «Importa dal mio profilo TikTok».`],
    [`Ouvre TikTok et connecte-toi, puis importe tes favoris en un clic.`, `Open TikTok and sign in, then import your favorites in one click.`, `Abre TikTok e inicia sesión, luego importa tus favoritos con un clic.`, `Öffne TikTok und melde dich an, dann importiere deine Favoriten mit einem Klick.`, `Abra o TikTok e entre na sua conta, depois importe seus favoritos com um clique.`, `Apri TikTok e accedi, poi importa i tuoi preferiti con un clic.`],
    [`· retraits illimités`, `· unlimited removals`, `· eliminaciones ilimitadas`, `· unbegrenztes Entfernen`, `· remoções ilimitadas`, `· rimozioni illimitate`],
    [`Gratuit : # / # retraits aujourd'hui`, `Free: $1 / $2 removals today`, `Gratis: $1 / $2 eliminaciones hoy`, `Kostenlos: $1 / $2 Entfernungen heute`, `Grátis: $1 / $2 remoções hoje`, `Gratis: $1 / $2 rimozioni oggi`],
    [`⭐ Laisser un avis`, `⭐ Leave a review`, `⭐ Dejar una reseña`, `⭐ Bewertung schreiben`, `⭐ Deixar uma avaliação`, `⭐ Lascia una recensione`],
    [`Aide`, `Help`, `Ayuda`, `Hilfe`, `Ajuda`, `Aiuto`],
    [`à trier`, `to sort`, `por ordenar`, `zu sortieren`, `para organizar`, `da ordinare`],
    [`rangées`, `filed`, `en colección`, `abgelegt`, `em coleções`, `in raccolta`],
    [`retirées`, `removed`, `quitados`, `entfernt`, `removidos`, `rimossi`],
    // ── boutons sous la carte, en-tête compact
    [`Garder`, `Keep`, `Conservar`, `Behalten`, `Manter`, `Tieni`],
    [`Retirer`, `Remove`, `Quitar`, `Entfernen`, `Remover`, `Rimuovi`],
    [`Ranger`, `Organize`, `Colección`, `Ablegen`, `Coleção`, `Raccolta`],
    [`Défaire`, `Undo`, `Deshacer`, `Rückgängig`, `Desfazer`, `Annulla`],
    [`Réglages`, `Settings`, `Ajustes`, `Einstellungen`, `Configurações`, `Impostazioni`],
    [`Faire un don`, `Donate`, `Donar`, `Spenden`, `Doar`, `Dona`],
    // ── divers
    [`vidéo(s)`, `video(s)`, `vídeo(s)`, `Video(s)`, `vídeo(s)`, `video`],
    [`vidéos`, `videos`, `vídeos`, `Videos`, `vídeos`, `video`],
    [`favoris`, `favorites`, `favoritos`, `Favoriten`, `favoritos`, `preferiti`],
  ];

  const norm = (s) => s.replace(/[’‘]/g, "'");
  const escRe = (s) => s.replace(/[.+?^${}()|[\]\\*]/g, '\\$&');
  // Les règles sont compilées une fois, puis chaque langue choisit sa colonne.
  const RULES = ROWS.map((row) => {
    const fr = row[0];
    let src = escRe(norm(fr)).replace(/¤$/, '(.+)').replace(/¤/g, '(.+?)').replace(/#/g, '(\\d+)');
    if (/^\p{L}/u.test(fr)) src = `(?<![\\p{L}\\d])${src}`;
    if (/\p{L}$/u.test(fr)) src = `${src}(?![\\p{L}])`;
    return { len: fr.length, re: new RegExp(src, 'gu'), row };
  }).sort((a, b) => b.len - a.len);

  let lang = 'fr';
  const cache = new Map();

  function tr(text) {
    if (lang === 'fr' || !text) return text;
    const src = String(text);
    if (!/[A-Za-zÀ-ÿ]/.test(src)) return src;
    if (cache.has(src)) return cache.get(src);
    const col = COL[lang];
    let out = norm(src).replace(/\s+/g, ' '); // retours à la ligne et indentations des gabarits : un seul espace
    // phrases déjà remplacées : on ne les repasse pas dans les règles suivantes (pas de double traduction)
    const marks = [];
    for (const r of RULES) {
      out = out.replace(r.re, (...m) => {
        const groups = m.slice(1, -2).filter((g) => typeof g === 'string' || g === undefined);
        const target = r.row[col] || r.row[1];
        const done = target.replace(/\$(\d)/g, (_, i) => tr(groups[i - 1] ?? ''));
        marks.push(done);
        return `\u0001${marks.length - 1}\u0002`; // repère invisible : seuls ces nombres-là sont remplacés à la fin
      });
    }
    out = out.replace(/\u0001(\d+)\u0002/g, (_, i) => marks[i]);
    if (cache.size > 3000) cache.clear();
    cache.set(src, out);
    return out;
  }

  const ATTRS = ['title', 'placeholder', 'aria-label', 'alt'];
  const SKIP = 'style, script, textarea, input, [data-nt]';
  const mem = new WeakMap(); // nœud ou élément → { fr, en } (texte d'origine et texte affiché)

  function doText(node) {
    const p = node.parentElement;
    if (!p || p.closest(SKIP) || p.closest('.chip:not(.new)')) return; // les noms de collection sont des données de l'utilisateur
    const m = mem.get(node);
    if (m && node.data === m.en) {
      // pas modifié par le code : on ne fait que réappliquer la langue courante
      const en = tr(m.fr);
      if (en !== node.data) { node.data = en; m.en = en; }
      return;
    }
    const fr = node.data;
    const en = tr(fr);
    mem.set(node, { fr, en });
    if (en !== fr) node.data = en;
  }
  function doAttrs(el) {
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const key = `${a}:`;
      let m = mem.get(el) || {};
      const cur = el.getAttribute(a);
      if (m[key] && cur === m[key].en) {
        const en = tr(m[key].fr);
        if (en !== cur) { el.setAttribute(a, en); m[key].en = en; }
      } else {
        const en = tr(cur);
        m[key] = { fr: cur, en };
        if (en !== cur) el.setAttribute(a, en);
      }
      mem.set(el, m);
    }
  }
  function walk(rootNode) {
    if (rootNode.nodeType === 3) return doText(rootNode);
    if (rootNode.nodeType !== 1 && rootNode.nodeType !== 11) return;
    if (rootNode.nodeType === 1) doAttrs(rootNode);
    const w = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) (n.nodeType === 3 ? doText(n) : doAttrs(n));
  }

  let observer = null;
  let target = null;
  function attach(root) {
    target = root;
    observer?.disconnect();
    observer = new MutationObserver((muts) => {
      observer.disconnect();
      try {
        for (const m of muts) {
          if (m.type === 'childList') m.addedNodes.forEach(walk);
          else if (m.type === 'characterData') doText(m.target);
          else if (m.type === 'attributes') doAttrs(m.target);
        }
      } finally {
        observer.observe(target, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
      }
    });
    observer.observe(target, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    walk(root);
  }

  // « auto » : langue de la page TikTok, sinon celle du navigateur ; une langue non proposée → anglais.
  const known = (code) => LANGS.some(([c]) => c === code);
  const detect = () => {
    const l = (document.documentElement.lang || navigator.language || 'en').toLowerCase().slice(0, 2);
    return known(l) ? l : 'en';
  };
  const resolve = (pref) => (known(pref) ? pref : detect());

  let pref = 'auto';
  const listeners = [];
  function set(p) {
    pref = p;
    const next = resolve(p);
    const changed = next !== lang;
    lang = next;
    if (changed) cache.clear();
    if (changed && target) walk(target);
    if (changed) listeners.forEach((f) => f(lang));
    return lang;
  }
  // TikTok n'écrit sa langue dans la page (<html lang>) qu'après son chargement (constaté : « en » d'abord, puis « es ») :
  // en mode automatique, on suit ce changement, pour que l'écran d'accueil s'affiche tout de suite dans la bonne langue.
  if (typeof MutationObserver !== 'undefined' && document.documentElement) {
    new MutationObserver(() => {
      if (!known(pref)) set(pref);
    }).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
  }

  return {
    attach,
    set,
    onChange: (f) => listeners.push(f),
    detect,
    tr,
    get lang() { return lang; },
    langs: LANGS.map(([code, name]) => ({ code, name })),
    locale: () => LANGS.find(([c]) => c === lang)?.[2] || 'en-GB',
  };
})();
