// Configuration de la vente (version Pro). Fichier chargé par background.js ET par content.js.
//
// Tant que storeId ET productId sont vides, l'extension est en « mode développement » : tout est débloqué, sans limite.
// Pour vendre :
//   1. Crée un produit « achat unique » avec clés de licence dans Lemon Squeezy (https://www.lemonsqueezy.com).
//   2. Recopie ci-dessous l'adresse de la page d'achat, l'identifiant de la boutique et celui du produit.
//      (Les identifiants servent à refuser les clés d'un autre produit.)
//   3. Pour te donner une licence gratuite à toi : crée un code de réduction à 100 % dans Lemon Squeezy.
const PRO_CONFIG = {
  buyUrl: 'https://sortfold.lemonsqueezy.com/checkout/buy/b981618b-b7be-4d10-bd0e-bce8455f8a55', // ex. https://TA-BOUTIQUE.lemonsqueezy.com/buy/xxxxxxxx-xxxx-xxxx
  storeId: '478324', // nombre
  productId: '1373287', // nombre
  price: '5 €',
  donateUrl: '', // page de don (Ko-fi, Buy Me a Coffee, PayPal.me, GitHub Sponsors…) ; vide = le bouton « Soutenir » est masqué
  freeDailyRemovals: 200, // retraits de favoris par jour en version gratuite (Pro : illimité)
  // Code personnel qui débloque le mode illimité. Seule l'empreinte (PBKDF2-SHA256, 200 000 tours, sel aléatoire) est stockée, jamais le code.
  masterSalt: 'bbb8afcc98f43374d70edb1d1c043236',
  masterHash: 'd61bb58bfa7285803aff972597637c02956e61ba6f3fc6ecd1fffbf27f919caa',
  revalidateDays: 7, // la licence est revérifiée tous les N jours
  offlineGraceDays: 30, // sans connexion, la licence reste valable encore N jours
};
