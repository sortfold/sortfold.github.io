// Script exécuté dans le contexte de la PAGE (world: MAIN), pas dans celui de l'extension.
// Seul ce contexte voit les propriétés React attachées aux éléments ; l'extension lui parle par postMessage.
//
// Deux besoins, vérifiés sur tiktok.com :
//  - « subtab » : les sous-onglets « Publications » / « Collections » du profil ignorent les clics simulés, mais le
//    composant qui les porte expose `onChange(id)`, qu'on appelle directement.
//  - « ids » / « modalIds » : les vignettes des collections ne se chargent pas quand l'onglet n'est pas visible ; en revanche chaque
//    élément de la liste porte l'identifiant de sa vidéo (`id`) et celui de sa collection (`teaParams.collection_id`).
(() => {
  const fiberOf = (el) => {
    const key = Object.keys(el).find((k) => k.startsWith('__reactFiber'));
    return key ? el[key] : null;
  };

  function switchSubTab({ id }) {
    const btn = [...document.querySelectorAll('button')].find((b) => /^(Publications|Collections)/.test(b.textContent.trim()));
    if (!btn) return { ok: false };
    for (let f = fiberOf(btn), i = 0; f && i < 15; f = f.return, i++) {
      const p = f.memoizedProps;
      if (p && typeof p.onChange === 'function' && Array.isArray(p.tabs)) {
        if (!p.tabs.some((t) => t.id === id)) return { ok: false };
        p.onChange(id);
        return { ok: true };
      }
    }
    return { ok: false };
  }

  // Identifiants des vidéos de la collection `collectionId`, ALIGNÉS sur les éléments de la liste (null si un élément
  // n'est pas reconnu). Le contrôle de `collection_id` évite de lire les cartes de la page précédente.
  function collectionIds({ collectionId }) {
    const data = [];
    for (const el of document.querySelectorAll('[data-e2e="collection-item-list"] [data-e2e="collection-item"]')) {
      let id = null;
      for (let f = fiberOf(el), i = 0; f && i < 14; f = f.return, i++) {
        const p = f.memoizedProps;
        if (p && p.teaParams && typeof p.id === 'string') {
          if (String(p.teaParams.collection_id) === String(collectionId)) id = p.id;
          break;
        }
      }
      data.push(id);
    }
    return { ok: true, data };
  }

  // Identifiants des favoris listés dans la fenêtre « Sélectionner des vidéos » (propriété `itemId`), dans l'ordre
  // de `[role="dialog"] [data-e2e="collection-item"]`.
  function modalIds() {
    const data = [];
    for (const el of document.querySelectorAll('[role="dialog"] [data-e2e="collection-item"]')) {
      let id = null;
      for (let f = fiberOf(el), i = 0; f && i < 14; f = f.return, i++) {
        const p = f.memoizedProps;
        if (p && typeof p.itemId === 'string') {
          id = p.itemId;
          break;
        }
      }
      data.push(id);
    }
    return { ok: true, data };
  }

  // Fiche de chaque vignette de la liste des favoris : description, auteur, image, durée, aperçu animé. L'élément de la
  // vignette porte l'identifiant de sa vidéo (prop `id`) et l'un de ses premiers hooks contient la fiche complète
  // (vérifié sur tiktok.com, octobre 2026 : 27 vignettes sur 27). Lisible même quand l'image n'est pas chargée (onglet
  // en arrière-plan), contrairement au texte alternatif de l'image. `from` : position dans la liste.
  function findItem(v, id, depth, seen) {
    if (!v || typeof v !== 'object' || depth > 4 || seen.has(v)) return null;
    seen.add(v);
    if (v.id === id && typeof v.desc === 'string') return v;
    for (const k of Object.keys(v).slice(0, 60)) {
      if (k === 'return' || k === 'child' || k === 'sibling' || k === '_owner' || k === 'stateNode') continue;
      const r = findItem(v[k], id, depth + 1, seen);
      if (r) return r;
    }
    return null;
  }
  // Champs utiles d'une fiche TikTok. Publication photo (diaporama) : « imagePost.images[].imageURL.urlList », sa vignette
  // dans « imagePost.cover » ; pas de vidéo à lire.
  function itemFields(it) {
    const photos = (it.imagePost?.images || []).map((p) => p.imageURL?.urlList?.[0]).filter(Boolean).slice(0, 35);
    return {
      desc: String(it.desc || '').slice(0, 400),
      author: it.author?.uniqueId || '',
      cover: it.imagePost?.cover?.imageURL?.urlList?.[0] || photos[0] || it.video?.cover || '',
      dyn: photos.length ? '' : it.video?.dynamicCover || '',
      dur: photos.length ? 0 : Number(it.video?.duration) || 0,
      photos,
    };
  }
  function itemOf(a) {
    const id = (a.href.match(/\/(?:video|photo)\/(\d+)/) || [])[1]; // publications photo : « /photo/ »
    if (!id) return null;
    for (let f = fiberOf(a), i = 0; f && i < 18; f = f.return, i++) {
      if (f.memoizedProps?.id !== id) continue;
      for (let h = f.memoizedState, j = 0; h && j < 12; h = h.next, j++) {
        const r = findItem(h.memoizedState, id, 0, new Set());
        if (r) return r;
      }
    }
    return null;
  }
  function favItems({ from = 0, max = 400 }) {
    const list = [...document.querySelectorAll('[data-e2e="favorites-item-list"] a[href*="/video/"], [data-e2e="favorites-item-list"] a[href*="/photo/"]')].slice(from, from + max);
    const data = list.map((a) => {
      const it = itemOf(a);
      if (!it) return null;
      return { id: it.id, ...itemFields(it) };
    });
    return { ok: true, data };
  }

  const calls = { subtab: switchSubTab, ids: collectionIds, modalIds, favItems };

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.tts !== 'call' || !calls[e.data.fn]) return;
    let res;
    try {
      res = calls[e.data.fn](e.data.args || {});
    } catch {
      res = { ok: false };
    }
    window.postMessage({ tts: 'result', reqId: e.data.reqId, ...res }, '*');
  });
})();
