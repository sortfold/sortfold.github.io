// Script exécuté dans le contexte de la PAGE (world: MAIN), pas dans celui de l'extension.
// Seul ce contexte voit les propriétés React attachées aux éléments ; l'extension lui parle par postMessage.
//
// Deux besoins, vérifiés sur tiktok.com :
//  - « subtab » : les sous-onglets « Publications » / « Collections » du profil ignorent les clics simulés, mais le
//    composant qui les porte expose `onChange(id)`, qu'on appelle directement.
//  - « ids » / « modalIds » : les vignettes des collections ne se chargent pas quand l'onglet n'est pas visible ; en revanche chaque
//    élément de la liste porte l'identifiant de sa vidéo (`id`) et celui de sa collection (`teaParams.collection_id`).
(() => {
  const fiberOf = (el) => {
    const key = Object.keys(el).find((k) => k.startsWith('__reactFiber'));
    return key ? el[key] : null;
  };

  function switchSubTab({ id }) {
    const btn = [...document.querySelectorAll('button')].find((b) => /^(Publications|Collections)/.test(b.textContent.trim()));
    if (!btn) return { ok: false };
    for (let f = fiberOf(btn), i = 0; f && i < 15; f = f.return, i++) {
      const p = f.memoizedProps;
      if (p && typeof p.onChange === 'function' && Array.isArray(p.tabs)) {
        if (!p.tabs.some((t) => t.id === id)) return { ok: false };
        p.onChange(id);
        return { ok: true };
      }
    }
    return { ok: false };
  }

  // Identifiants des vidéos de la collection `collectionId`, ALIGNÉS sur les éléments de la liste (null si un élément
  // n'est pas reconnu). Le contrôle de `collection_id` évite de lire les cartes de la page précédente.
  function collectionIds({ collectionId }) {
    const data = [];
    for (const el of document.querySelectorAll('[data-e2e="collection-item-list"] [data-e2e="collection-item"]')) {
      let id = null;
      for (let f = fiberOf(el), i = 0; f && i < 14; f = f.return, i++) {
        const p = f.memoizedProps;
        if (p && p.teaParams && typeof p.id === 'string') {
          if (String(p.teaParams.collection_id) === String(collectionId)) id = p.id;
          break;
        }
      }
      data.push(id);
    }
    return { ok: true, data };
  }

  // Identifiants des favoris listés dans la fenêtre « Sélectionner des vidéos » (propriété `itemId`), dans l'ordre
  // de `[role="dialog"] [data-e2e="collection-item"]`.
  function modalIds() {
    const data = [];
    for (const el of document.querySelectorAll('[role="dialog"] [data-e2e="collection-item"]')) {
      let id = null;
      for (let f = fiberOf(el), i = 0; f && i < 14; f = f.return, i++) {
        const p = f.memoizedProps;
        if (p && typeof p.itemId === 'string') {
          id = p.itemId;
          break;
        }
      }
      data.push(id);
    }
    return { ok: true, data };
  }

  const calls = { subtab: switchSubTab, ids: collectionIds, modalIds };

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.tts !== 'call' || !calls[e.data.fn]) return;
    let res;
    try {
      res = calls[e.data.fn](e.data.args || {});
    } catch {
      res = { ok: false };
    }
    window.postMessage({ tts: 'result', reqId: e.data.reqId, ...res }, '*');
  });
})();
